-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 26, 2011 at 08:54 PM
-- Server version: 5.0.67
-- PHP Version: 5.2.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `movies200`
--

-- --------------------------------------------------------

--
-- Table structure for table `info_best_visitors`
--

CREATE TABLE IF NOT EXISTS `info_best_visitors` (
  `time` varchar(255) NOT NULL,
  `v_count` int(11) NOT NULL default '0',
  KEY `v_count` (`v_count`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_best_visitors`
--

INSERT INTO `info_best_visitors` (`time`, `v_count`) VALUES
('20-Dec-2010 الساعة : 04:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `info_browser`
--

CREATE TABLE IF NOT EXISTS `info_browser` (
  `name` varchar(20) NOT NULL,
  `count` int(11) NOT NULL default '0',
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_browser`
--

INSERT INTO `info_browser` (`name`, `count`) VALUES
('Netscape', 0),
('MSIE', 124),
('Lynx', 0),
('Opera', 0),
('WebTV', 0),
('Konqueror', 0),
('Bot', 0),
('Other', 0),
('Chrome', 1542),
('Firefox', 1),
('Nokia', 0),
('BlackBerry', 0),
('iPhone', 0),
('iPod', 0),
('Android', 0);

-- --------------------------------------------------------

--
-- Table structure for table `info_hits`
--

CREATE TABLE IF NOT EXISTS `info_hits` (
  `date` varchar(20) NOT NULL,
  `hits` int(11) NOT NULL default '0',
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_hits`
--


-- --------------------------------------------------------

--
-- Table structure for table `info_online`
--

CREATE TABLE IF NOT EXISTS `info_online` (
  `time` int(15) NOT NULL default '0',
  `ip` varchar(40) NOT NULL default '',
  `uid` int(11) NOT NULL default '0',
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_online`
--

INSERT INTO `info_online` (`time`, `ip`, `uid`) VALUES
(1303835666, '127.0.0.1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `info_os`
--

CREATE TABLE IF NOT EXISTS `info_os` (
  `name` varchar(20) NOT NULL,
  `count` int(11) NOT NULL default '0',
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_os`
--

INSERT INTO `info_os` (`name`, `count`) VALUES
('Windows', 1666),
('Mac', 0),
('Linux', 0),
('FreeBSD', 0),
('SunOS', 0),
('IRIX', 0),
('BeOS', 0),
('OS/2', 0),
('AIX', 0),
('Other', 1),
('BlackBerry', 0),
('Symbian', 0);

-- --------------------------------------------------------

--
-- Table structure for table `movies_access_log`
--

CREATE TABLE IF NOT EXISTS `movies_access_log` (
  `id` int(11) NOT NULL auto_increment,
  `username` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `status` text NOT NULL,
  `ip` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_access_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_actors`
--

CREATE TABLE IF NOT EXISTS `movies_actors` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `img` text NOT NULL,
  `thumb` text NOT NULL,
  `details` text NOT NULL,
  `views` int(11) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_actors`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_actors_index`
--

CREATE TABLE IF NOT EXISTS `movies_actors_index` (
  `id` int(11) NOT NULL auto_increment,
  `actor_id` int(11) NOT NULL default '0',
  `movie_id` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `movie_id` (`movie_id`),
  KEY `actor_id` (`actor_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_actors_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_actors_photos`
--

CREATE TABLE IF NOT EXISTS `movies_actors_photos` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `cat` int(11) NOT NULL default '0',
  `img` text NOT NULL,
  `img_resized` text NOT NULL,
  `thumb` text NOT NULL,
  `date` int(10) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_actors_photos`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_actors_photos_tags`
--

CREATE TABLE IF NOT EXISTS `movies_actors_photos_tags` (
  `id` int(11) NOT NULL auto_increment,
  `photo_id` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `actor_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `actor_id` (`actor_id`),
  KEY `photo_id` (`photo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_actors_photos_tags`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_banners`
--

CREATE TABLE IF NOT EXISTS `movies_banners` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `img` text NOT NULL,
  `date` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `type` varchar(20) NOT NULL,
  `views` int(11) NOT NULL default '0',
  `clicks` int(11) NOT NULL default '0',
  `menu_id` int(11) NOT NULL default '0',
  `menu_pos` varchar(1) NOT NULL,
  `pages` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `c_type` varchar(20) NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pages` (`pages`),
  KEY `active` (`active`),
  KEY `menu_pos` (`menu_pos`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `movies_banners`
--

INSERT INTO `movies_banners` (`id`, `title`, `url`, `img`, `date`, `ord`, `type`, `views`, `clicks`, `menu_id`, `menu_pos`, `pages`, `content`, `c_type`, `active`) VALUES
(1, 'اللوماني', 'http://allomani.com', 'http://allomani.com/allomani_banner.gif', 1294499147, 0, 'header', 48, 0, 0, 'r', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', '', 'img', 1),
(2, 'اللوماني', 'http://allomani.com', 'http://allomani.com/allomani_banner.gif', 1294499245, 0, 'footer', 45, 0, 0, 'r', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', '', 'img', 1);

-- --------------------------------------------------------

--
-- Table structure for table `movies_blocks`
--

CREATE TABLE IF NOT EXISTS `movies_blocks` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `pos` varchar(2) NOT NULL default '',
  `file` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `template` varchar(255) NOT NULL default '0',
  `pages` varchar(255) NOT NULL default '',
  `hide_title` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `active` (`active`),
  KEY `pages` (`pages`),
  KEY `pos` (`pos`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `movies_blocks`
--

INSERT INTO `movies_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`, `hide_title`, `cat`) VALUES
(10, 'البحث', 'r', '<form method="postt" action="search.php">\r\n<input type=text name="keyword" size="15" tabindex="1">\r\n<br>\r\n<select name="op">\r\n<option value="movies">افلام</option>\r\n<option value="news">اخبار</option>\r\n<input type=submit value="بحث" tabindex="1">\r\n</form>', 4, 1, '0', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', 0, 0),
(8, 'القائمة الرئيسية', 'r', '<b>::</b> <a href=''index.php''>الرئيسية </a><br>\r\n<b>::</b> <a href=''browse.html''>استعراض الأفلام</a><br>\r\n\r\n<b>::</b> <a href=''actors.html''>الممثلين</a><br>\r\n\r\n\r\n<b>::</b> <a href=''news.html''>الاخبار</a><br>\r\n<b>::</b> <a href=''statistics.php''>احصائيات الموقع</a><br>\r\n<b>::</b> <a href=''contactus.php''>الاتصال بنا</a><br>\r\n ', 0, 1, '0', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', 0, 0),
(29, 'أخر الإضافات', 'c', '<?\r\nglobal $settings,$data;\r\n\r\n$qr=db_query("select * from movies_data order by date DESC limit 8") ;\r\n\r\nrun_template(''browse_movies_header'');\r\n\r\n$c=0 ;\r\n\r\n\r\nwhile ($data =db_fetch($qr)){\r\n\r\n   \r\nif ($c==$settings[''movies_cells'']) {\r\nrun_template(''browse_movies_sep'');\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\nrun_template(''browse_movies'');\r\n              \r\n}\r\nrun_template(''browse_movies_footer'');\r\n?>', 1, 1, '0', 'main,', 0, 0),
(11, 'الاستفتاءات', 'l', '<?\r\n$qr_title = db_query("select * from movies_votes_cats  where active=1");\r\nif(db_num($qr_title)){\r\n\r\n$data_title = db_fetch($qr_title);\r\nprint "<center>$data_title[title]</center>";\r\n$qr = mysql_query("select * from movies_votes where cat=$data_title[id]");\r\nprint "<form action=\\"votes.php\\" method=\\"post\\">\r\n<input type=''hidden'' name=''action'' value=''vote_add''>\r\n";\r\n\r\n while ($data = mysql_fetch_array($qr)){\r\n\r\n        print "<input type=''radio'' value=''$data[id]'' name=''vote_id''>$data[title]<br>";\r\n\r\n\r\n\r\n }\r\nprint "<center><br><input type=''submit'' value=''تصويت''> <br><br><a href=''votes.php''>النتائج </a></center></form>";\r\n}else{\r\nprint "<center>  لا توجد تصويتات مفعلة حاليا </center>";\r\n}\r\n?>', 1, 1, '0', 'main,browse.php,movie_info.php,news.php,pages,search.php,votes.php,statics,contactus.php,', 0, 0),
(4, 'المتواجدون الأن', 'r', '<?\r\nglobal $counter,$settings ;\r\n\r\nprint "<p align=center>  يتصفح الموقع حاليا $counter[online_users] زائر";\r\n\r\nif($settings[''online_members_count'']){\r\nprint " , $counter[online_members] عضو";\r\n}\r\n\r\nprint "</p>";\r\n\r\nprint "<p dir=rtl align=center>أكبر تواجد كان  $counter[best_visit] في : <br> $counter[best_visit_time] <br></p>";\r\n\r\n', 3, 1, '0', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', 0, 0),
(18, 'آخر الأخبار', 'c', '<?\r\nglobal $data,$phrases;\r\n$qr = db_query("select * from movies_news order by id DESC limit 4");\r\n\r\nif(db_num($qr)){\r\nprint "\r\n<hr width=100% class=separate_line size=\\"1\\">" ;\r\n\r\nwhile($data = db_fetch($qr)){\r\n\r\n\r\nrun_template(''browse_news'');  \r\n\r\n\r\n        }\r\n\r\n}else{\r\nprint "<center> $phrases[no_news]</center>";\r\n}\r\n       ?>', 5, 1, '0', 'main,', 0, 0),
(37, 'الأكثر تقييما', 'c', '<?\r\nglobal $settings,$data,$links,$phrases;\r\n\r\n$qr=db_query("select *  from movies_data where votes > 0 order by (votes / votes_total) DESC limit 4");\r\n\r\nif(db_num($qr)){\r\ncompile_template(get_template(''browse_movies_header''));\r\n\r\n$c=0 ;\r\n\r\n\r\nwhile ($data =db_fetch($qr)){\r\n\r\n   \r\nif ($c==$settings[''movies_cells'']) {\r\ncompile_template(get_template(''browse_movies_sep''));\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\ncompile_template(get_template(''browse_movies''));\r\n              \r\n}\r\ncompile_template(get_template(''browse_movies_footer''));\r\n}else{\r\nprint "<center> $phrases[no_movies]</center>";\r\n}\r\n?>', 4, 1, '0', 'main,', 0, 35),
(21, 'الأقسام', 'r', '<?\r\nglobal $links,$cats,$phrases;\r\n?>\r\n\r\n<script type="text/javascript" src="js/cats_menu.js"></script>\r\n\r\n<?\r\n$qr = db_query("select id,cat,name from movies_cats where active=1 order by cat,ord asc");\r\nif(db_num($qr)){\r\n\r\nwhile($data = db_fetch($qr)){\r\n    $cats[$data[''cat'']][]= array("id"=>$data[''id''],"name"=>$data[''name'']);\r\n}\r\nunset($data);\r\n\r\nprint "<ul id=\\"cats_menu\\">";\r\nforeach($cats[0] as $data){\r\nget_expand_menu_items($data);\r\n    \r\n}\r\nprint "</ul>";\r\n\r\n?>\r\n<script type="text/javascript">\r\nexpanded_initiate(); \r\n</script>\r\n\r\n<?\r\n}else{\r\nprint "<center>".$phrases[''no_cats'']."</center>";\r\n}\r\n\r\nfunction get_expand_menu_items($dx){\r\n    global $cats,$links;\r\n print "<li>\r\n<a href=\\"".str_replace("{id}",$dx[''id''],$links[''links_cats''])."\\" title=\\"$dx[name]\\"><img src=''images/folder_small.gif''>&nbsp;$dx[name]</a>";\r\n\r\nif(count($cats[$dx[''id'']])){\r\n    print "<ul>";\r\n foreach($cats[$dx[''id'']] as $dx2){\r\n get_expand_menu_items($dx2);\r\n    }   \r\n    \r\n    print "</ul>";\r\n}\r\n\r\nprint "</li>";\r\n}\r\n?>', 1, 1, '0', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', 0, 0),
(23, 'احصائيات', 'r', '<?\r\nglobal $phrases;\r\n\r\n   $cnt_movies = db_qr_fetch("select count(id) as count from movies_data");\r\n\r\n$cnt_files = db_qr_fetch("select count(id) as count from movies_files");\r\n\r\n\r\n    $cnt_cats = db_qr_fetch("select count(id) as count from movies_cats");\r\n\r\n\r\nprint "\r\n\r\n<b> $phrases[cats_count] : </b> $cnt_cats[count] <br>\r\n <b>  $phrases[movies_count] : </b> $cnt_movies[count] <br>\r\n\r\n <b>  $phrases[files_count] : </b> $cnt_files[count] <br>\r\n";\r\n?>', 5, 1, '0', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', 0, 0),
(24, 'جديد السوق', 'l', '<?\r\nglobal $links;\r\n\r\n$qr = db_query("select movies_data.* from movies_new_menu,movies_data where movies_data.id=movies_new_menu.movie_id order by movies_new_menu.ord asc");\r\nprint "<center>";\r\n\r\nwhile($data=db_fetch($qr)){\r\n\r\n\r\nprint "<a href=\\"".str_replace("{id}",$data[''id''],$links[''links_movie_info''])."\\" title=\\"$data[name]\\"><img width=70 src=\\"".get_image($data[''thumb''])."\\" title=\\"$data[name]\\" border=0><br>$data[name]</a>".iif($data[''year''],"<br><span dir=''ltr''>( $data[year] )</span>")."<br><br>";\r\n}\r\n', 0, 1, '0', 'main,browse.php,movie_info.php,news.php,pages,search.php,votes.php,statics,contactus.php,', 0, 0),
(30, 'الأعضاء', 'r', '<? if(check_member_login()){\r\nglobal $member_data,$style ;\r\n\r\n\r\nprint "<center>  أهلا و سهلا بك يا $member_data[username] <br> <br>" ;\r\n$nw_msgs = db_qr_fetch("select count(id) as count from movies_members_msgs where owner=''$member_data[id]'' and opened=0 and sent=0");\r\n\r\nif($nw_msgs[''count''] >0){\r\nprint "<font color=red> لديك $nw_msgs[count] رسائل جديدة </font><br><br>";\r\n}\r\n\r\nprint "</center>\r\n\r\n<a href=''usercp.php''><img src=''$style[images]/my_favorite.gif''>&nbsp; المفضلة </a><br>\r\n\r\n\r\n<a href=''messages.php''><img src=''$style[images]/my_messages.gif''>&nbsp; الرسائل الخاصة</a><br>\r\n\r\n<a href=''usercp.php?action=profile''><img src=''$style[images]/my_profile.gif''>&nbsp; الملف الشخصي </a><br>\r\n\r\n<a href=''usercp.php?action=friends''><img src=''$style[images]/friends_list.gif''>&nbsp; الاصدقاء </a><br>\r\n\r\n<a href=''usercp.php?action=black_list''><img src=''$style[images]/black_list.gif''>&nbsp; قائمة التجاهل</a><br>\r\n\r\n<a href=''login.php?action=logout''><img src=''$style[images]/logout.gif''>&nbsp; تسجيل خروج </a>\r\n</center><br>";\r\n}else{\r\n?>\r\n<form method="POST" action="login.php">\r\n<input type=hidden name=action value=login>\r\n<input type=hidden name=re_link value="<? print $_SERVER[REQUEST_URI] ; ?>">\r\n<table border="0" width="100%">\r\n	<tr>\r\n		<td height="15"><span lang="ar-sa">اسم المستخدم :</span></td></tr><tr>\r\n		<td height="15"><input type="text" name="username" size="10"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="12"><span lang="ar-sa">كلمة المرور :</span></td></tr><tr>\r\n		<td height="12" ><input type="password" name="password" size="10"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="23">\r\n		<p align="center"><input type="submit" value="تسجيل دخول"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="38"><span lang="ar-sa">\r\n		<a href="register.php">مستخدم جديد ؟</a><br>\r\n		<a href="index.php?action=forget_pass">نسيت كلمة المرور ؟</a></span></td>\r\n	</tr>\r\n</table>\r\n</form>\r\n\r\n<?\r\n}\r\n?>', 2, 1, '0', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', 0, 0),
(36, 'الأكثر تحميلا', 'c', '<?\r\nglobal $settings,$data,$links;\r\n\r\n$qr=db_query("select movies_data.*  from movies_files,movies_data where movies_data.id=movies_files.cat group by movies_files.cat order by movies_files.downloads DESC limit 4");\r\n\r\ncompile_template(get_template(''browse_movies_header''));\r\n\r\n$c=0 ;\r\n\r\n\r\nwhile ($data =db_fetch($qr)){\r\n\r\n   \r\nif ($c==$settings[''movies_cells'']) {\r\ncompile_template(get_template(''browse_movies_sep''));\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\ncompile_template(get_template(''browse_movies''));\r\n              \r\n}\r\ncompile_template(get_template(''browse_movies_footer''));\r\n?>', 3, 1, '0', 'main,', 0, 35),
(35, 'الأكثر مشاهدة', 'c', '<?\r\nglobal $settings,$data,$links;\r\n\r\n$qr=db_query("select movies_data.*  from movies_files,movies_data where movies_data.id=movies_files.cat group by movies_files.cat order by movies_files.views DESC limit 4");\r\n\r\ncompile_template(get_template(''browse_movies_header''));\r\n\r\n$c=0 ;\r\n\r\n\r\nwhile ($data =db_fetch($qr)){\r\n\r\n   \r\nif ($c==$settings[''movies_cells'']) {\r\ncompile_template(get_template(''browse_movies_sep''));\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\ncompile_template(get_template(''browse_movies''));\r\n              \r\n}\r\ncompile_template(get_template(''browse_movies_footer''));\r\n?>', 2, 1, '0', 'main,', 0, 0),
(38, 'العروض', 'c', '<?\r\n\r\n$qr=db_query("select * from movies_banners where `type` like ''offer'' and active=1 order by ord");\r\nif(db_num($qr)){\r\n\r\ninclude_once("includes/class_slider.php");\r\n\r\nopen_table();\r\n$slider = new slider("slider");      \r\n\r\nwhile($data=db_fetch($qr)){\r\n\r\n$ids[] = $data[''id''];\r\n\r\n$slider->start($data[''id'']);\r\nprint "<center>".iif($data[''url''],"<a href=\\"banner.php?id=$data[id]\\" target=_blank>").iif($data[''img''],"<img border=0 src=\\"$data[img]\\" alt=\\"$data[title]\\"><br><br>").$data[''content''].iif($data[''url''],"</a>")."</center>";\r\n\r\n$slider->end();  \r\n}\r\n\r\n\r\n$slider->run();\r\ndb_query("update movies_banners set views=views+1 where id IN (".implode(",",$ids).")");\r\nclose_table();\r\n}\r\n?>\r\n', 0, 1, 'no_title_no_border', 'main,', 1, 0),
(39, 'RSS & Sitemap', 'l', '<center>\r\n<a href=''rss.php''><img src=''images/rss.gif'' title=''RSS'' border=0><br>RSS</a>\r\n\r\n<hr class=separate_line size=1>\r\n<br>\r\n<a href=''sitemap.xml''><img src=''images/sitemap.gif'' title=''Sitemap'' border=0><br>خريطة الموقع</a>\r\n</center>', 2, 1, '0', 'main,browse.php,movie_info.php,news.php,pages,search.php,votes.php,statics,contactus.php,', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `movies_cats`
--

CREATE TABLE IF NOT EXISTS `movies_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `img` varchar(255) NOT NULL default '',
  `cat` int(11) NOT NULL default '0',
  `active` int(1) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `path` varchar(255) NOT NULL default '',
  `users` varchar(255) NOT NULL default '',
  `page_title` text NOT NULL,
  `page_description` text NOT NULL,
  `page_keywords` text NOT NULL,
  `download_for_members` int(1) NOT NULL,
  `watch_for_members` int(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `active` (`active`),
  KEY `cat` (`cat`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `movies_cats`
--

INSERT INTO `movies_cats` (`id`, `name`, `img`, `cat`, `active`, `ord`, `path`, `users`, `page_title`, `page_description`, `page_keywords`, `download_for_members`, `watch_for_members`) VALUES
(1, 'الأفلام', '', 0, 1, 1, '1,0', '', '', '', '', 0, 0),
(2, 'المسلسلات', '', 0, 1, 2, '2,0', '10', '', '', '', 0, 0),
(3, 'افلام عربية', '', 1, 1, 1, '3,1,0', '', '', '', '', 0, 0),
(4, 'افلام اجنبية', '', 1, 1, 0, '4,1,0', '10', '', '', '', 0, 0),
(5, 'افلام هندية', '', 1, 1, 2, '5,1,0', '', '', '', '', 0, 0),
(6, 'مسلسلات عربية', '', 2, 1, 2, '6,2,0', '', '', '', '', 0, 0),
(7, 'مسلسلات اجنبية', '', 2, 1, 1, '7,2,0', '', '', '', '', 0, 0),
(8, 'مسلسلات تركية', '', 2, 1, 0, '8,2,0', '', '', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `movies_comments`
--

CREATE TABLE IF NOT EXISTS `movies_comments` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL default '0',
  `fid` int(11) NOT NULL default '0',
  `comment_type` varchar(100) NOT NULL default '',
  `content` text NOT NULL,
  `time` int(14) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `movie_id` (`fid`,`comment_type`,`active`),
  KEY `active` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_confirmations`
--

CREATE TABLE IF NOT EXISTS `movies_confirmations` (
  `id` int(11) NOT NULL auto_increment,
  `type` text NOT NULL,
  `old_value` text NOT NULL,
  `new_value` text NOT NULL,
  `cat` int(11) NOT NULL default '0',
  `code` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_confirmations`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_countries`
--

CREATE TABLE IF NOT EXISTS `movies_countries` (
  `name` varchar(80) NOT NULL default '',
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movies_countries`
--

INSERT INTO `movies_countries` (`name`) VALUES
('Afghanistan'),
('Albania'),
('Algeria'),
('American Samoa'),
('Andorra'),
('Angola'),
('Anguilla'),
('Antarctica'),
('Antigua and Barbuda'),
('Argentina'),
('Armenia'),
('Aruba'),
('Australia'),
('Austria'),
('Azerbaijan'),
('Bahamas'),
('Bahrain'),
('Bangladesh'),
('Barbados'),
('Belarus'),
('Belgium'),
('Belize'),
('Benin'),
('Bermuda'),
('Bhutan'),
('Bolivia'),
('Bosnia and Herzegovina'),
('Botswana'),
('Bouvet Island'),
('Brazil'),
('British Indian Ocean Territory'),
('Brunei Darussalam'),
('Bulgaria'),
('Burkina Faso'),
('Burundi'),
('Cambodia'),
('Cameroon'),
('Canada'),
('Cape Verde'),
('Cayman Islands'),
('Central African Republic'),
('Chad'),
('Chile'),
('China'),
('Christmas Island'),
('Cocos (Keeling) Islands'),
('Colombia'),
('Comoros'),
('Congo'),
('Cook Islands'),
('Costa Rica'),
('Cote D''Ivoire'),
('Croatia'),
('Cuba'),
('Cyprus'),
('Czech Republic'),
('Denmark'),
('Djibouti'),
('Dominica'),
('Dominican Republic'),
('Ecuador'),
('Egypt'),
('El Salvador'),
('Equatorial Guinea'),
('Eritrea'),
('Estonia'),
('Ethiopia'),
('Faroe Islands'),
('Fiji'),
('Finland'),
('France'),
('Gabon'),
('Gambia'),
('Georgia'),
('Germany'),
('Ghana'),
('Gibraltar'),
('Greece'),
('Greenland'),
('Grenada'),
('Guadeloupe'),
('Guam'),
('Guatemala'),
('Guinea'),
('Guinea-Bissau'),
('Guyana'),
('Haiti'),
('Honduras'),
('Hong Kong'),
('Hungary'),
('Iceland'),
('India'),
('Indonesia'),
('Iraq'),
('Ireland'),
('Israel'),
('Italy'),
('Jamaica'),
('Japan'),
('Jordan'),
('Kazakhstan'),
('Kenya'),
('Kiribati'),
('Korea, Republic of'),
('Kuwait'),
('Kyrgyzstan'),
('Latvia'),
('Lebanon'),
('Lesotho'),
('Liberia'),
('Libyan Arab Jamahiriya'),
('Liechtenstein'),
('Lithuania'),
('Luxembourg'),
('Macao'),
('Madagascar'),
('Malawi'),
('Malaysia'),
('Maldives'),
('Mali'),
('Malta'),
('Marshall Islands'),
('Martinique'),
('Mauritania'),
('Mauritius'),
('Mayotte'),
('Mexico'),
('Monaco'),
('Mongolia'),
('Montserrat'),
('Morocco'),
('Mozambique'),
('Myanmar'),
('Namibia'),
('Nauru'),
('Nepal'),
('Netherlands'),
('Netherlands Antilles'),
('New Caledonia'),
('New Zealand'),
('Nicaragua'),
('Niger'),
('Nigeria'),
('Niue'),
('Norfolk Island'),
('Norway'),
('Oman'),
('Pakistan'),
('Palau'),
('Palestine'),
('Panama'),
('Papua New Guinea'),
('Paraguay'),
('Peru'),
('Philippines'),
('Pitcairn'),
('Poland'),
('Portugal'),
('Puerto Rico'),
('Qatar'),
('Reunion'),
('Romania'),
('Russian Federation'),
('Rwanda'),
('Saint Helena'),
('Saint Kitts and Nevis'),
('Saint Lucia'),
('Saint Pierre and Miquelon'),
('Samoa'),
('San Marino'),
('Sao Tome and Principe'),
('Saudi Arabia'),
('Senegal'),
('Serbia and Montenegro'),
('Seychelles'),
('Sierra Leone'),
('Singapore'),
('Slovakia'),
('Slovenia'),
('Solomon Islands'),
('Somalia'),
('South Africa'),
('Spain'),
('Sri Lanka'),
('Sudan'),
('Suriname'),
('Svalbard and Jan Mayen'),
('Swaziland'),
('Sweden'),
('Switzerland'),
('Syrian Arab Republic'),
('Taiwan, Province of China'),
('Tajikistan'),
('Thailand'),
('Timor-Leste'),
('Togo'),
('Tokelau'),
('Tonga'),
('Trinidad and Tobago'),
('Tunisia'),
('Turkey'),
('Turkmenistan'),
('Turks and Caicos Islands'),
('Tuvalu'),
('Uganda'),
('Ukraine'),
('United Arab Emirates'),
('United Kingdom'),
('United States'),
('Uruguay'),
('Uzbekistan'),
('Vanuatu'),
('Venezuela'),
('Viet Nam'),
('Virgin Islands, British'),
('Virgin Islands, U.s.'),
('Wallis and Futuna'),
('Western Sahara'),
('Yemen'),
('Zambia'),
('Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `movies_data`
--

CREATE TABLE IF NOT EXISTS `movies_data` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `details` text NOT NULL,
  `img` text NOT NULL,
  `thumb` text NOT NULL,
  `date` int(10) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL default '0',
  `year` int(11) NOT NULL default '0',
  `director` varchar(50) NOT NULL default '',
  `page_title` varchar(255) NOT NULL default '',
  `page_description` varchar(255) NOT NULL default '',
  `page_keywords` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_fields_sets`
--

CREATE TABLE IF NOT EXISTS `movies_fields_sets` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `style` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `enable_search` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_fields_sets`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_files`
--

CREATE TABLE IF NOT EXISTS `movies_files` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `url_watch` text NOT NULL,
  `date` int(11) NOT NULL default '0',
  `downloads` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `ord` (`ord`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_files`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_hooks`
--

CREATE TABLE IF NOT EXISTS `movies_hooks` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `hookid` varchar(255) NOT NULL,
  `code` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_hooks`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_links`
--

CREATE TABLE IF NOT EXISTS `movies_links` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `movies_links`
--

INSERT INTO `movies_links` (`id`, `name`, `value`) VALUES
(1, 'links_actor_photos', 'actor_{id}/photos.html'),
(2, 'links_movie_files', 'movie_{id}/files.html'),
(3, 'links_movie_actors', 'movie_{id}/actors.html'),
(4, 'links_movie_subtitles', 'movie_{id}/subtitles.html'),
(5, 'links_actor_photo', 'actor/photo_{id}.html'),
(6, 'file_watch', 'watch_{id}.html'),
(7, 'links_profile', 'profile_{id}.html'),
(8, 'links_movie_info', 'movie_{id}/index.html'),
(9, 'links_cats', 'cat_{id}.html'),
(10, 'links_pages', 'page_{id}.html'),
(11, 'links_browse_news', 'news_{cat}.html'),
(12, 'links_browse_news_w_pages', 'news_{cat}_{start}.html'),
(13, 'links_actor_details', 'actor_{id}/index.html'),
(14, 'links_actors', 'actors.html'),
(15, 'links_movie_photo', 'movie/photo_{id}.html'),
(16, 'links_movie_photos', 'movie_{id}/photos.html'),
(17, 'file_download', 'download_{id}'),
(18, 'subtitle_download', 'subtitle_download_{id}'),
(19, 'file_watch_ext', 'watch_{id}'),
(20, 'links_cats_w_pages', 'cat_{id}_{start}_{orderby}_{sort}.html'),
(21, 'news_details', 'news_view_{id}.html'),
(22, 'links_news', 'news.html'),
(23, 'actors_w_pages', 'actors_{start}.html');

-- --------------------------------------------------------

--
-- Table structure for table `movies_members`
--

CREATE TABLE IF NOT EXISTS `movies_members` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL default '',
  `password` varchar(100) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `active_code` varchar(255) NOT NULL default '',
  `date` int(11) NOT NULL default '0',
  `last_login` int(11) NOT NULL default '0',
  `usr_group` int(11) NOT NULL default '0',
  `birth` date NOT NULL default '0000-00-00',
  `country` varchar(90) NOT NULL default '',
  `gender` varchar(10) NOT NULL default '',
  `members_list` int(11) NOT NULL default '0',
  `img` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `pm_email_notify` int(1) NOT NULL,
  `privacy_settings` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_members`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_members_black`
--

CREATE TABLE IF NOT EXISTS `movies_members_black` (
  `id` int(11) NOT NULL auto_increment,
  `uid1` int(11) NOT NULL,
  `uid2` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_members_black`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_members_favorites`
--

CREATE TABLE IF NOT EXISTS `movies_members_favorites` (
  `id` int(11) NOT NULL auto_increment,
  `fid` int(11) NOT NULL default '0',
  `uid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_members_favorites`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_members_friends`
--

CREATE TABLE IF NOT EXISTS `movies_members_friends` (
  `id` int(11) NOT NULL auto_increment,
  `uid1` int(11) NOT NULL,
  `uid2` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_members_friends`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_members_msgs`
--

CREATE TABLE IF NOT EXISTS `movies_members_msgs` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `owner` int(11) NOT NULL default '0',
  `uid` int(11) NOT NULL default '0',
  `username` varchar(255) NOT NULL,
  `opened` int(1) NOT NULL default '0',
  `date` int(11) NOT NULL default '0',
  `sent` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `user` (`owner`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_members_msgs`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_members_sets`
--

CREATE TABLE IF NOT EXISTS `movies_members_sets` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `style` varchar(255) NOT NULL,
  `required` int(1) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `required` (`required`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_members_sets`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_meta`
--

CREATE TABLE IF NOT EXISTS `movies_meta` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `title` text NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `movies_meta`
--

INSERT INTO `movies_meta` (`id`, `name`, `title`, `description`, `keywords`) VALUES
(1, 'movie_info', '{name} {year} - {cat}', 'فيلم {name} {year} , قسم {cat} , افلام {cat} , تحميل {name} , مشاهدة {name}', 'فيلم {name} {year} , قسم {cat} , افلام {cat} , تحميل {name} , مشاهدة {name}'),
(2, 'cats', '{name}{sp}{page}', 'قسم {name} , {name} 2010 , {name} 2010 , تحميل {name} , مشاهدة {name} {page}', '{name} , {name} 2010 , {name} 2010 , تحميل {name} , مشاهدة {name} {page}'),
(3, 'news', '{name}', '{name} , اقرأ {name} , خبر {name} , تفاصيل {name}', '{name} , اقرأ {name} , خبر {name} , تفاصيل {name}'),
(4, 'actor_details', '{name}', 'بيانات {name} , تفاصيل {name} , اخبار {name} , صور {name} , افلام {name}', 'بيانات {name} , تفاصيل {name} , اخبار {name} , صور {name} , افلام {name}'),
(5, 'movie_watch', 'مشاهدة {file} - {movie} {year} - {cat}', 'مشاهدة {movie} {year},مشاهدة {file} , تحميل {movie} {year}, تحميل {file} , {cat}', 'مشاهدة {movie} {year} ,مشاهدة {file} , تحميل {movie} {year}, تحميل {file} , {cat}'),
(6, 'movie_photo', 'الصورة {id} - {movie} {year} - {cat}', 'الصورة {id} , {name} , {movie} , {year} , {cat}', 'الصورة {id} , {name} , {movie} , {year} , {cat}'),
(7, 'movie_photos', 'صور الفيلم - {movie} {year} - {cat}', 'صور الفيلم , {movie} , {year} , {cat}', 'صور الفيلم , {movie} , {year} , {cat}'),
(8, 'movie_actors', 'ممثلين الفيلم {movie} {year} - {cat}', 'ممثلين الفيلم {movie} {year} , {cat} , مشاهدة {movie} , تحميل {movie}', 'ممثلين الفيلم {movie} {year} , {cat} , مشاهدة {movie} , تحميل {movie}'),
(9, 'movie_files', 'ملفات الفيلم {movie} {year} - {cat}', 'ملفات الفيلم {movie} {year} , {cat} , مشاهدة {movie} , تحميل {movie}', 'ملفات الفيلم {movie} {year} , {cat} , مشاهدة {movie} , تحميل {movie}'),
(10, 'movie_subtitles', 'ترجمات الفيلم {movie} {year} - {cat}', 'ترجمات الفيلم {movie} {year} , {cat} , مشاهدة {movie} , تحميل {movie}', 'ترجمات الفيلم {movie} {year} , {cat} , مشاهدة {movie} , تحميل {movie}'),
(11, 'actor_photo', 'الصورة {id} - {name}', 'الصورة {id} , بيانات {name} , تفاصيل {name} , اخبار {name} , صور {name} , افلام {name}', 'الصورة {id} , بيانات {name} , تفاصيل {name} , اخبار {name} , صور {name} , افلام {name}'),
(12, 'actor_photos', 'صور الممثل - {name}', 'صور الممثل , بيانات {name} , تفاصيل {name} , اخبار {name} , صور {name} , افلام {name}', 'صور الممثل , بيانات {name} , تفاصيل {name} , اخبار {name} , صور {name} , افلام {name}'),
(13, 'member_profile', '{name} - الملف الشخصي', 'الملف الشخصي {name} , {name} profile , العضو {name} , الافلام المفصلة {name} , مراسلة {name}', 'الملف الشخصي {name} , {name} profile , العضو {name} , الافلام المفصلة {name} , مراسلة {name}'),
(14, 'pages', '{name}', 'صفحة {name} , تفاصيل {name}', 'صفحة {name} , تفاصيل {name}'),
(15, 'actors', 'الممثلين{sp}{page}', 'الممثلين , الفنانين , المخرجين , الفنان , الممثل , المخرج , المنتج {page}', 'الممثلين , الفنانين , المخرجين , الفنان , الممثل , المخرج , المنتج {page}'),
(16, 'news_cats', '{name}{sp}{page}', '{name} , اخبار {name} , جديد {name} , {name} news , {name} حصري', '{name} , اخبار {name} , جديد {name} , {name} news , {name} حصري');

-- --------------------------------------------------------

--
-- Table structure for table `movies_news`
--

CREATE TABLE IF NOT EXISTS `movies_news` (
  `id` int(11) NOT NULL auto_increment,
  `writer` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `details` text NOT NULL,
  `date` int(11) NOT NULL,
  `img` text NOT NULL,
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_news`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_news_cats`
--

CREATE TABLE IF NOT EXISTS `movies_news_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_news_cats`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_new_menu`
--

CREATE TABLE IF NOT EXISTS `movies_new_menu` (
  `id` int(11) NOT NULL auto_increment,
  `movie_id` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `movie_id` (`movie_id`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_new_menu`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_pages`
--

CREATE TABLE IF NOT EXISTS `movies_pages` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `active` (`active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `movies_pages`
--

INSERT INTO `movies_pages` (`id`, `title`, `content`, `active`) VALUES
(1, 'صفحة اختبار', '<p>\r\n	صفحة اختبار</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `movies_photos`
--

CREATE TABLE IF NOT EXISTS `movies_photos` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `cat` int(11) NOT NULL default '0',
  `img` text NOT NULL,
  `img_resized` text NOT NULL,
  `thumb` text NOT NULL,
  `date` int(10) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_photos`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_photos_tags`
--

CREATE TABLE IF NOT EXISTS `movies_photos_tags` (
  `id` int(11) NOT NULL auto_increment,
  `photo_id` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `actor_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `actor_id` (`actor_id`),
  KEY `photo_id` (`photo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_photos_tags`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_phrases`
--

CREATE TABLE IF NOT EXISTS `movies_phrases` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `cat` varchar(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1468 ;

--
-- Dumping data for table `movies_phrases`
--

INSERT INTO `movies_phrases` (`id`, `name`, `value`, `cat`) VALUES
(3, 'the_movies_count', 'عدد الأفلام', 'main'),
(1455, 'movie_actors_max', 'عدد الممثلين في صفحة الفيلم', 'cp'),
(5, 'last_update', 'آخر تحديث', 'main'),
(1454, 'movie_actors_cells', 'عدد اعمدة ممثلين الفيلم', 'cp'),
(9, 'download', 'تحميل', 'main'),
(12, 'send2friend', 'ارسال لصديق', 'main'),
(14, 'watch', 'مشاهدة', 'main'),
(15, 'vote_video', 'تقييم الفيلم', 'main'),
(1453, 'actors_per_page', 'عدد الممثلين في الصفحة الواحدة', 'cp'),
(1452, 'movie_subtitles_list_max', 'عدد الترجمات الظاهرة في صفحة الفيلم', 'cp'),
(20, 'err_no_videos', 'لا توجد أفلام تحت هذا القسم', 'main'),
(22, 'err_no_cats', 'عفوا , لا توجد اقسام هنا', 'main'),
(1451, 'movie_files_list_max', 'عدد الملفات الظاهرة في صفحة الفيلم', 'cp'),
(1450, 'movie_photos_max', 'عدد الصور في صفحة الفيلم', 'cp'),
(39, 'subtitles', 'الترجمات', 'main'),
(1449, 'عدد أعمدة صور الفيلم', 'movie_photos_cells', 'cp'),
(38, 'err_no_subtitles', 'لا توجد ترجمات', 'main'),
(29, 'vote_video_thnx_msg', 'شكرا لك .. لقد تم تقييم الفيلم', 'main'),
(1448, 'movie_subtitles_list_ajax', 'اظهار قائمة ترجمات الفيلم بنظام Ajax', 'cp'),
(1447, 'movie_files_list_ajax', 'اظهار قائمة ملفات الفيلم بنظام Ajax', 'cp'),
(1446, 'movies_perpage', 'عدد الأفلام في الصفحة الواحدة', 'cp'),
(1445, 'movies_add_fields', 'عدد الحقول في اضافة الأفلام', 'cp'),
(1289, 'rating_expire_msg', 'عفوا , يمكنك التقييم كل {hours} ساعة', 'cp'),
(46, 'the_files_count', 'عدد الملفات', 'main'),
(1444, 'show_movies_in_groups', 'عرض الافلام في مجموعات', 'cp'),
(48, 'home_page', 'الرئيسية', 'main'),
(49, 'movie_pictures', 'صور من الفيلم', 'main'),
(50, 'back_to_news', 'الرجوع الى الأخبار', 'main'),
(1442, 'no_banners', 'لا توجد اعلانات', 'cp'),
(1440, 'movies_list', 'قائمة الافلام', 'cp'),
(1441, 'the_movie', 'الفيلم', 'cp'),
(1438, 'watch_for_members', 'المشاهدة للاعضاء فقط', 'cp'),
(1439, 'download_for_members', 'التحميل للاعضاء فقط', 'cp'),
(1437, 'cat_del_warn', 'حذف هذا القسم سوف يؤدي الى حذف جميع الأقسام و الأفلام التي يحتويها , هل تريد المتابعة ؟', 'cp'),
(1436, 'add_by_name', 'اضافة بواسطة الاسم', 'cp'),
(1434, 'news_votes', 'تقييم الاخبار', 'cp'),
(1435, 'add_by_id', 'اضافة بواسطة الرقم', 'cp'),
(1433, 'news_views', 'زيارات الاخبار', 'cp'),
(1432, 'actors_photos_votes', 'تقييم صور الممثلين', 'cp'),
(64, 'sex', 'الجنس', 'main'),
(65, 'male', 'ذكر', 'main'),
(66, 'female', 'أنثى', 'main'),
(1431, 'actors_photos_views', 'مشاهدات صور الممثلين', 'cp'),
(1430, 'actors_votes', 'تقييم الممثلين', 'cp'),
(1429, 'actors_views', 'مشاهدات الممثلين', 'cp'),
(1428, 'movies_photos_votes', 'تقييم صور الافلام', 'cp'),
(1427, 'movies_photos_views', 'مشاهدة صور الافلام', 'cp'),
(1426, 'movies_votes', 'تقييم الأفلام', 'cp'),
(1425, 'movies_views', 'مشاهدة الافلام', 'cp'),
(1424, 'movies_files_downloads', 'تحميل ملفات الافلام', 'cp'),
(1423, 'movies_files_views', 'مشاهدة ملفات الافلام', 'cp'),
(1422, 'manage_movies_cats', 'إدارة الأقسام و الأفلام', 'cp'),
(1421, 'actor_name', 'اسم الممثل', 'cp'),
(1420, 'actors_list', 'قائمة الممثلين', 'cp'),
(625, 'click_and_drag_to_change_order', 'انقر و اسحب لتغيير الترتيب', 'cp'),
(626, 'access_log', 'سجل الدخول', 'cp'),
(1294, 'comment_is_waiting_admin_review', 'تم اضافة تعليقك و في انتظار موافقة الادارة', 'cp'),
(628, 'contact_us', 'الإتصال بنا', 'main'),
(629, 'no_results', 'لا توجد نتائج', 'main'),
(630, 'search_results', 'نتائج البحث', 'main'),
(631, 'currency_mark', 'علامة العملة', 'cp'),
(633, 'admin_email', 'بريد الادارة', 'cp'),
(634, 'page_description', 'وصف الصفحة', 'cp'),
(635, 'hide_title', 'اخفاء العنوان', 'cp'),
(636, 'err_no_page', 'عفوا , هذه الصفحة غير موجودة', 'main'),
(637, 'type_search_keyword', 'قم بكتابة شيء للبحث عنه لا يقل عن {letters} أحرف', 'main'),
(638, 'the_name', 'الإسم', 'main'),
(639, 'add_date', 'تاريخ الإضافة', 'main'),
(640, 'err_wrong_url', 'رابط خاطيء', 'main'),
(1388, 'page_number_x', 'الصفحة {x}', 'main'),
(642, 'the_details', 'التفاصيل', 'cp'),
(643, 'pages', 'الصفحات', 'main'),
(644, 'the_writer', 'الكاتب', 'main'),
(645, 'the_news_archive', 'أرشيف الأخبار', 'main'),
(647, 'the_price', 'السعر', 'main'),
(648, 'vote_select', 'التقييم', 'main'),
(649, 'vote_do', 'تقييم', 'main'),
(650, 'send2friend_subject', 'دعوة من صديقك', 'main'),
(651, 'send2friend_done', 'لقد تم ارسال الدعوة  لصديقك', 'main'),
(652, 'your_name', 'اسمك', 'main'),
(653, 'your_email', 'بريدك الإلكتروني', 'main'),
(654, 'your_friend_email', 'بريد صديقك', 'main'),
(655, 'send', 'ارسال', 'main'),
(656, 'err_vote_expire_hours', 'عفوا , يمكنك التصويت كل {vote_expire_hours} ساعة', 'main'),
(657, 'add2favorite', 'اضافة الى المفضلة', 'main'),
(658, 'add2fav_success', 'تمت الاضافة الى المفضلة', 'main'),
(659, 'register_closed', 'عفوا , التسجيل مغلق', 'main'),
(660, 'no_news', 'لا توجد أخبار', 'main'),
(1293, 'please_select_movies', 'يرجى اختيار الافلام', 'cp'),
(663, 'the_phrases', 'العبارات', 'cp'),
(664, 'welcome_to_cp', 'أهلا بك في لوحة التحكم', 'cp'),
(665, 'php_version', 'إصدار PHP', 'cp'),
(666, 'mysql_version', 'إصدار MySQL', 'cp'),
(667, 'zend_version', 'إصدار Zend Optimizer', 'cp'),
(668, 'the_version', 'الاصدار', 'cp'),
(669, 'cp_available', 'متوفرة', 'cp'),
(670, 'cp_not_available', 'غير متوفرة', 'cp'),
(671, 'gd_library', 'مكتبة GD', 'cp'),
(672, 'gd_install_required', 'يجب عليك تثبيت مكتبة GD لكي يعمل السكريبت على سيرفرك بشكل جيد', 'cp'),
(673, 'cp_addons', 'الإضافات', 'cp'),
(674, 'no_addons', 'لا توجد اضافات', 'cp'),
(675, 'edit', 'تعديل', 'cp'),
(676, 'register', 'التسجيل', 'main'),
(677, 'register_email_exists', 'خطأ :  هذا البريد موجود مسبقا <br>  اذا كان هذا هو بريدك الالكتروني و نسيبت كلمة المرور', 'main'),
(678, 'register_user_exists', 'عفوا .. اسم المستخدم {username} موجود مسبقا , يرجى استخدام اسم مستخدم آخر', 'main'),
(679, 'reg_complete', 'لقد تم اكمال عملية التسجيل بنجاح .', 'main'),
(681, 'err_fileds_not_complete', 'تأكد من تعبئة جميع الحقول', 'main'),
(682, 'err_passwords_not_match', 'كلمة المرور و تأكيدها غير متطابقين', 'main'),
(683, 'email', 'البريد الالكتروني', 'main'),
(684, 'username', 'اسم المستخدم', 'main'),
(685, 'password', 'كلمة المرور', 'main'),
(686, 'cp_login_do', 'تسجيل الدخول', 'cp'),
(687, 'cp_username', 'اسم المستخدم', 'cp'),
(688, 'cp_password', 'كلمة المرور', 'cp'),
(689, 'the_content_type', 'نوع المحتوى', 'cp'),
(690, 'the_url', 'الرابط', 'cp'),
(691, 'bnr_appearance_places', 'مكان الظهور', 'cp'),
(692, 'bnr_appearance_pages', 'صفحات الظهور', 'cp'),
(693, 'add_after_menu_number', 'اضافة بعد قائمة رقم', 'cp'),
(694, 'login_do', 'تسجيل الدخول', 'cp'),
(695, 'bnr_ctype_code', 'كود', 'cp'),
(696, 'bnr_ctype_img', 'صورة / رابط', 'cp'),
(697, 'the_code', 'الكود', 'cp'),
(698, 'bnr_open', 'بانر فتحة', 'cp'),
(699, 'bnr_close', 'بانر قفلة', 'cp'),
(700, 'bnr_menu', 'اعلان قائمة', 'cp'),
(701, 'bnr_header', 'بانر هيدر', 'cp'),
(702, 'bnr_footer', 'بانر فوتر', 'cp'),
(703, 'bnr_menu_pos', 'في', 'cp'),
(704, 'the_left', 'اليسار', 'cp'),
(705, 'the_center', 'الوسط', 'cp'),
(706, 'the_right', 'اليمين', 'cp'),
(707, 'bnr_the_menu', 'القائمة', 'cp'),
(708, 'bnr_the_visits', 'الزيارات', 'cp'),
(709, 'bnr_appearance_count', 'مرات الظهور', 'cp'),
(710, 'add_button', 'اضافة', 'cp'),
(711, 'the_order', 'الترتيب', 'cp'),
(712, 'the_image', 'الصورة', 'cp'),
(713, 'the_title', 'العنوان', 'cp'),
(714, 'delete', 'حذف', 'cp'),
(715, 'pages_lang', 'لغة الصفحات', 'cp'),
(716, 'pages_encoding', 'ترميز الصفحات', 'cp'),
(717, 'cp_enable_browsing', 'تصفح الموقع', 'cp'),
(718, 'cp_opened', 'مفتوح', 'cp'),
(719, 'cp_closed', 'مغلق', 'cp'),
(720, 'cp_browsing_closing_msg', 'رسالة الإغلاق', 'cp'),
(721, 'site_closed_for_visitors', 'الموقع مغلق للزوار', 'main'),
(722, 'cp_mailing_sending_to', 'مراسلة', 'cp'),
(723, 'cp_send_as', 'إرسال كـ', 'cp'),
(724, 'cp_as_email', 'بريد الكتروني', 'cp'),
(725, 'next_page', 'الصفحة التالية', 'cp'),
(726, 'failed', 'فشل', 'cp'),
(727, 'cp_as_pm', 'رسالة خاصة', 'cp'),
(728, 'cp_send_to', 'إرسال الى', 'cp'),
(729, 'all_members', 'جميع الاعضاء', 'cp'),
(730, 'one_member', 'عضو محدد', 'cp'),
(731, 'sender_name', 'اسم المرسل', 'cp'),
(732, 'sender_email', 'بريد المرسل', 'cp'),
(733, 'msg_type', 'نوع الرسالة', 'cp'),
(734, 'msg_encoding', 'ترميز الرسالة', 'cp'),
(735, 'msg_subject', 'موضوع الرسالة', 'cp'),
(736, 'start_from', 'البدء من', 'cp'),
(737, 'mailing_emails_perpage', 'العدد كل صفحة', 'cp'),
(738, 'auto_pages_redirection', 'انتقال تلقائي بين الصفحات', 'cp'),
(739, 'cp_url_fopen_disabled_msg', 'اعدادات السيرفر لا تسمح بسحب ملف عن طريق رابط خارجي', 'cp'),
(740, 'err_url_x_invalid', 'الرابط {url} غير صحيح', 'cp'),
(741, 'local_file_uploader', 'رفع من الجهاز', 'cp'),
(742, 'external_file_uploader', 'سحب من رابط خارجي', 'cp'),
(743, 'cp_photo_resize_width', 'عرض', 'cp'),
(744, 'cp_photo_resize_hieght', 'طول', 'cp'),
(745, 'view', 'عرض', 'cp'),
(746, 'members_mailing', 'مراسلة الاعضاء', 'cp'),
(747, 'yes', 'نعم', 'main'),
(748, 'no', 'لا', 'main'),
(749, 'cp_mng_members', 'ادارة الاعضاء', 'cp'),
(750, 'members_custom_fields', 'الخانات الاضافية للأعضاء', 'cp'),
(751, 'cp_members_remote_db', 'قاعدة بيانات خارجية', 'cp'),
(752, 'the_members', 'الأعضاء', 'cp'),
(753, 'cp_add_new_template', 'اضافة قالب جديد', 'cp'),
(754, 'the_description', 'الوصف', 'cp'),
(755, 'cp_edit_templates', 'تعديل القوالب', 'cp'),
(756, 'main_page', 'الرئيسية', 'cp'),
(757, 'the_templates', 'القوالب', 'cp'),
(758, 'style_settings', 'اعدادات', 'cp'),
(759, 'add_style', 'اضافة ستايل جديد', 'cp'),
(760, 'style_selectable', 'يمكن للزوار اختياره', 'cp'),
(761, 'template_name', 'اسم القالب', 'cp'),
(762, 'template_description', 'وصف القالب', 'cp'),
(763, 'add_new_template', 'اضافة قالب جديد', 'cp'),
(764, 'are_you_sure', 'هل انت متأكد ؟', 'cp'),
(765, 'the_database', 'قاعدة البيانات', 'cp'),
(766, 'backup', 'نسخة احتياطية', 'cp'),
(767, 'db_repair_tables_do', 'اصلاح الجداول', 'cp'),
(768, 'cp_db_backup_do', 'اخذ نسخة احتياطية الآن', 'cp'),
(769, 'the_file_path', 'مسار الملف', 'cp'),
(770, 'db_backup_saveto_server', 'حفظ النسخة في السيرفر', 'cp'),
(771, 'db_backup_saveto_pc', 'حفظ النسخة الى الجهاز', 'cp'),
(772, 'cp_db_backup', 'نسخة احتياطية من قاعدة البيانات', 'cp'),
(773, 'the_size', 'الحجم', 'cp'),
(774, 'the_table', 'الجدول', 'cp'),
(775, 'the_status', 'الحالة', 'cp'),
(776, 'please_select_tables_to_rapair', 'يرجى اختيار الجداول المراد اصلاحها', 'cp'),
(777, 'cp_repairing_table', 'إصلاح الجدول', 'cp'),
(778, 'done', 'تم', 'cp'),
(779, 'cp_db_check_repair', 'فحص / اصلاح', 'cp'),
(780, 'backup_done_successfully', 'تمت العملية بنجاح', 'cp'),
(781, 'the_search', 'البحث', 'cp'),
(782, 'members_count', 'عدد الأعضاء', 'cp'),
(783, 'cp_remote_members_db', 'قاعدة بيانات أعضاء خارجية', 'cp'),
(784, 'use_remote_db', 'استخدام قاعدة بيانات خارجية', 'cp'),
(785, 'db_host', 'عنوان السيرفر', 'cp'),
(786, 'db_name', 'اسم قاعدة البيانات', 'cp'),
(787, 'db_username', 'اسم مستخدم البيانات', 'cp'),
(788, 'members_table', 'جدول الأعضاء', 'cp'),
(789, 'note', 'ملاحظة', 'cp'),
(790, 'members_remote_db_wizzard_note', 'عند استخدام قاعدة بيانات أعضاء جديدة يجب عليك استخدام معالج قواعد بيانات الأعضاء للتأكد من توافق قاعدة البيانات و اعدادها للعمل', 'cp'),
(791, 'members_remote_db_wizzard', 'معالج قواعد بيانات الأعضاء', 'cp'),
(792, 'chng_field_type_success', 'تم تغيير نوع الخانة في قاعدة البيانات بنجاح', 'cp'),
(793, 'chng_field_type_failed', 'لم يتمكن السكريبت من تغيير نوع الخانة , يرجى تغييرها يدويا من مدير قاعدة البيانات', 'cp'),
(794, 'add_field_failed', 'لم يتمكن السكريبت من اضافة الخانة , يرجى اضافتها يدويا من مدير قاعدة البيانات', 'cp'),
(795, 'add_field_success', 'تمت اضافة الخانة الى قاعدة البيانات بنجاح', 'cp'),
(796, 'members_remote_db_compatible', 'قاعدة البيانات متوافقة مع السكريبت', 'cp'),
(797, 'members_remote_db_uncompatible', 'قاعدة البيانات غير متوافقة مع السكريبت , يرجى مراجعة الأخطاء و اصلاحهم ثم اعادة الاختبار', 'cp'),
(798, 'wrong_remote_db_name', 'اسم قاعدة البيانات خاطيء , يرجى التأكد منه', 'cp'),
(799, 'wrong_remote_db_connect_info', 'خطأ اثناء الاتصال بالقاعدة , يرجى التأكد من بيانات الاتصال', 'cp'),
(800, 'members_remote_db_disabled', 'النظام غير مفعل', 'cp'),
(801, 'no_members_custom_fields', 'لا توجد خانات اضافية', 'cp'),
(802, 'add_member_custom_field', 'اضافة خانة اضافية', 'cp'),
(803, 'the_type', 'النوع', 'cp'),
(804, 'textbox', 'نص', 'cp'),
(805, 'textarea', 'صندوق نص متعدد الاسطر', 'cp'),
(806, 'select_menu', 'قائمة اختيار', 'cp'),
(807, 'radio_button', 'زر اختيار', 'cp'),
(808, 'checkbox', 'خانة اختيار متعدد', 'cp'),
(809, 'default_value', 'القيمة الافتراضية', 'cp'),
(810, 'put_every_option_in_sep_line', 'للخيارات يتم وضع كل خيار في سطر جديد', 'cp'),
(811, 'required', 'مطلوب', 'cp'),
(812, 'addition_style', 'تنسيق اضافي', 'cp'),
(813, 'addition_fields', 'معلومات اضافية', 'cp'),
(814, 'this_member_not_exists', 'هذا العضو غير موجود', 'cp'),
(815, 'members_local_db_clean_wizzard', 'معالج تنظيف جداول الأعضاء المحلية', 'cp'),
(816, 'members_local_db_clean_note', 'عند استخدام قاعدة بيانات محلية او خارجية يتم تخزين بيانات الخانات الاضافية و المفضلة و الرسائل الخاصة و غيرها على بعض الجداول في قاعدة البيانات المحلية , لذلك يفضل تنظيف هذه الجدوال لتسريع عمل القاعدة و تجنبا لعدم حصول اي تداخل في البيانات', 'cp'),
(817, 'members_local_db_clean_description', 'سوف يقوم المعالج بحذف اي بينات تتعلق بالأعضاء كما هو موضح , يرجى التأكد ان الجداول التالية لا تحتوي على اي بيانات ضرورية ثم الضغط على زر التنفيذ', 'cp'),
(818, 'members_msgs_table', 'جدول رسائل الأعضاء الخاصة', 'cp'),
(819, 'members_favorite_table', 'جدول بيانات الملفات المفضلة للأعضاء', 'cp'),
(820, 'members_custom_fields_table', 'جدول بيانات الخانات الاضافية للأعضاء', 'cp'),
(821, 'members_confirmations_table', 'جدول تأكيدات التغيرات للأعضاء', 'cp'),
(822, 'process_done_successfully', 'تمت العملية بنجاح', 'cp'),
(823, 'from', 'من', 'cp'),
(824, 'plz_enter_username_and_pwd', 'يرجى التأكد من ادخال اسم المستخدم وكلمة المرور', 'main'),
(825, 'pwd_rest_request_msg_subject', 'طلب تغيير كلمة المرور', 'cp'),
(826, 'rest_pwd_request_msg_sent', 'تم ارسال رسالة الى بريدك الالكتروني تحتوي رابط تغيير كلمة المرور', 'cp'),
(827, 'pwd_rest_done_msg_subject', 'كلمة مرورك الجديدة !', 'cp'),
(828, 'pwd_rest_done', 'لقد تم تغيير كلمة مرورك و ارسال كلمة المرور الجديدة الى بريدك الالكتروني', 'cp'),
(829, 'security_code', 'كود التحقق', 'cp'),
(830, 'email_activation_msg_subject', 'تفعيل بريدك الالكتروني', 'cp'),
(831, 'upload_file', 'رفع ملف', 'cp'),
(832, 'search_do', 'بحث', 'cp'),
(833, 'birth', 'تاريخ الميلاد', 'main'),
(834, 'country', 'الدولة', 'main'),
(835, 'select_from_menu', 'اختر من القائمة', 'main'),
(836, 'register_do', 'تسجيل', 'main'),
(837, 'registered_before', 'انت مسجل لدينا مسبقا', 'main'),
(838, 'click_here', 'اضغط هنا', 'main'),
(839, 'forgot_pass', 'نسيت كلمة المرور ؟', 'main'),
(840, 'login_info_sent', 'لقد تم ارسال معلومات الدخول الى بريدك الالكتروني', 'main'),
(841, 'email_not_exists', 'خطأ : هذا البريد غير مسجل لدينا', 'main'),
(842, 'continue', 'متابعة', 'main'),
(843, 'active_account', 'تفعيل الاشتراك', 'main'),
(844, 'active_acc_succ', 'لقد تم تفعيل اشتراكك بنجاح', 'main'),
(845, 'active_acc_err', 'عفوا .. لم يتم التفعيل , قد يكون تم تفعيله مسبقا أو هنالك خطأ في الرابط', 'main'),
(846, 'login', 'تسجيل دخول', 'main'),
(847, 'newuser', 'مستخدم جديد ؟', 'main'),
(848, 'err_function_usage_denied', 'خطأ : لا يمكنك استعمال الدالة', 'main'),
(849, 'err_emails_not_match', 'البريد الإلكتروني و تأكيده غير متطابقين', 'main'),
(850, 'email_confirm', 'تأكيد البريد الإلكتروني', 'main'),
(851, 'err_sec_code_not_valid', 'كود التحقق غير صحيح', 'main'),
(852, 'registration', 'التسجيل', 'cp'),
(853, 'as_every_cat_settings', 'اعدادات كل قسم', 'cp'),
(854, 'enabled_for_all', 'مفعل للكل', 'cp'),
(855, 'security_code_in_registration', 'كود التحقق في التسجيل', 'cp'),
(856, 'auto_email_activate', 'تفعيل البريد الالكتروني تلقائيا', 'cp'),
(857, 'username_min_letters', 'اقل عدد حروف لإسم المستخدم', 'cp'),
(858, 'username_exludes', 'استثنائات اسم المستخدم', 'cp'),
(859, 'emails_msgs_default_type', 'نوع رسائل البريد الالكتروني الافتراضية', 'cp'),
(860, 'emails_msgs_default_encoding', 'ترميز رسائل البريد الالكتروني الافتراضية', 'cp'),
(861, 'leave_blank_to_use_site_encoding', 'اتركه فارغا لإستخدام ترميز الموقع الافتراضي', 'cp'),
(862, 'uploader_system', 'نظام رفع الملفات', 'cp'),
(863, 'disable_uploader_msg', 'رسالة عدم التفعيل', 'cp'),
(864, 'uploader_path', 'مسار الرفع', 'cp'),
(865, 'uploader_allowed_types', 'الأنواع المسموح رفعها', 'cp'),
(866, 'enabled', 'مفعل', 'cp'),
(867, 'disabled', 'معطل', 'cp'),
(868, 'password_confirm', 'تأكيد كلمة المرور', 'main'),
(869, 'err_username_min_letters', 'عدد حروف اسم المستخدم اقل من المسموح به', 'main'),
(870, 'err_email_not_valid', 'البريد الالكتروني غير صحيح', 'main'),
(871, 'err_username_not_allowed', 'اسم المستخدم غير مسموح به', 'main'),
(872, 'reg_complete_need_activation', 'لقد تم اكمال عملية التسجيل بنجاح . سوف يتم ارسال رسالة الى بريد الالكتروني تحتوي على رابط تفعيل اشتراكك', 'main'),
(873, 'req_addition_info', 'معلومات اضافية مطلوبة', 'main'),
(874, 'not_req_addition_info', 'معلومات غير مطلوبة', 'main'),
(875, 'your_email_changed_successfully', 'تم تغيير بريدك الالكتروني بنجاح', 'main'),
(876, 'this_account_already_activated', 'عفوا , هذا الحساب تم تفعيله مسبقا', 'main'),
(877, 'closed_account_cannot_activate', 'عفوا, هذا الحساب مغلق لا يمكنك تفعيله', 'main'),
(878, 'activation_msg_sent_successfully', 'لقد تم ارسال رسالة تفعيل الاشتراك الى بريدك الالكتروني بنجاح', 'main'),
(879, 'register_date', 'تاريخ التسجيل', 'cp'),
(880, 'last_login', 'آخر دخول', 'cp'),
(882, 'member_added_successfully', 'تم اضافة العضو بنجاح', 'cp'),
(883, 'please_fill_all_fields', 'يرجى اكمال جميع الحقول', 'cp'),
(884, 'member_edited_successfully', 'تم تعديل العضو بنجاح', 'cp'),
(885, 'add_member', 'اضافة عضو', 'cp'),
(886, 'records_perpage', 'السجلات في الصفحة', 'cp'),
(887, 'member_edit', 'تعديل العضو', 'cp'),
(888, 'member_acc_type', 'نوع الحساب', 'cp'),
(1307, 'pages_links_settings', 'اعدادات روابط الصفحات', 'cp'),
(890, 'acc_type_not_activated', 'غير منشط', 'cp'),
(891, 'acc_type_activated', 'مفعل', 'cp'),
(892, 'acc_type_closed', 'مغلق', 'cp'),
(893, 'leave_blank_for_no_change', 'أتركه فارغا لعدم التغيير', 'cp'),
(894, 'this_account_closed_cant_login', 'عفوا, هذا الحساب مغلق , غير مصرح لك بالدخول', 'main'),
(895, 'this_account_not_activated', 'خطأ , لم يتم تفعيل العضوية بعد', 'main'),
(896, 'chng_email_msg_subject', 'تأكيد تغيير بريدك الإلكتروني', 'main'),
(897, 'resend_activation_msg', 'اعادة ارسال رسالة التفعيل', 'main'),
(898, 'invalid_pwd', 'خطأ, كلمة المرور غير صحيحة', 'main'),
(899, 'invalid_username', 'خطأ, اسم المستخدم غير صحيح', 'main'),
(900, 'usercp_menu', 'قائمة التحكم', 'main'),
(901, 'usercp_welcome_msg', 'أهلا بك يا {username} في لوحة التحكم', 'main'),
(902, 'cp_hooks_fix_order', 'ترتيب تلقائي', 'cp'),
(903, 'cp_hooks', 'الاضافات البرمجية المدمجة', 'cp'),
(904, 'no_hooks', 'لا توجد اضافات', 'cp'),
(905, 'add', 'اضافة', 'cp'),
(906, 'the_place', 'المكان', 'cp'),
(907, 'the_options', 'الخيارات', 'cp'),
(908, 'the_default_template', 'القالب الافتراضي', 'cp'),
(910, 'the_news', 'الأخبار', 'cp'),
(911, 'the_votes', 'الاستفتائات', 'cp'),
(912, 'the_statics', 'الاحصائيات', 'cp'),
(913, 'appearance_places', 'أماكن الظهور', 'cp'),
(914, 'the_blocks', 'القوائم', 'cp'),
(915, 'the_position', 'الموقع', 'cp'),
(916, 'right', 'يمين', 'cp'),
(917, 'center', 'وسط', 'cp'),
(918, 'left', 'يسار', 'cp'),
(919, 'the_template', 'القالب', 'cp'),
(920, 'to_up', 'الى الأعلى', 'cp'),
(921, 'to_down', 'الى الأسفل', 'cp'),
(922, 'enable', 'تنشيط', 'cp'),
(923, 'disable', 'تعطيل', 'cp'),
(924, 'cp_blocks_fix_order', 'تصحيح ترتيب القوائم تلقائيا', 'cp'),
(925, 'cp_no_blocks', 'لا توجد قوائم', 'cp'),
(926, 'the_content', 'المحتوى', 'cp'),
(927, 'logout', 'تسجيل خروج', 'cp'),
(928, 'the_settings', 'الإعدادات', 'cp'),
(929, 'do_button', 'تنفيذ', 'cp'),
(930, 'news_add', 'اضافة خبر', 'cp'),
(931, 'news_short_content', 'النص الخارجي', 'cp'),
(932, 'auto_short_content_create', 'انشاء النص الخارجي تلقائيا', 'cp'),
(933, 'the_date', 'التاريخ', 'main'),
(934, 'all', 'الكل', 'main'),
(935, 'view_do', 'عرض', 'main'),
(936, 'os_and_browsers_statics', 'احصائيات المتصفحات و النظم', 'cp'),
(937, 'visitors_hits_statics', 'احصائيات زيارات الزوار', 'cp'),
(938, 'online_visitors_statics', 'احصائيات المتواجدون الآن', 'cp'),
(939, 'default_style', 'الستايل الافتراضي', 'cp'),
(940, 'search_min_letters', 'أقل عدد للأحرف في البحث', 'cp'),
(941, 'sorry_search_disabled', 'نأسف لك , لقد قامت الادارة بتعطيل البحث', 'main'),
(942, 'uploader_title', 'رفع الملفات', 'cp'),
(943, 'pixel', 'بيكسل', 'cp'),
(944, 'this_filetype_not_allowed', 'نوع الملف غير مسموح به', 'cp'),
(945, 'the_file', 'الملف', 'cp'),
(946, 'auto_photos_resize', 'تصغير تلقائي للصور', 'cp'),
(947, 'upload_file_do', 'رفع الملف', 'cp'),
(948, 'allowed_filetypes', 'الأنواع المسموح رفعها', 'cp'),
(949, 'please_login_first', 'يرجى تسجيل الدخول اولا', 'cp'),
(950, 'uploader_thumb_width', 'عرض المصغرة الافتراضي', 'cp'),
(951, 'uploader_thumb_hieght', 'طول المصغرة الافتراضي', 'cp'),
(952, 'fixed', 'ثابت', 'cp'),
(953, 'send2friend_failed', 'خطأ أثناء الارسال .. حاول مرة اخرى', 'main'),
(954, 'invalid_from_or_to_email', 'يرجى التأكد من صحة بريدك او بريد صديقك الالكتروني', 'main'),
(955, 'urls_fields_add', 'اضافة رابط اضافي', 'cp'),
(956, 'access_denied', 'غير مصرح بالدخول', 'cp'),
(1305, 'seo_settings', 'اعدادات SEO', 'cp'),
(1306, 'pages_meta_settings', 'اعدادات بيانات الصفحات', 'cp'),
(958, 'the_cat', 'القسم', 'cp'),
(959, 'show_paid_option', 'اظهار خيار تم الدفع', 'cp'),
(960, 'no_new_files', 'لا توجد ملفات جديدة', 'cp'),
(961, 'err_autosearch_folder_not_exists', 'مجلد البحث التلقائي غير صحيح , يرجى التأكد من اسم المجلد و التجربة مرة اخرى', 'cp'),
(962, 'auto_search', 'البحث التلقائي', 'cp'),
(1413, 'months_ago', 'شهر', 'main'),
(1414, 'weeks_ago', 'اسبوع', 'main'),
(964, 'images_folder', 'مجلد الصور', 'cp'),
(965, 'edit_templates', 'تعديل القوالب', 'cp'),
(966, 'the_banners', 'الاعلانات', 'cp'),
(967, 'users_and_permissions', 'المستخدمين و التصاريح', 'cp'),
(968, 'permissions_manage', 'ادارة التصاريح', 'cp'),
(969, 'cp_sections_permissions', 'صلاحيات الدخول للأقسام', 'cp'),
(971, 'cp_err_username_exists', 'خطأ .. اسم المستخدم الذي قمت بإدخاله موجود مسبقا', 'cp'),
(972, 'cp_plz_enter_usr_pwd', 'يرجى ادخال اسم المستخدم و كلمة المرور', 'cp'),
(973, 'cp_edit_user_success', 'تم تعديل المستخدم بنجاح', 'cp'),
(974, 'cp_add_user', 'اضافة مستخدم', 'cp'),
(975, 'cp_email', 'البريد الإلكتروني', 'cp'),
(976, 'cp_user_group', 'الرتبة', 'cp'),
(977, 'cp_user_admin', 'مدير', 'cp'),
(978, 'cp_user_mod', 'مشرف', 'cp'),
(979, 'the_users', 'المستخدمين', 'cp'),
(980, 'edit_personal_acc_only', 'صلاحياتك لا تسمح إلا بتعديل حسابك الشخصي فقط', 'cp'),
(981, 'click_here_to_edit_ur_account', 'لتعديل حسابك إضغط هنا', 'cp'),
(982, 'the_pages', 'الصفحات', 'cp'),
(983, 'pages_add', 'اضافة صفحة', 'cp'),
(984, 'no_pages', 'لا توجد صفحات', 'cp'),
(985, 'err_cat_access_denied', 'لاتملك الصلاحيات للدخول الى هذ القسم', 'cp'),
(986, 'you_can_edit_this_values_from_config_file', 'يمكنك تعديل هذه القيم من ملف الاعدادات config.php', 'cp'),
(987, 'no_data', 'لا توجد بيانات', 'cp'),
(989, 'field_style', 'تنسيق اضافي', 'cp'),
(991, 'asc', 'تصاعديا', 'cp'),
(992, 'desc', 'تنازليا', 'cp'),
(993, 'payment_methods', 'طرق الدفع', 'cp'),
(994, 'the_most_voted', 'الأكثر تقييما', 'cp'),
(998, 'store_field_add', 'اضافة', 'cp'),
(999, 'new', 'جديد', 'main'),
(1000, 'features', 'المواصفات', 'main'),
(1002, 'fields_options_add_note', 'بعد اضافة الخانة قم بالضغط على خيار التعديل لتعديل الخيارات', 'cp'),
(1003, 'printable_copy', 'نسخة للطباعة', 'main'),
(1004, 'kg', 'كيلوجرام', 'main'),
(1330, 'black_list_note', 'الاعضاء في هذه القائمة لن يتمكنوا من مراسلتك او رؤية ملفك الشخصي', 'main'),
(1006, 'the_favorite', 'المفضلة', 'main'),
(1007, 'no_files', 'لا توجد ملفات', 'main'),
(1008, 'send_new_msg', 'ارسل رسالة جديدة', 'main'),
(1009, 'the_messages', 'الرسائل', 'main'),
(1010, 'used_messages', 'رسالة مستعملة', 'main'),
(1011, 'pm_box_full_warning', 'تحذير : بريدك ممتليء , لن تتمكن من استقبال اي رسائل جديدة', 'main'),
(1012, 'no_messages', 'لا توجد رسائل', 'main'),
(1013, 'the_sender', 'المرسل', 'main'),
(1014, 'the_subject', 'الموضوع', 'main'),
(1015, 'reply', 'رد', 'main'),
(1016, 'err_sendto_pm_box_full', 'خطأ : البريد الذي تحاول الارسال اليه ممتليء', 'main'),
(1017, 'pm_sent_successfully', 'لقد تم ارسال رسالتك بنجاح', 'main'),
(1018, 'err_sendto_username_invalid', 'خطأ .. اسم المستخدم المرسل اليه غير صحيح . يرجى التأكد منه و المحاولة مرة اخرى', 'main'),
(1019, 'the_message', 'الرسالة', 'main'),
(1020, 'chng_email_conf_msg_sent', 'تم ارسال رسالة لك تحتوي رابط تفعيل بريدك الالكتروني الجديد', 'main'),
(1021, 'your_profile_updated_successfully', 'تم تحديث بياناتك بنجاح', 'main'),
(1022, 'the_profile', 'الملف الشخصي', 'main'),
(1023, 'err_wrong_uploader_folder', 'خطأ في مجلد التحميل', 'cp'),
(1024, 'register_email_exists2', 'اذا كان هذا هو بريدك الالكتروني و نسيبت كلمة المرور', 'cp'),
(1025, 'the_statics_and_counters', 'الاحصائيات و العدادات', 'cp'),
(1026, 'cp_visitors_statics', 'احصائيات الزوار', 'cp'),
(1027, 'cp_counters_start_date', 'تاريخ بدء العدادات', 'cp'),
(1028, 'cp_total_visits', 'مجموع الزيارات', 'cp'),
(1029, 'the_hour', 'الساعة', 'cp'),
(1030, 'operating_systems', 'أنظمة التشغيل', 'main'),
(1031, 'the_browsers', 'المتصفحات', 'main'),
(1032, 'monthly_statics_for', 'إحصائيات الزوار الشهرية لعام', 'main'),
(1033, 'daily_statics_for', 'إحصائيات الزوار اليومية لشهر', 'main'),
(1034, 'the_year', 'العام', 'main'),
(1035, 'the_month', 'الشهر', 'main'),
(1036, 'right_to_left', 'من اليمن الى اليسار', 'cp'),
(1037, 'left_to_right', 'من اليسار الى اليمين', 'cp'),
(1038, 'page_dir', 'اتجاه الصفحة', 'cp'),
(1039, 'mailing_email', 'بريد المراسلة', 'cp'),
(1040, 'copyrights_sitename', 'اسم الموقع في نص الحقوق', 'cp'),
(1041, 'section_name', 'اسم القسم', 'cp'),
(1042, 'site_name', 'اسم الموقع', 'cp'),
(1043, 'page_keywords', 'كلمات مساعدة', 'cp'),
(1044, 'votes_expire_time', 'الوقت الفاصل في الاستفتائات', 'cp'),
(1045, 'hour', 'ساعة', 'cp'),
(1046, 'the_weight', 'الوزن', 'main'),
(1047, 'not_available_now', 'غير متوفر حاليا', 'main'),
(1048, 'bnr_views', 'ظهور', 'cp'),
(1049, 'bnr_visits', 'زيارة', 'cp'),
(1050, 'update', 'تحديث', 'main'),
(1051, 'orderby', 'الترتيب حسب', 'main'),
(1052, 'remove_from_fav', 'حذف من المفضلة', 'main'),
(1053, 'to', 'الى', 'main'),
(1054, 'search_in_subcats', 'البحث في الأقسام الفرعية أيضا', 'main'),
(1055, 'enlarge_pic', 'اضغط لتكبير الصورة', 'main'),
(1057, 'not_selected', 'غير محدد', 'main'),
(1058, 'availability', 'التوفر', 'main'),
(1412, 'year_ago', 'سنة', 'main'),
(1061, 'the_cats', 'الأقسام', 'cp'),
(1316, 'for_members_only', 'للأعضاء فقط', 'cp'),
(1064, 'add_cat', 'اضافة قسم', 'cp'),
(1419, 'pm_send_denied', 'عفوا , لا يمكنك مراسلة هذا العضو', 'main'),
(1067, 'default', 'افتراضي', 'cp'),
(1068, 'view_page', 'مشاهدة الصفحة', 'cp'),
(1069, 'vote_add', 'اضافة تصويت جديد', 'cp'),
(1070, 'set_default', 'تعيين افتراضي', 'cp'),
(1071, 'edit_or_options', 'تعديل / خيارات', 'cp'),
(1072, 'add_options', 'اضافة خيارات', 'cp'),
(1404, 'add_to_friends_list', 'اضافة الى قائمة الاصدقاء', 'main'),
(1074, 'images_cells_count', 'عدد أعمدة الصور', 'cp'),
(1075, 'news_perpage', 'عدد الأخبار في الصفحة الواحدة', 'cp'),
(1076, 'back_to_cats', 'الرجوع الى الأقسام', 'cp'),
(1411, 'last_page', 'الصفحة الأخيرة', 'main'),
(1410, 'prev_page', 'الصفحة السابقة', 'main'),
(1080, 'move_from', 'نقل من', 'cp'),
(1081, 'move_to', 'نقل الى', 'cp'),
(1418, 'seconds_ago', 'ثانية', 'main'),
(1083, 'next', 'التالي', 'cp'),
(1084, 'move_do', 'نقل', 'cp'),
(1085, 'redirection_msg', 'جاري التحويل , اذا كان متصفحك لا يدعم التحويل التلقائي', 'main'),
(1086, 'checkout', 'اتمام الشراء', 'main'),
(1087, 'no_payment_gateways_available', 'لا توجد بوابات دفع متوفرة حاليا', 'main'),
(1088, 'select_all', 'تحديد الكل', 'cp'),
(1089, 'select_none', 'الغاء التحديد', 'cp'),
(1090, 'change_comment', 'تغيير التعليق', 'cp'),
(1091, 'payment_gateways', 'بوابات الدفع', 'main'),
(1315, 'download_for_all', 'للجميع', 'cp'),
(1093, 'count', 'عدد', 'main'),
(1292, 'the_subtitles_count', 'عدد الترجمات', 'cp'),
(1095, 'without_comment', 'بدون تعليق', 'cp'),
(1096, 'the_comment', 'التعليق', 'cp'),
(1097, 'fields_count', 'عدد الحقول', 'cp'),
(1098, 'prev_votes', 'استفتائات سابقة', 'main'),
(1099, 'no_options', 'لا توجد خيارات', 'main'),
(1100, 'users_count', 'عدد المستخدمين', 'cp'),
(1101, 'show_sitename_in_subpages', 'اظهار اسم الموقع في الصفحات الفرعية', 'cp'),
(1102, 'show_section_name_in_subpages', 'اظهار اسم القسم في الصفحات الفرعية', 'cp'),
(1103, 'bill_payment', 'دفع الفاتورة', 'main'),
(1104, 'not_available', 'غير متوفر', 'main'),
(1409, 'first_page', 'الصفحة الأولى', 'main'),
(1106, 'msgs_count_limit', 'حد الرسائل الخاصة', 'cp'),
(1107, 'message', 'رسالة', 'cp'),
(1108, 'paid', 'تم الدفع', 'main'),
(1408, 'for_no_one', 'لا احد', 'main'),
(1407, 'for_any_one', 'الكل', 'main'),
(1111, 'the_invoice', 'الفاتورة', 'main'),
(1113, 'payment_method', 'طريقة الدفع', 'main'),
(1115, 'ram_banner_width', 'عرض نافذة الاعلانات', 'cp'),
(1116, 'ram_banner_height', 'طول نافذة الاعلانات', 'cp'),
(1119, 'not_saved', 'غير محفوظ', 'main'),
(1417, 'minutes_ago', 'دقيقة', 'main'),
(1122, 'telephone', 'رقم الاتصال', 'main'),
(1416, 'hours_ago', 'ساعة', 'main'),
(1124, 'city', 'المدينة', 'main'),
(1415, 'days_ago', 'يوم', 'main'),
(1127, 'the_count', 'العدد', 'main'),
(1129, 'the_total', 'الاجمالي', 'main'),
(1291, 'the_director', 'المخرج', 'cp'),
(1131, 'err_invalid_id', '<b>خطأ : </b> يرجى التأكد من الرقم', 'cp'),
(1132, 'the_id', 'الرقم', 'cp'),
(1133, 'without_title', 'بدون عنوان', 'cp'),
(1134, 'cp_rest_counters', 'تصفير العدادات', 'cp'),
(1135, 'cp_rest_counters_do', 'تصفير العدادات', 'cp'),
(1136, 'visitors_statics_rest_done', 'تم تصفير عدادات الزوار', 'cp'),
(1137, 'cp_no_phrases', 'لا توجد عبارات', 'cp'),
(1138, 'cp_no_templates', 'لا توجد قوالب', 'cp'),
(1139, 'cp_invalid_pwd', 'كلمة المرور غير صحيحة', 'cp'),
(1140, 'cp_invalid_username', 'اسم المستخدم غير صحيح', 'cp'),
(1141, 'cp_welcome_msg', 'أهلا و سهلا بك يا {username}', 'cp'),
(1142, 'cp_statics', 'احصائيات', 'cp'),
(1143, 'search', 'بحث', 'cp'),
(1144, 'forgot_pwd_msg_subject', 'استرجاع كلمة المرور', 'cp'),
(1145, 'without_selection', 'بدون اختيار', 'cp'),
(1146, 'create_main_user', 'انشاء المستخدم الرئيسي', 'cp'),
(1317, 'gender', 'الجنس', 'main'),
(1148, 'tabbed_to', 'القائمة الرئيسية', 'cp'),
(1149, 'without_tabbed_menu', 'بدون قائمة رئيسية', 'cp'),
(1150, 'prev', 'السابق', 'main'),
(1151, 'offers_menu', 'قائمة العروض', 'main'),
(1313, 'default_value_or_options', 'القيمة الافتراضية / الخيارات', 'cp'),
(1312, 'send_msg_to_member', 'مراسلة العضو', 'cp'),
(1154, 'show_prev_votes', 'عرض الاستفتائات السابقة', 'cp'),
(1156, 'max_count', 'اقصى عدد', 'cp'),
(1157, 'random', 'عشوائي', 'cp'),
(1158, 'cats_permissions', 'تصاريح الاقسام', 'cp'),
(1159, 'cats_permissions_note', 'يمكنك ادارة تصاريح الاقسام للمشرفين بالضغط على رابط تعديل القسم و تحديد المشرفين له', 'cp'),
(1160, 'store_fields_note', 'يتم اعداد المواصفات و التفاصيل لكل قسم من خلال رابط تعديل القسم', 'cp'),
(1406, 'for_friends_only', 'الاصدقاء فقط', 'main'),
(1405, 'add_to_black_list', 'اضافة الى قائمة التجاهل', 'main'),
(1165, 'other', 'غير ذلك', 'main'),
(1303, 'manage_movie_meta', 'اعداد بيانات الصفحة', 'cp'),
(1304, 'leave_blank_to_use_default_settings', 'اتركه فارغ لاستخدام الاعدادات الافتراضية', 'cp'),
(1299, 'activate', 'تفعيل', 'cp'),
(1300, 'the_member', 'العضو', 'main'),
(1356, 'delete_picture', 'حذف الصورة', 'main'),
(1170, 'the_total_price', 'السعر الاجمالي', 'cp'),
(1171, 'update_data', 'تحديث البيانات', 'cp'),
(1172, 'cannot_disable_default_status', 'لا يمكن تعطيل حالة افتراضية', 'cp'),
(1173, 'cannot_delete_default_status', 'لا يمكن حذف حالة افتراضية', 'cp'),
(1176, 'text_color', 'لون النص', 'cp'),
(1177, 'show_payment_options', 'اظهار خيارات دفع الفاتورة', 'cp'),
(1178, 'sending_form_code', 'كود فورم الارسال', 'cp'),
(1179, 'is_gateway', 'بوابة دفع ؟', 'cp'),
(1180, 'short_description', 'الوصف القصير', 'cp'),
(1181, 'fields_search_menu', 'قائمة البحث', 'cp'),
(1182, 'options_edit', 'تعديل الخيارات', 'cp'),
(1183, 'the_value', 'القيمة', 'cp'),
(1184, 'without_main_cat', 'بدون قسم رئيسي', 'cp'),
(1311, 'sent_messages', 'الرسائل الصادرة', 'main'),
(1310, 'received_msgs', 'الرسائل الواردة', 'main'),
(1187, 'move_the_cats', 'نقل الأقسام', 'cp'),
(1188, 'please_select_cats_first', 'يرجى تحديد الاقسام أولا', 'cp'),
(1309, 'add2fav_already_exists', 'هذا الفيلم موجود مسبقا في المفضلة', 'main'),
(1190, 'err_invalid_cat_id', '<b> خطأ : </b> يرجى التأكد من رقم القسم', 'cp'),
(1191, 'err_cats_not_selected', '<b> خطأ : </b> لم يتم تحديد الأقسام', 'cp'),
(1192, 'move', 'نقل', 'cp'),
(1403, 'profile_access_denied', 'عفوا , لا يمكنك مشاهدة هذا الملف الشخصي', 'main'),
(1194, 'the_moderators', 'المشرفين', 'cp'),
(1195, 'page_custom_info', 'بيانات مخصصة للصفحة', 'cp'),
(1196, 'the_page_keywords', 'الكلمات المساعدة', 'cp'),
(1298, 'comment_type', 'نوع التعليق', 'cp'),
(1308, 'add2fav_confirm_msg', 'هل انت متأكد انك تريد اضافة الفيلم "{name}" الى المفضلة', 'main'),
(1201, 'photos_count', 'عدد الصور', 'cp'),
(1301, 'remaining_letters', 'حروف متبقية', 'cp'),
(1296, 'the_comments', 'التعليقات', 'cp'),
(1203, 'add_photos', 'اضافة صور', 'cp'),
(1204, 'no_photos', 'لا توجد صور', 'cp'),
(1205, 'no_moderators', 'لا يوجد مشرفين', 'cp'),
(1206, 'available', 'متوفر', 'cp'),
(1207, 'pay_now', 'ادفع الان', 'main'),
(1295, 'comments_waiting_admin_review', 'تعليقات تنتظر الموافقة', 'cp'),
(1302, 'write_your_comment', 'اكتب تعليقك', 'cp'),
(1210, 'phrases_name_exists', 'لم تتم الاضافة , هذا الاسم مستخدم مسبقا', 'cp'),
(1211, 'the_players', 'المشغلات', 'cp'),
(1212, 'no_players', 'لا توجد مشغلات', 'cp'),
(1213, 'extensions', 'الامتدادات', 'cp'),
(1214, 'players_add', 'اضافة مشغل', 'cp'),
(1215, 'ioncube_version', 'اصدار ionCube', 'cp'),
(1216, 'internal_player', 'المشغل الداخلي', 'cp'),
(1217, 'external_player', 'المشغل الخارجي', 'cp'),
(1218, 'the_download', 'التحميل', 'cp'),
(1219, 'file_name', 'اسم الملف', 'cp'),
(1220, 'the_icon_url', 'رابط الأيقونة', 'cp'),
(1221, 'the_icon_alt', 'عنوان الأيقونة', 'cp'),
(1222, 'use_comma_between_types', 'استخدم فاصلة (Comma) بين الأنواع', 'cp'),
(1223, 'the_movies', 'الافلام', 'main'),
(1224, 'no_cats', 'لا توجد اقسام', 'main'),
(1225, 'add_movie', 'اضافة فيلم', 'cp'),
(1226, 'close', 'اغلاق', 'main'),
(1227, 'no_movies', 'لا توجد افلام', 'main'),
(1228, 'add_to_new_movies_list', 'اضافة الى قائمة جديد السوق', 'cp'),
(1229, 'new_movies_list', 'قائمة جديد السوق', 'cp'),
(1230, 'movie_del_warn', 'حذف هذا الفيلم سوف يؤدي الى حذف جميع ملفات الترجمة و الصور التابعة له , هل تريد المتابعة ؟', 'cp'),
(1231, 'download_url', 'رابط التحميل', 'cp'),
(1232, 'watch_url', 'رابط المشاهدة', 'cp'),
(1233, 'custom_watch_url', 'رابط مشاهدة مخصص', 'cp'),
(1234, 'add_files', 'اضافة ملفات', 'cp'),
(1235, 'browse_movies', 'استعراض الافلام', 'cp'),
(1236, 'movie_info', 'بيانات الفيلم', 'cp'),
(1237, 'members_comments', 'تعلقيات الأعضاء', 'main'),
(1238, 'the_actors', 'الممثلين', 'main'),
(1239, 'no_actors', 'لا يوجد ممثلين', 'main'),
(1240, 'actor_movies', 'افلام الممثل', 'main'),
(1241, 'manage_files', 'ادارة الملفات', 'cp'),
(1242, 'manage_actors', 'ادارة الممثلين', 'cp'),
(1243, 'manage_subtitles', 'ادارة ملفات الترجمة', 'cp'),
(1244, 'manage_photos', 'ادارة الصور', 'cp'),
(1245, 'add_actor', 'اضافة ممثل', 'cp'),
(1246, 'player_view_style', 'طريقة العرض', 'cp'),
(1247, 'player_view_in_page_ajax', 'Ajax في اطار الصفحة', 'cp'),
(1248, 'player_view_dialog_ajax', 'Ajax اطار منبثق', 'cp'),
(1249, 'player_view_ext_page', 'صفحة خارجية', 'cp'),
(1250, 'movie_photos', 'صور الفيلم', 'cp'),
(1251, 'next_photo', 'الصورة التالية', 'cp'),
(1252, 'the_photo', 'الصورة', 'cp'),
(1253, 'prev_photo', 'الصورة السابقة', 'cp'),
(1254, 'full_photo_size', 'الحجم الكامل', 'cp'),
(1443, 'rating_exire_time', 'الوقت الفاصل بين التقييمات', 'cp'),
(1256, 'movie_description', 'وصف الفيلم', 'cp'),
(1257, 'cover_photo', 'صورة الغلاف', 'cp'),
(1258, 'delete_cover', 'حذف الصورة', 'cp'),
(1259, 'movie_files_add', 'اضافة ملفات', 'cp'),
(1260, 'movie_photos_add', 'اضافة صور', 'cp'),
(1261, 'cover_photo_save_error', 'لم يتم حفظ صورة الغلاف , يرجى المحاولة مرة اخرى', 'cp'),
(1262, 'movie_cover_photo', 'صورة غلاف الفيلم', 'cp'),
(1263, 'movie_cover_thumb', 'مصغرة غلاف الفيلم', 'cp'),
(1264, 'movie_cover_thumb_width', 'عرض مصغرة غلاف الفيلم', 'cp'),
(1265, 'movie_cover_thumb_height', 'طول مصغرة غلاف الفيلم', 'cp'),
(1266, 'actor_thumb', 'مصغرة الممثلين', 'main'),
(1267, 'actor_thumb_width', 'عرض مصغرة الممثل', 'main'),
(1268, 'actor_thumb_height', 'طول مصغرة الممثل', 'main'),
(1269, 'actor_photo_save_error', 'لم يتم حفظ الصورة , يرجى المحاولة مرة اخرى', 'main'),
(1270, 'actors_show_in_groups', 'عرض الممثلين في مجموعات حسب الاسم', 'main'),
(1271, 'release_year', 'سنة الأصدار', 'main'),
(1272, 'err', 'خطأ', 'main'),
(1273, 'edit_done', 'تم التعديل', 'cp'),
(1274, 'please_select_photos', 'يرجى اختيار الصور', 'cp'),
(1275, 'actor_photos', 'صور الممثل', 'main'),
(1276, 'actor_photos_add', 'اضافة', 'cp'),
(1277, 'in_this_photo', 'في هذه الصورة', 'main'),
(1278, 'more', 'المزيد', 'main'),
(1279, 'movie_actors', 'ممثلين الفيلم', 'main'),
(1280, 'no_comments', 'لا توجد تعليقات', 'main'),
(1281, 'please_login', 'يرجى تسجل الدخول', 'main'),
(1282, 'err_empty_comment', 'لم يتم كتابة التعليق', 'main'),
(1283, 'older_comments', 'تعليقات أقدم', 'main'),
(1284, 'no_files_selected', 'لم يتم اخيار الملفات', 'main'),
(1285, 'the_files', 'الملفات', 'main'),
(1286, 'activated', 'مفعل', 'cp'),
(1287, 'not_activated', 'غير مفعل', 'cp'),
(1288, 'since', 'منذ', 'cp'),
(1290, 'rating_done', 'تم التقييم', 'cp'),
(1318, 'report_file', 'الابلاغ عن الملف', 'cp'),
(1350, 'comment_is_not_exist', 'التعليق غير موجود', 'cp'),
(1349, 'report_number_x', 'بلاغ رقم', 'cp'),
(1347, 'security_code_in_report', 'كود التحقق', 'main'),
(1348, 'security_code_in_send', 'كود التحقق', 'main'),
(1322, 'err_upload_max_size', 'يرجى التأكد من ان حجم الملف اقل من', 'main'),
(1323, 'photo_not_saved', 'لم يتم حفظ الصورة', 'main'),
(1324, 'new_pm_email_notify', 'ابلاغ بالبريد عند استلام رسالة خاصة جديدة', 'main'),
(1325, 'pm_email_notify_subject', 'رسالة خاصة جديدة', 'main'),
(1326, 'not_classified', 'غير مصنف', 'main'),
(1327, 'sort_by', 'الترتيب حسب', 'main'),
(1328, 'visitors_can_sort_movies', 'امكانية الزوار من اختيار ترتيب الافلام', 'cp'),
(1329, 'movies_default_sort', 'الترتيب الافتراضي للافلام', 'cp'),
(1331, 'online_status', 'التواجد', 'main'),
(1332, 'online', 'متصل', 'main'),
(1333, 'offline', 'غير متصل', 'main'),
(1334, 'movies_fields', 'خانات الافلام الاضافية', 'cp'),
(1335, 'no_movies_fields', 'لا توجد خانات اضافية', 'cp'),
(1336, 'enable_search', 'تفعيل البحث', 'cp'),
(1337, 'add_custom_field', 'اضافة خانة اضافية', 'cp'),
(1338, 'report_sent', 'شكرا لك , تم ابلاغ الادارة', 'main'),
(1339, 'the_explanation', 'التوضيح', 'main'),
(1340, 'new_reports', 'بلاغات جديدة', 'main'),
(1341, 'report_type', 'نوع البلاغ', 'main'),
(1342, 'the_reports', 'البلاغات', 'cp'),
(1343, 'no_reports', 'لا توجد بلاغات', 'cp'),
(1344, 'reports_count', 'عدد البلاغات', 'cp'),
(1345, 'movies_files', 'ملفات الافلام', 'cp'),
(1346, 'report_do', 'ابلاغ عن مخالفة', 'main'),
(1351, 'member_is_not_exist', 'العضو غير موجود', 'cp'),
(1352, 'movie_is_not_exist', 'الفيلم غير موجود', 'cp'),
(1353, 'comment_count', 'عدد التعليقات', 'cp'),
(1354, 'deactivate', 'تعطيل', 'cp'),
(1355, 'profile_picture', 'الصورة الشخصية', 'main'),
(1357, 'profile_preview', 'معاينة الملف الشخصي', 'main'),
(1358, 'views', 'عدد المشاهدات', 'main'),
(1359, 'date_format', 'صيغة التاريخ', 'cp'),
(1360, 'the_counters', 'العدادات', 'cp'),
(1361, 'contactus_send_successfully', 'شكرا لك , تم ارسال الرسالة بنجاح', 'main'),
(1362, 'contactus_send_failed', 'عفوا , حدث خطأ أثناء الارسال يرجى المحاولة مرة اخرى لاحقا', 'main'),
(1363, 'without_subject', 'بدون عنوان', 'main'),
(1364, 'counters_reset', 'تصفير العدادات', 'cp'),
(1365, 'members_connectors', 'ربط الاعضاء', 'cp'),
(1366, 'movies_count', 'عدد الافلام', 'main'),
(1367, 'cats_count', 'عدد الاقسام', 'main'),
(1368, 'files_count', 'عدد الملفات', 'main'),
(1369, 'comments_count', 'عدد التعليقات', 'main'),
(1370, 'visitors_can_send_reports', 'امكانية الزوار من ارسال البلاغات', 'cp'),
(1371, 'general_settings', 'اعدادات عامة', 'cp'),
(1372, 'mailing_settings', 'اعدادات المراسلة', 'cp'),
(1373, 'default_privacy_settings', 'الاعدادات الافتراضية للخصوصية', 'cp'),
(1374, 'pic_width', 'عرض الصورة', 'cp');
INSERT INTO `movies_phrases` (`id`, `name`, `value`, `cat`) VALUES
(1375, 'pic_height', 'طول الصورة', 'cp'),
(1376, 'pic_max_width', 'اقصى عرض للصورة', 'cp'),
(1377, 'pic_max_height', 'اقصى طول للصورة', 'cp'),
(1378, 'thumb_width', 'عرض المصغرة', 'cp'),
(1379, 'thumb_height', 'طول المصغرة', 'cp'),
(1380, 'the_photos', 'الصور', 'cp'),
(1381, 'actor_pic', 'صورة الممثل', 'cp'),
(1382, 'vote_movie', 'تقييم الفيلم', 'cp'),
(1383, 'send_movie', 'ارسال الفيلم لصديق', 'cp'),
(1384, 'movies_order', 'ترتيب الافلام', 'cp'),
(1385, 'news_cat_del_warn', 'حذف هذا القسم سوف يؤدي على حذف جميع الاخبار في داخله , هل تريد المتابعة ؟', 'cp'),
(1386, 'read_more', 'اقرأ المزيد', 'main'),
(1387, 'please_select_news_first', 'يرجى اختيار الاخبار اولا', 'cp'),
(1389, 'movies_photos', 'صور الافلام', 'cp'),
(1390, 'actors_photos', 'صور الممثلين', 'cp'),
(1391, 'time_and_date', 'الوقت و التاريخ', 'cp'),
(1392, 'timezone', 'المنطقة الزمنية', 'cp'),
(1393, 'privacy_settings', 'اعدادات الخصوصية', 'main'),
(1394, 'profile_view', 'مشاهدة الملف الشخصي', 'main'),
(1395, 'fav_movies', 'الافلام المفضلة', 'main'),
(1396, 'receive_pm_from', 'استقبال رسائل خاصة من', 'main'),
(1397, 'this_member_exist_in_list', 'هذا العضو موجود في القائمة مسبقا', 'main'),
(1398, 'add_done_successfully', 'تمت الاضافة بنجاح', 'main'),
(1399, 'friends_list', 'قائمة الاصدقاء', 'main'),
(1400, 'no_friends_in_list', 'لا يوجد اصدقاء في القائمة', 'main'),
(1401, 'black_list', 'قائمة التجاهل', 'main'),
(1402, 'no_members_in_list', 'لا يوجد اعضاء في القائمة', 'main'),
(1456, 'actor_photos_cells', 'عدد أعمدة صور الممثل', 'cp'),
(1457, 'actor_photos_max', 'عدد الصور في صفحة الممثل', 'cp'),
(1458, 'comments_max_letters', 'اقصى عدد حروف', 'cp'),
(1459, 'movies_comments', 'تعليقات على الافلام', 'cp'),
(1460, 'movie_photo_comments', 'نعليقات على عرض صورة الفيلم', 'cp'),
(1461, 'actors_comments', 'تعليقات على الممثل', 'cp'),
(1462, 'actor_photo_comments', 'تعليقات على صورة الممثل', 'cp'),
(1463, 'news_comments', 'تعليقات على الاخبار', 'cp'),
(1464, 'comments_auto_activate', 'تفعيل تلقائي للتعليقات', 'cp'),
(1465, 'show_online_members_count', 'اظهار عدد الاعضاء المتواجدون', 'cp'),
(1466, 'movie_photos_cells', 'عدد أعمدة صور الفيلم', 'cp'),
(1467, 'commets_per_request', 'التعليقات لكل طلب', 'cp');

-- --------------------------------------------------------

--
-- Table structure for table `movies_phrases_cats`
--

CREATE TABLE IF NOT EXISTS `movies_phrases_cats` (
  `id` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movies_phrases_cats`
--

INSERT INTO `movies_phrases_cats` (`id`, `name`) VALUES
('cp', 'لوحة التحكم / النظام'),
('main', 'العبارات العامة');

-- --------------------------------------------------------

--
-- Table structure for table `movies_players`
--

CREATE TABLE IF NOT EXISTS `movies_players` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `int_content` text NOT NULL,
  `exts` varchar(255) NOT NULL default '',
  `int_enabled` int(1) NOT NULL default '0',
  `ext_enabled` int(1) NOT NULL default '0',
  `int_icon` varchar(255) NOT NULL,
  `ext_icon` varchar(255) NOT NULL,
  `int_icon_alt` varchar(255) NOT NULL,
  `ext_icon_alt` varchar(255) NOT NULL,
  `ext_content` text NOT NULL,
  `ext_mime` varchar(100) NOT NULL default '',
  `ext_filename` varchar(255) NOT NULL default '',
  `download_icon` varchar(255) NOT NULL,
  `download_enabled` int(1) NOT NULL default '0',
  `download_icon_alt` varchar(255) NOT NULL,
  `view_style` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `movies_players`
--

INSERT INTO `movies_players` (`id`, `name`, `int_content`, `exts`, `int_enabled`, `ext_enabled`, `int_icon`, `ext_icon`, `int_icon_alt`, `ext_icon_alt`, `ext_content`, `ext_mime`, `ext_filename`, `download_icon`, `download_enabled`, `download_icon_alt`, `view_style`) VALUES
(1, 'المشغل الافتراضي', '<!-- begin embedded RealMedia file... -->\r\n      <table border=''0'' cellpadding=''0'' align="center">\r\n        <!-- begin video window... -->\r\n        <tr><td>\r\n        <OBJECT id=''rvocx'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n        width="500" height="300">\r\n        <param name=''src'' value="{url}">\r\n        <param name=''autostart'' value="true">\r\n        <param name=''controls'' value=''imagewindow''>\r\n        <param name=''console'' value=''video''>\r\n        <param name=''loop'' value="true">\r\n        <EMBED src="{url}" width="500" height="300" \r\n        loop="true" type=''audio/x-pn-realaudio-plugin'' controls=''imagewindow'' console=''video'' autostart="true">\r\n        </EMBED>\r\n        </OBJECT>\r\n        </td></tr>\r\n        <!-- ...end video window -->\r\n          <!-- begin control panel... -->\r\n          <tr><td>\r\n          <OBJECT id=''rvocx'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n          width="500" height=''30''>\r\n          <param name=''src'' value="{url}">\r\n          <param name=''autostart'' value="true">\r\n          <param name=''controls'' value=''ControlPanel''>\r\n          <param name=''console'' value=''video''>\r\n          <EMBED src="{url}" width="500" height=''30'' \r\n          controls=''ControlPanel'' type=''audio/x-pn-realaudio-plugin'' console=''video'' autostart="true">\r\n          </EMBED>\r\n          </OBJECT>\r\n          </td></tr>\r\n          <!-- ...end control panel -->\r\n          <!-- ...end embedded RealMedia file -->\r\n        <!-- begin link to launch external media player... -->\r\n       \r\n      </table>\r\n', '', 1, 0, 'images/watch.gif', 'images/watch.gif', 'مشاهدة ({views} مشاهدة)', 'مشاهدة خارجية ({views} مشاهدة)', '{url}', 'audio/x-pn-realaudio', 'watch.ram', 'images/download.gif', 1, 'تحميل ({downloads} تحميل)', 0),
(2, 'Flash Video Player', '<center>\r\n\r\n<OBJECT id="mpl" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="500" height="300"><PARAM name="movie" value="players/player.swf" /><PARAM name="quality" value="high" /><PARAM name="allowfullscreen" value="true" /><PARAM name="allowscriptaccess" value="always" /><PARAM name="flashvars" value="file={url}&autostart=true" />\r\n\r\n<embed\r\n   src="players/player.swf" \r\n   width="500"\r\n   height="300"\r\n   allowscriptaccess="always"\r\n   allowfullscreen="true"\r\n   id="player1"\r\n   name="player1"\r\n   flashvars="file={url}&dock=true&autostart=true"/>\r\n\r\n</OBJECT>\r\n\r\n\r\n</center>', '.flv,.mp4', 1, 0, 'images/watch.gif', '', 'مشاهدة ({views} مشاهدة)', '', '', '', '', 'images/download.gif', 1, 'تحميل ({downloads} تحميل)', 0),
(3, 'Windows Media Player', '    <table border=''0'' cellpadding=''0'' align="center">\r\n      <tr><td>\r\n      <OBJECT id=''mediaPlayer'' width="400" height="305"\r\n      classid=''CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95''\r\n      codebase=''http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701''\r\n      standby=''Loading Microsoft Windows Media Player components...'' type=''application/x-oleobject''>\r\n      <param name=''fileName'' value="{url}">\r\n      <param name=''animationatStart'' value=''true''>\r\n      <param name=''transparentatStart'' value=''true''>\r\n      <param name=''autoStart'' value="true">\r\n      <param name=''showControls'' value="true">\r\n      <param name=''loop'' value="false">\r\n      <EMBED type=''application/x-mplayer2''\r\n        pluginspage=''http://microsoft.com/windows/mediaplayer/en/download/''\r\n        id=''mediaPlayer'' name=''mediaPlayer'' displaysize=''4'' autosize=''-1''\r\n        bgcolor=''darkblue'' showcontrols="true" showtracker=''-1''\r\n        showdisplay=''0'' showstatusbar=''-1'' videoborder3d=''-1'' width="400" height="305"\r\n        src="{url}" autostart="true" designtimesp=''5311'' loop="false">\r\n      </EMBED>\r\n      </OBJECT>\r\n      </td></tr>\r\n      <!-- ...end embedded WindowsMedia file -->\r\n    <!-- begin link to launch external media player... -->\r\n      \r\n      </table>', '.wmv', 1, 0, 'images/watch.gif', '', 'مشاهدة ({views} مشاهدة)', '', '', '', '', 'images/download.gif', 1, 'تحميل ({downloads} تحميل)', 2),
(4, 'Divx Player', '<center>\r\n<object classid="clsid:67DABFBF-D0AB-41fa-9C46-CC0F21721616" width="600" height="358" codebase="http://go.divx.com/plugin/DivXBrowserPlugin.cab">\r\n  <param name="custommode" value="none" />\r\n  <param name="autoPlay" value="true" />\r\n  <param name="src" value="{url}" />\r\n  <embed type="video/divx"\r\n         src="{url}"\r\n         custommode="none"\r\n         width="600" height="358"\r\n         autoPlay="false"\r\n         pluginspage="http://go.divx.com/plugin/download/">\r\n  </embed>\r\n</object>\r\n', '.avi,.mkv', 1, 0, 'images/watch.gif', '', 'مشاهدة ({views} مشاهدة)', '', '', '', '', 'images/download.gif', 1, 'تحميل ({downloads} تحميل)', 2),
(5, 'YouTube', '<center>\r\n\r\n<OBJECT id="mpl" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="500" height="300"><PARAM name="movie" value="players/player.swf" /><PARAM name="quality" value="high" /><PARAM name="allowfullscreen" value="true" /><PARAM name="allowscriptaccess" value="always" /><PARAM name="flashvars" value="file={url}&autostart=true" />\r\n\r\n<embed\r\n   src="players/player.swf" \r\n   width="500"\r\n   height="300"\r\n   allowscriptaccess="always"\r\n   allowfullscreen="true"\r\n   id="player1"\r\n   name="player1"\r\n   flashvars="file={url}&dock=true"/>\r\n\r\n</OBJECT>\r\n\r\n\r\n</center>', 'youtube.com', 1, 0, 'images/watch.gif', '', 'مشاهدة ({views} مشاهدة)', '', '', '', '', 'images/youtube_watch.png', 1, 'مشاهدة في يوتيوب ({downloads} مشاهدة)', 1),
(6, 'Real Video Player', '<!-- begin embedded RealMedia file... -->\r\n      <table border=''0'' cellpadding=''0'' align="center">\r\n        <!-- begin video window... -->\r\n        <tr><td>\r\n        <OBJECT id=''rvocx'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n        width="500" height="300">\r\n        <param name=''src'' value="{url}">\r\n        <param name=''autostart'' value="true">\r\n        <param name=''controls'' value=''imagewindow''>\r\n        <param name=''console'' value=''video''>\r\n        <param name=''loop'' value="true">\r\n        <EMBED src="{url}" width="500" height="300" \r\n        loop="true" type=''audio/x-pn-realaudio-plugin'' controls=''imagewindow'' console=''video'' autostart="true">\r\n        </EMBED>\r\n        </OBJECT>\r\n        </td></tr>\r\n        <!-- ...end video window -->\r\n          <!-- begin control panel... -->\r\n          <tr><td>\r\n          <OBJECT id=''rvocx'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n          width="500" height=''30''>\r\n          <param name=''src'' value="{url}">\r\n          <param name=''autostart'' value="true">\r\n          <param name=''controls'' value=''ControlPanel''>\r\n          <param name=''console'' value=''video''>\r\n          <EMBED src="{url}" width="500" height=''30'' \r\n          controls=''ControlPanel'' type=''audio/x-pn-realaudio-plugin'' console=''video'' autostart="true">\r\n          </EMBED>\r\n          </OBJECT>\r\n          </td></tr>\r\n          <!-- ...end control panel -->\r\n          <!-- ...end embedded RealMedia file -->\r\n        <!-- begin link to launch external media player... -->\r\n       \r\n      </table>\r\n', '.rm,.rmvb,.rv', 1, 0, 'images/watch.gif', 'images/watch.gif', 'مشاهدة ({views} مشاهدة)', 'مشاهدة خارجية ({views} مشاهدة)', '{url}', 'audio/x-pn-realaudio', 'watch.ram', 'images/download.gif', 1, 'تحميل ({downloads} تحميل)', 0);

-- --------------------------------------------------------

--
-- Table structure for table `movies_reports`
--

CREATE TABLE IF NOT EXISTS `movies_reports` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `report_type` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `date` int(11) NOT NULL,
  `opened` int(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `report_type` (`report_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_reports`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_settings`
--

CREATE TABLE IF NOT EXISTS `movies_settings` (
  `name` varchar(255) NOT NULL default '',
  `value` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movies_settings`
--

INSERT INTO `movies_settings` (`name`, `value`) VALUES
('snd2friend', '1'),
('vote_song', '1'),
('sitename', 'اللوماني'),
('section_name', 'الأفلام v2.0'),
('movies_add_fields', '5'),
('letters_songs', '1'),
('letters_singers', '1'),
('html_dir', 'rtl'),
('header_keywords', 'افلام , movies'),
('uploader', '1'),
('uploader_path', 'uploads'),
('uploader_msg', 'نأسف لك , رفع الملفات غير مفعل في النسخة التجريبية'),
('uploader_types', 'jpg,gif,png,rm,mp3,zip,rar'),
('movies_add_limit', '5'),
('actor_photos_cells', '4'),
('movies_perpage', '30'),
('movies_cells', '4'),
('vote_movie', '1'),
('snd2friend_clip', '1'),
('max_cover_width', '150'),
('max_cover_hieght', '200'),
('movie_photos_cells', '4'),
('mailing_email', 'mailing@{domain_name}'),
('copyrights_sitename', 'اللوماني'),
('votes_expire_hours', '24'),
('vote_file_expire_hours', '24'),
('search_min_letters', '3'),
('msgs_count_limit', '1000'),
('members_register', '1'),
('news_perpage', '20'),
('photo_thumb_width', '100'),
('photo_thumb_height', '100'),
('enable_browsing', '1'),
('disable_browsing_msg', '<center>\r\n نأسف لك , الموقع مغلق حاليا لبعض التعديلات\r\n</center>\r\n'),
('actor_photos_max', '4'),
('uploader_thumb_width', '100'),
('uploader_thumb_hieght', '100'),
('site_pages_encoding', 'utf-8'),
('site_pages_lang', 'ar-sa'),
('default_styleid', '1'),
('section_name_in_subpages', '0'),
('sitename_in_subpages', '1'),
('mailing_default_use_html', '1'),
('mailing_default_encoding', ''),
('enable_comments', '1'),
('comments_auto_activate', '1'),
('photo_resized_height', '720'),
('photo_resized_width', '720'),
('enable_photos_comments', '1'),
('enable_photo_comments', '1'),
('cover_thumb_fixed', '1'),
('movie_cover_thumb_width', '135'),
('movie_cover_thumb_height', '200'),
('actor_thumb_width', '65'),
('actor_thumb_height', '65'),
('actor_thumb_fixed', '1'),
('actors_show_in_groups', '1'),
('comments_bad_words_replacement', '***'),
('comments_bad_words', 'حمار,كلب,سكس,fuck,sex'),
('movie_photos_max', '4'),
('movie_actors_cells', '5'),
('movie_actors_max', '5'),
('actor_img_width', '150'),
('actor_img_height', '200'),
('actor_img_fixed', '1'),
('commets_per_request', '10'),
('movie_files_list_ajax', '0'),
('movie_files_list_max', '10'),
('movie_subtitles_list_ajax', '1'),
('rating_expire_hours', '24'),
('movie_subtitles_list_ajax', '1'),
('movie_subtitles_list_max', '10'),
('comments_max_letters', '255'),
('header_description', 'افلام , ممثلين , صور , سينما , مسلسلات'),
('enable_news_comments', '1'),
('count_visitors_info', '1'),
('count_visitors_hits', '1'),
('count_online_visitors', '1'),
('enable_profiles', '1'),
('report_file_enabled', '1'),
('admin_email', 'no-reply@allomani.com'),
('members_profile_pictures', '1'),
('profile_pic_thumb_width', '30'),
('profile_pic_thumb_height', '30'),
('profile_pic_width', '100'),
('profile_pic_height', '100'),
('movies_groups', '1'),
('visitors_can_sort_movies', '1'),
('movies_default_orderby', 'year'),
('movies_default_sort', 'desc'),
('other_votes_show', '1'),
('other_votes_limit', '10'),
('other_votes_orderby', 'rand()'),
('enable_actor_comments', '1'),
('enable_actor_photo_comments', '1'),
('defualt_privacy_profile', '0'),
('defualt_privacy_fav_movies', '0'),
('defualt_privacy_messages', '0'),
('default_privacy_settings', 'a:8:{s:7:"profile";i:0;s:6:"gender";i:0;s:5:"birth";i:0;s:7:"country";i:0;s:10:"last_login";i:0;s:6:"online";i:0;s:10:"fav_movies";i:0;s:8:"messages";i:0;}'),
('online_members_count', '0'),
('reports_enabled', '1'),
('', ''),
('register_sec_code', '1'),
('register_username_min_letters', '4'),
('', ''),
('register_username_exclude_list', 'admin,mod,webmaster'),
('report_sec_code', '1'),
('send_sec_code', '1'),
('date_format', 'D, d M Y'),
('reports_for_visitors', '1'),
('actors_per_page', '200'),
('timezone', 'Asia/Baghdad'),
('auto_email_activate', '0');

-- --------------------------------------------------------

--
-- Table structure for table `movies_subtitles`
--

CREATE TABLE IF NOT EXISTS `movies_subtitles` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `date` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `downloads` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_subtitles`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_templates`
--

CREATE TABLE IF NOT EXISTS `movies_templates` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `protected` int(1) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=134 ;

--
-- Dumping data for table `movies_templates`
--

INSERT INTO `movies_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`, `views`) VALUES
(1, 'الهيدر', 'header', '<body onunload="pop_close()">\r\n\r\n<div class=''header-div''><img src=''images/logo.png''></div>\r\n\r\n<br><br>\r\n\r\n<div class=''container''>\r\n', 1, 1, 1),
(17, 'كود رأس الصفحة', 'page_head', '<?\r\nglobal $settings,$section_name,$title_sub,$sitename,$meta_keywords,$meta_description,$settings,$action,$scripturl;\r\n\r\nif(($section_name && $settings[''section_name_in_subpages'']) || $title_sub){\r\n$full_title = iif($sitename && ($settings[''sitename_in_subpages''] ||  (CFN == "index.php" && !$action)),$sitename,'''');\r\n}else{\r\n$full_title = $sitename;\r\n}\r\nif($section_name && ($settings[''section_name_in_subpages''] || (CFN == "index.php" && !$action))){\r\n$full_title .= iif($full_title," - $section_name",$section_name);\r\n}\r\n\r\nif($title_sub){\r\n$full_title .= iif($full_title," - $title_sub",$title_sub);\r\n}\r\n\r\n\r\nprint "<!DOCTYPE html PUBLIC \\"-//W3C//DTD XHTML 1.0 Transitional//EN\\"\r\n         \\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\\">\r\n\r\n<html xmlns=\\"http://www.w3.org/1999/xhtml\\" dir=\\"$settings[html_dir]\\">\r\n\r\n<head>\r\n<base href=\\"$scripturl/\\" />\r\n\r\n<meta http-equiv=\\"Content-Type\\" content=\\"text/html; charset=utf-8\\" />\r\n<meta http-equiv=\\"Content-Language\\" content=\\"$settings[site_pages_lang]\\" />\r\n\r\n";\r\nprint "<!-- no cache headers -->\r\n	<meta http-equiv=\\"Pragma\\" content=\\"no-cache\\" />\r\n	<meta http-equiv=\\"Expires\\" content=\\"-1\\" />\r\n	<meta http-equiv=\\"Cache-Control\\" content=\\"no-cache\\" />\r\n<!-- end no cache headers -->\r\n\r\n<meta name=\\"generator\\" content=\\"Allomani Movies v2.0\\" />\r\n\r\n<meta name=\\"keywords\\" content=\\"allomani,اللوماني,".$meta_keywords."\\" />\r\n<meta name=\\"description\\" content=\\"$meta_description\\" />\r\n<meta name=\\"abstract\\" content=\\"$meta_description\\" />\r\n\r\n<meta name=\\"robots\\" content=\\"index, follow\\" />\r\n<meta name=\\"rating\\" content=\\"General\\" /> \r\n<meta name=\\"distribution\\" content=\\"Global\\" />\r\n\r\n\r\n<link type=\\"text/css\\" rel=\\"stylesheet\\" href=\\"css.php\\" />";\r\n\r\nprint "<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS\\" href=\\"rss.php\\" />\r\n\r\n<title>$full_title</title>\r\n";\r\n\r\n?>\r\n<script type="text/javascript">\r\nvar scripturl="<?=$scripturl?>";\r\n</script>\r\n\r\n<script type="text/javascript" src="js/prototype.js"></script>\r\n<script type="text/javascript" src="js/javascript.js"></script>\r\n<?\r\n\r\nif(in_array(CFN,array("actor_details.php","actor_photos.php","movie_info.php","movie_photos.php","movie_files.php","news.php","profile.php"))){\r\nprint "<script type=''text/javascript'' src=''js/jquery.js''></script>\r\n<script> jQuery.noConflict(); </script>\r\n<script type=''text/javascript'' src=''js/jquery.raty.min.js''></script>";\r\n}\r\n\r\n\r\nif(in_array(CFN,array("movie_info.php","movie_files.php","profile.php"))){\r\nprint "<script type=''text/javascript'' src=''js/jquery.boxy.allomani.js''></script>";\r\n}\r\n\r\n?>\r\n', 1, 1, 2),
(2, 'الفوتر', 'footer', '</div>\r\n<div class=''footer-div''>\r\n\r\n <br>\r\n<div align=right>&nbsp;&nbsp;&nbsp;\r\n<?global $styleid;print_style_selection();?>\r\n</div><br>\r\n\r\n</div>\r\n\r\n</body>\r\n\r\n</html>\r\n        \r\n        \r\n        \r\n        \r\n        \r\n        ', 1, 1, 1),
(3, 'القوائم', 'block', '<table width="100%"  border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n	<tr>\r\n		<td>\r\n			<img src="images/table_01.gif" width="10" height="12" alt=""></td>\r\n		<td width="100%" height="12" background="images/table_02.gif"></td>\r\n		<td>\r\n			<img src="images/table_03.gif" width="10" height="12" alt=""></td>\r\n	</tr>\r\n	<tr>\r\n		<td background="images/table_04.gif" width="10">\r\n			<img src="images/table_04.gif" width="10" height="10" alt=""></td>\r\n		<td width="100%" bgcolor="#f9ecba" style="text-align:right;padding:5px" dir="rtl">\r\n			{title}{new_line}{content}</td>\r\n		<td background="images/table_06.gif" width="10">\r\n			<img src="images/table_06.gif" width="10" height="10" alt=""></td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<img src="images/table_07.gif" width="10" height="10" alt=""></td>\r\n		<td background="images/table_08.gif" width="100%" height="10">\r\n		</td>\r\n		<td>\r\n			<img src="images/table_09.gif" width="10" height="10" alt=""></td>\r\n	</tr>\r\n</table>\r\n', 1, 1, 1),
(4, 'الجداول', 'table', '<table width="100%" border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n	<tr>\r\n		<td>\r\n			<img src="images/table_01.gif" width="10" height="12" alt=""></td>\r\n		<td width="100%" height="12" background="images/table_02.gif"></td>\r\n		<td>\r\n			<img src="images/table_03.gif" width="10" height="12" alt=""></td>\r\n	</tr>\r\n	<tr>\r\n		<td background="images/table_04.gif" width="10">\r\n			<img src="images/table_04.gif" width="10" height="10" alt=""></td>\r\n		<td width="100%" bgcolor="#f9ecba" style="text-align:right;padding:5px" dir="rtl">\r\n			{title}{new_line}{content}</td>\r\n		<td background="images/table_06.gif" width="10">\r\n			<img src="images/table_06.gif" width="10" height="10" alt=""></td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<img src="images/table_07.gif" width="10" height="10" alt=""></td>\r\n		<td background="images/table_08.gif" width="100%" height="10">\r\n		</td>\r\n		<td>\r\n			<img src="images/table_09.gif" width="10" height="10" alt=""></td>\r\n	</tr>\r\n</table>\r\n<br>', 1, 1, 1),
(93, 'عرض الممثلين', 'browse_actors', '<?\r\nglobal $data,$links;\r\n\r\nprint "<a href=\\"".str_replace("{id}",$data[''id''],$links[''links_actor_details''])."\\" title=\\"$data[name]\\">\r\n        <img src=\\"".get_image($data[''thumb''])."\\" title=\\"$data[name]\\"><br>$data[name]</a>";\r\n?>', 1, 1, 0),
(97, 'تفاصيل الممثل', 'actor_details', '<?\r\nglobal $data,$phrases,$style;\r\n\r\nprint "<table width=100%><tr><td>\r\n\r\n<DIV style=\\"FLOAT: left\\"><TABLE border=\\"0\\"><TBODY><TR><TD><TABLE border=\\"0\\"><TBODY><TR><TD align=\\"center\\">\r\n<img src=''".get_image($data[''img''])."''>\r\n</TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir=\\"rtl\\" align=\\"right\\">\r\n$data[details] \r\n</td></tr>\r\n</div>\r\n\r\n</td></tr></table>";\r\n\r\nif($data[''votes_total''] > 0 && $data[''votes''] > 0){\r\n$rating = $data[''votes'']/$data[''votes_total''] ;\r\n}else{ $rating = 0 ;}\r\n\r\n\r\nprint "<br><br><center>";\r\nprint_rating(''actor'',$data[''id''],$rating);    \r\nprint "</center>";\r\n\r\n print "<br><img src=\\"$style[images]/views.gif\\"> &nbsp; <b>$phrases[views] : </b>$data[views]";   ', 1, 1, 0),
(98, '', 'movie_actors_content', '<?\r\nglobal $c,$settings,$data,$links;\r\n\r\n  print "<li>\r\n        <a href=\\"".str_replace("{id}",$data[''id''],$links[''links_movie_info''])."\\" title=\\"$data[name]\\">\r\n$data[name]</a>".iif($data[''year''],"&nbsp;&nbsp;($data[year])")."</li>";\r\n\r\n?>\r\n', 1, 1, 0),
(99, '', 'movie_actors_header', '<?\r\nprint "<ul>"; \r\n?>', 1, 1, 0),
(100, '', 'movie_actors_footer', '<?\r\n  print "</ul>"; \r\n?>', 1, 1, 0),
(5, 'الاتصال بنا', 'contactus', '<?\r\nglobal $sec_img,$phrases;\r\n\r\n open_table("$phrases[contact_us]");  \r\n    print "<center>\r\n              <form action=''contactus.php'' method=post>\r\n\r\n           \r\n              <input type=hidden name=''action'' value=''send''>\r\n              <table width=60%>\r\n\r\n              <tr>\r\n              <td width=23%> $phrases[the_name] </td>\r\n              <td>\r\n              <input name=''email_name'' type=''text'' size=30>\r\n              </td>\r\n              </tr>\r\n\r\n                <tr>\r\n              <td>$phrases[email] </td>\r\n              <td>\r\n              <input name=''email_email'' type=''text'' size=30>\r\n              </td>\r\n              </tr>\r\n\r\n                  <tr>\r\n              <td> $phrases[the_subject] </td>\r\n              <td>\r\n              <input name=''email_subject'' type=''text'' size=30>\r\n              </td>\r\n              </tr>\r\n            <tr>\r\n              <td> $phrases[the_message] </td>\r\n              <td>\r\n             <textarea name=''email_msg'' rows=5 cols=40></textarea>\r\n              </td>\r\n              </tr>\r\n             <tr>\r\n             <td>$phrases[security_code]</td><td>".$sec_img->output_input_box(''sec_string'',''size=7'')."\r\n           &nbsp;<img src=\\"sec_image.php\\" alt=\\"Verification Image\\" /></td></tr>\r\n           \r\n              <tr><td colspan=2 align=center>\r\n             <input type=\\"submit\\" style=\\"width: 100 ; height: 30\\" value=\\"$phrases[send]\\">\r\n             </td> </tr>\r\n             </form>\r\n             </table>\r\n            </center> ";\r\n  close_table();  \r\n?>', 1, 1, 0),
(6, 'رسالة الإرسال لصديق', 'friend_msg', '<html dir=rtl>\r\n<body>\r\n\r\n<div dir=rtl align=right> قام صديقك بارسال هذا الفيلم لك </p>\r\n\r\n\r\nاسم صديقك : {name_from}<br>\r\nبريد صديقك : {email_from}<br><br>\r\n\r\n<center><table width=100%><td valign=top width=2><img src=''{thumb}''></td><td>\r\n<p align=center><b>{name}</b></p>\r\n\r\n<p>{details}</p>\r\n\r\n\r\nلتحميل / مشاهدة الفيلم : <br> <a href="{url}" target=_blank>{url}</a>\r\n\r\n\r\n</td></tr></table>\r\n\r\n</body>\r\n</html>\r\n', 1, 1, 0),
(14, 'استعراض الأفلام', 'browse_movies', '<?\r\nglobal $data,$phrases,$action,$links,$orderby,$settings;\r\n\r\nprint "<td align=center valign=top><a href=\\"".str_replace("{id}",$data[''id''],$links[''links_movie_info''])."\\">\r\n<img border=0 title=\\"$data[name]\\" src=\\"".get_image($data[''thumb''],"images/no_pic_movie.gif")."\\">\r\n            <br>$data[name]</a>".iif($orderby == "year" && $settings[''movies_groups''],"",iif($data[''year''],"<br><span dir=''ltr''>( $data[year] )</span>"));\r\n\r\nif($data[''fav_id'']){\r\nprint "<br><br>\r\n<a href=\\"usercp.php?action=del_fav&id=$data[fav_id]\\" onclick=\\"return confirm(''$phrases[are_you_sure]'');\\"><img src=''images/delete.gif'' title=''$phrases[delete]'' border=0>$phrases[delete]</a>";\r\n}\r\n\r\n\r\nif(CFN=="search.php"){\r\nprint "<br><img src=''images/cat.gif''><a href=\\"".str_replace("{id}",$data[''cat_id''],$links[''links_cats''])."\\">$data[cat_name]</a>";\r\n}\r\nprint "</td>";\r\n?>\r\n', 1, 1, 2),
(13, 'عرض الأخبار - خارجي', 'browse_news', '<?\r\nglobal $phrases,$data,$links,$settings;\r\n\r\n$news_date = date($settings[''date_format''],$data[''date'']);\r\n$details_link = str_replace(''{id}'',$data[''id''],$links[''news_details'']);\r\n\r\n\r\nprint "<table width=100%>\r\n\r\n<tr><td colspan=2 align=center>\r\n<a href=\\"$details_link\\" title=\\"$data[title]\\"><span class=''title''>$data[title]</span></a>\r\n</td></tr>\r\n\r\n\r\n<tr><td align=center width=''80''>\r\n<a href=\\"$details_link\\" title=\\"$data[title]\\"><img src=\\"".get_image($data[''img''])."\\" title=\\"$data[title]\\"></a></td>\r\n<td>\r\n\r\n<font color=''#808080''>$news_date : </font> $data[content] ... <a href=\\"$details_link\\"> $phrases[read_more]</a>\r\n<br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font></td></tr>\r\n\r\n</table>\r\n<hr class=separate_line size=\\"1\\">";\r\n?>', 1, 1, 2),
(20, '', 'browse_movies_header', '<table width=100%><tr>', 1, 1, 0),
(21, '', 'browse_movies_footer', '</tr></table>', 1, 1, 0),
(22, '', 'browse_movies_sep', '</tr><tr>', 1, 1, 0),
(25, 'عرض الخبر - داخلي', 'browse_news_inside', '<?\r\nglobal $data,$phrases,$settings;\r\n\r\n$news_date = date($settings[''date_format''],$data[''date'']);\r\n\r\nprint "<table width=100%><tr><td>\r\n\r\n<DIV style=\\"FLOAT: left\\"><TABLE border=\\"0\\"><TBODY><TR><TD><TABLE border=\\"0\\"><TBODY><TR><TD align=\\"center\\">\r\n<img src=''".get_image($data[''img''])."''>\r\n</TD></TR><TR><TD align=center><font color=''#808080''>$news_date</font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir=\\"rtl\\" align=\\"right\\">\r\n$data[details] <br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font>\r\n\r\n</td></tr>\r\n<tr><td colspan=2 align=left><a href=''news_print.php?id=$data[id]''><img src=''images/print.gif'' alt=''$phrases[printable_copy]'' border=0></a>\r\n\r\n</div>\r\n\r\n</td></tr></table>";\r\n\r\nif($data[''votes_total''] > 0 && $data[''votes''] > 0){\r\n$rating = $data[''votes'']/$data[''votes_total''] ;\r\n}else{ $rating = 0 ;}\r\n\r\n\r\nprint "<br><br><center>";\r\nprint_rating(''news'',$data[''id''],$rating);    \r\nprint "</center>";\r\n?>', 1, 1, 1),
(26, 'عرض الخبر - طباعة', 'browse_news_print', '<html dir=rtl>\r\n<title>{title}</title>\r\n\r\n<table width=100%>\r\n<tr>\r\n<td>\r\n<p align=center><font size=5><b>{title}</b></font></p>\r\n</td></tr>\r\n\r\n<tr><td>\r\n\r\n<DIV style="FLOAT: left"><TABLE border="0"><TBODY><TR><TD><TABLE border="0"><TBODY><TR><TD align="center">\r\n<img src=''{img}''>\r\n</TD></TR><TR><TD align=center><font color=''#808080''>{date} </font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir="rtl" align="right">\r\n{details} <br><br> الكاتب : <font color=''#808080''>{writer}</font>\r\n</div>\r\n</td></tr>\r\n\r\n</table>   ', 1, 1, 0),
(29, 'قالب الخطوط و الألوان', 'CSS', '/*------------------ BODY -------------------*/\r\nBODY {\r\nFONT-SIZE: 8pt; \r\nCOLOR: #000000 ; \r\nFONT-FAMILY: Tahoma; \r\n\r\nmargin-top: 0px;\r\nmargin-right: 0px;\r\nmargin-bottom: 0px;\r\nmargin-left: 0px;\r\n\r\nBACKGROUND-COLOR: #911d00;\r\n}\r\n\r\n.header-div {\r\nbackground-image:url(''images/header_bg.png'');\r\nheight:141px;\r\n}\r\n\r\n.container {\r\nmin-height: 100%;\r\n}\r\n\r\n\r\n.footer-div {\r\nwidth:100%;\r\nbackground-image:url(''images/footer_bg.png'');\r\nheight:70px;\r\n}\r\n\r\nimg { \r\nborder: 0px; \r\n}\r\n\r\nfieldset {\r\n	border:  1px solid #911d00;padding: 2;\r\n	\r\n}\r\n\r\n\r\n\r\n\r\n/*--------- TITLES -------------*/\r\n.title {\r\nfont-size: 10pt; color: #911d00; font-weight:bold;align:center;\r\n}\r\n\r\n.block_title{\r\n\r\n}\r\n\r\n.table_title{\r\n}\r\n\r\n\r\n/*----------- LINKS -----------------*/\r\nA:link {COLOR: #946f20; TEXT-DECORATION: none;}\r\nA:active {COLOR: #946f20; TEXT-DECORATION: none;}\r\nA:visited {COLOR: #946f20; TEXT-DECORATION: none;}\r\nA:hover {COLOR: #000000; TEXT-DECORATION: none;}\r\n\r\n\r\n/*----------- PATH BAR -----------------*/\r\n\r\n.path{\r\nCOLOR: #FFFFFF ; \r\n}\r\n\r\n\r\nA:link.path_link {\r\nCOLOR: #FFFFFF; TEXT-DECORATION: none\r\n}\r\nA:active.path_link {\r\nCOLOR: #FFFFFF;  TEXT-DECORATION: none\r\n}\r\nA:visited.path_link {\r\nCOLOR: #FFFFFF;  TEXT-DECORATION: none\r\n}\r\nA:hover.path_link {\r\nCOLOR: #FFFFFF;  TEXT-DECORATION: none\r\n}\r\n\r\n\r\n\r\n/*--------- MEMBERS MESSAGES FONT-----------------*/\r\n.messages {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\n\r\n/*--------- SPARATE LINKE --------------------*/\r\n.separate_line{\r\nborder-width: 1px 0 0 0; border-style: solid; border-color: #911d00;\r\n}\r\n\r\n/*-------- Colored Rows COLORS ---------------*/\r\n.row_1{\r\nbackground-color: #f9ecba;\r\n}\r\n.row_2{\r\nbackground-color: #F0D7A1 ;\r\n}\r\n\r\n\r\n.older_comments_div{\r\nbackground-color: #E9E9E9;\r\n}\r\n\r\n\r\n/* ------- online / offline -----*/\r\n.online {color:#008000;font-weight: bold;}\r\n.offline {color:#585858;}\r\n\r\n/* --------- Categories Menu --------------- */\r\n#cats_menu, #cats_menu ul{\r\n  text-align:right;\r\n  margin:0; \r\n  padding:0; \r\n}\r\n\r\n#cats_menu li{\r\n  margin:0 10px 0 0; \r\n  padding:0; \r\n  list-style-type:none; \r\n}\r\n\r\n#cats_menu .symbols{ \r\n  float:right;\r\n  width:12px;\r\n  height:1em;\r\n  background-position:0 50%;\r\n  background-repeat:no-repeat;\r\n}\r\n\r\n\r\n/* ---------- Tabs ------------ */\r\n.tabs {\r\nwidth: 100%;\r\n\r\n		margin: 0px;\r\n}\r\n\r\n.tab_active {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-width: 1px;\r\n	border-style: solid;\r\n	background-color: #fff;\r\n	color: #000;\r\n	float: right;\r\n	width: 150px;\r\n	cursor: default;\r\n	font-weight: bold;\r\n	padding: 2px;\r\n	font-size: 10pt;\r\n	text-align: center;\r\n	background-image:url(''images/tabs_shade.gif'')\r\n}\r\n\r\n.tab_inactive {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 1px;\r\n	background-color: #ddd;\r\n	color: #777;\r\n	float: right;\r\n	width: 150px;\r\n        cursor:pointer;\r\n	cursor: hand;\r\n	padding: 2px;\r\n	font-size: 10pt;\r\n	text-align: center;\r\n}\r\n\r\n.tab_content {\r\n	-moz-border-radius: 0px 10px 10px 10px;\r\n	width: 99%;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 0px;\r\n	color: #000;\r\n	float: right;\r\n	text-align: right;\r\n	padding: 10px;\r\n}\r\n\r\n.tab_container {\r\nwidth: 100%;\r\nalign: center;\r\ntext-align: center;\r\n}\r\n\r\n\r\n/* --------- Slider ---------------*/\r\n\r\n.slider_active {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-width: 1px;\r\n	border-style: solid;\r\n	background-color: #fff;\r\n	color: #000;\r\n	float: right;\r\n	\r\n	cursor: default;\r\n	font-weight: bold;\r\n\r\nmargin: 0 5px; \r\nheight:15;\r\npadding: 3px 5px;\r\n\r\n	font-size: 10pt;\r\n	text-align: center;\r\n	background-image:url(''images/tabs_shade.gif'')\r\n}\r\n\r\n.slider_inactive {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 1px;\r\n	background-color: #ddd;\r\n	color: #777;\r\n	float: right;\r\n        cursor:pointer;\r\n	cursor: hand;\r\n       \r\n\r\nmargin: 0 5px; \r\nheight:15;\r\npadding: 3px 5px;\r\n\r\n	font-size: 10pt;\r\n	text-align: center;\r\n}\r\n\r\n\r\n\r\n\r\n.slider_btnz{\r\ncursor: hand;\r\nwidth:25;\r\n}\r\n\r\n\r\n//-------- pop Dialog ---------------\r\n\r\n.boxy-wrapper { position: absolute; left: 50%;\r\n  top: 50%;}\r\n\r\n.boxy-wrapper.fixed { position: fixed;  }\r\n\r\n  /* Modal */\r\n  \r\n  .boxy-modal-blackout { position: absolute; background-color: black; left: 0; top: 0; }\r\n  \r\n  /* Border */\r\n\r\n  .boxy-wrapper { empty-cells: show; }\r\n    .boxy-wrapper .top-left,\r\n    .boxy-wrapper .top-right,\r\n    .boxy-wrapper .bottom-right,\r\n    .boxy-wrapper .bottom-left { width: 10px; height: 10px; padding: 0 ;background-color: black;opacity: 0.6; filter: alpha(opacity=60);}\r\n    \r\n    \r\n	.boxy-wrapper .top,\r\n	.boxy-wrapper .bottom { height: 10px; background-color: black; opacity: 0.6; filter: alpha(opacity=60); padding: 0 }\r\n	\r\n	.boxy-wrapper .left,\r\n	.boxy-wrapper .right { width: 10px; background-color: black; opacity: 0.6; filter: alpha(opacity=60); padding: 0 }\r\n	\r\n	/* Title bar */\r\n	\r\n	.boxy-wrapper .title-bar { background-color: black; padding: 6px; position: relative; text-align:center; }\r\n	  .boxy-wrapper .title-bar.dragging { cursor: move; }\r\n	    .boxy-wrapper .title-bar h2 { font-size: 12px; color: white; line-height: 1; margin: 0; padding: 0; font-weight: normal; }\r\n	    .boxy-wrapper .title-bar .close { color: white; position: absolute; top: 6px; right: 6px; font-size: 90%; line-height: 1; }\r\n		\r\n	/* Content Region */\r\n	\r\n	.boxy-inner { background-color: #911d00; padding: 0 }\r\n	.boxy-content { padding: 15px; }\r\n	\r\n	/* Question Boxes */\r\n\r\n    .boxy-wrapper .question { width: 350px; min-height: 80px; }\r\n    .boxy-wrapper .answers { text-align: right; }\r\n\r\n\r\n\r\n\r\n', 1, 1, 5),
(30, '', 'browse_movies_cats_header', '<?\r\nopen_table();\r\nprint "<table width=100%>";\r\n?>', 1, 1, 0),
(31, '', 'browse_movies_cats_sep', '</tr><tr>', 1, 1, 0),
(32, '', 'browse_movies_cats', '<?\r\nglobal $data,$links,$phrases;\r\n\r\nprint " <td align=center><center><a href=\\"".str_replace("{id}",$data[''id''],$links[''links_cats''])."\\">\r\n            <img border=0 title=\\"$data[name]\\"\r\n            src=\\"".get_image($data[''img''],"images/folder.gif")."\\">\r\n            <br>$data[name] </a><br>" ;\r\n\r\n print "</td>";\r\n?>', 1, 1, 0),
(33, '', 'browse_movies_cats_footer', '<?\r\nprint "</tr></table>";\r\nclose_table();\r\n?>', 1, 1, 0),
(110, 'رسالة تفعيل البريد الالكتروني', 'email_activation_msg', '<html dir=rtl>\r\n<body>\r\n\r\nمرحبا {name}, <br><br>\r\n\r\n\r\nلتفعيل بريدك الالكتروني يرجى الضغط على الرابط التالي : <br>\r\n\r\n<a href="{url}" target=_blank>{url}</a>\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>\r\n', 1, 1, 0),
(111, 'رسالة تأكيد تغيير البريد الالكتروني', 'email_change_confirmation_msg', '<html dir=rtl>\r\n<body>\r\n\r\nمرحبا {username} <br><br>\r\n\r\nتصلك هذه الرسالة لتأكيد بريدك الاكتروني الجديد<br><br>\r\n\r\nلتغيير بريدك الالكتروني الى هذا البريد , يرجى الضغط على الرابط التالي : <br>\r\n\r\n<a href="{active_link}" target=_blank>{active_link}</a>\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1, 0),
(112, 'رسالة كلمة المرور الجديدة', 'pwd_rest_done_msg', '<html dir=rtl>\r\n<body>\r\n\r\n{name},<br>\r\nلقد تم تغيير كلمة المرور الخاصة بك,\r\n<br><br>\r\n\r\nكلمة المرور الجديدة : {password}\r\n\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1, 0),
(113, 'رسالة طلب تغيير كلمة المرور', 'pwd_rest_request_msg', '<html dir=rtl>\r\n<body>\r\n\r\n{name},<br><br>\r\n\r\nلقد قمت بطلب تغيير كلمة المرور لفقدانك لها , لتأكيد العملية يرجى الضغط على الرابط التالي : \r\n<br>\r\n<a href="{url}" target=_blank>{url}</a>\r\n<br><br>\r\n\r\nاذا لم تكن انت من قام بعمل هذا الطلب , فضلا تجاهل هذه الرسالة\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}', 1, 1, 0),
(114, '', 'no_title_no_border', '{content}', 0, 1, 0),
(115, '', 'center_banners', '<?\r\nglobal $data;\r\nprint "<center><a href=''banner.php?id=$data[id]'' target=_blank><img src=''$data[img]'' border=0 title=''$data[title]''></a><br></center>";\r\n?>', 1, 1, 0),
(116, '', 'blocks_banners', '<?\r\nglobal $data;\r\nopen_block();\r\n\r\nprint "<center><a href=''banner.php?id=$data[id]'' target=_blank><img src=''$data[img]'' border=0 title=''$data[title]''></a></center>";\r\n\r\nclose_block();\r\n?>', 1, 1, 0),
(123, '', 'movie_icons', '<?\r\nglobal $data,$movie_files_count,$movie_subtitles_count,$settings,$phrases,$style,$files_cnt,$scripturl,$links;\r\n\r\n\r\n //------ files ----------//\r\n\r\n          if($movie_files_count == 1){\r\n          get_movie_file_icons($data[''id'']);\r\n          }elseif($movie_files_count > 1 && $settings[''movie_files_list_ajax'']){\r\n            print "<a href=''javascript:;'' onClick=\\"show_files_list($data[id]);\\"><img src=''$style[images]/folder_download.gif'' title=\\"$phrases[watch] / $phrases[download]\\" border=0 width=24 height=24></a>&nbsp;";\r\n           }\r\n\r\n//------ subtitles ------//\r\n\r\nif($movie_subtitles_count && $settings[''movie_subtitles_list_ajax'']){\r\n          print "<a href=''javascript:;'' onClick=\\"show_subtitles_list($data[id]);\\"><img src=''$style[images]/subtitles.gif'' title=\\"$phrases[subtitles]\\" border=0 width=24 height=24></a>&nbsp;";\r\n          }\r\n//----------------------//\r\n          if($settings[''snd2friend'']){\r\n          print "<a href=\\"javascript:send($data[id])\\" id=''snd2friend_lnk''><img src=''$style[images]/snd.gif'' title=\\"$phrases[send2friend]\\" border=0 width=24 height=24></a>&nbsp;";\r\n         }\r\n\r\n//--------------------//\r\nprint "<a href=''http://www.facebook.com/sharer.php?u=".urlencode($scripturl."/".str_replace("{id}",$data[''id''],$links[''links_movie_info'']))."'' target=_blank><img src=''$style[images]/facebook.gif'' width=24 height=24 title=''Share with Facebook'' border=0></a>&nbsp;";\r\n\r\n//--------------------//\r\n         if(check_member_login()){\r\n          print "<a href=\\"javascript:add_to_fav($data[id]);\\"><img src=''$style[images]/favorite_add.gif'' title=\\"$phrases[add2favorite]\\" border=0></a>&nbsp;";\r\n          }\r\n\r\n if($settings[''reports_enabled''] && $movie_files_count == 1){\r\n           print "<a href=\\"javascript:;\\" onClick=\\"report($files_cnt[id],''movie_file'');\\"><img src=\\"$style[images]/report.gif\\" title=\\"$phrases[report_do]\\" border=0 width=24 height=24></a>&nbsp;";\r\n           }\r\n\r\n?>', 1, 1, 0),
(118, 'رسالة التنبيه بالبريد للرسائل الخاصة', 'pm_email_notify_msg', '<html dir="rtl">\r\n<body>\r\n\r\n<div align=right>\r\n\r\nمرحبا , <br>\r\n\r\nلقد وصلتك رسالة جديدة من {name_from} <br><br>\r\n\r\nلمشاهدة الرسالة قم بزيارة الرابط التالي <br>\r\n\r\n<a href="{url}" target=_blank>{url}</a> <br>\r\n\r\n</div>\r\n</body>\r\n</html>', 1, 1, 0),
(119, 'شريط ترتيب الافلام', 'movies_sort_bar', '<?\r\nglobal $phrases,$cat,$links,$start,$orderby,$sort;\r\n\r\n$orders = array("name"=>$phrases[''the_name''],"year"=>$phrases[''release_year''],"id"=>$phrases[''add_date''],"votes"=>$phrases[''the_most_voted'']);\r\n\r\n\r\n\r\n$page_string = str_replace(array(''{id}'',''{start}''),array($cat,$start),$links[''links_cats_w_pages'']);\r\n\r\n\r\nprint "<span class=''path''><img src=''images/sort.gif''>&nbsp;<b>$phrases[sort_by] :</b>&nbsp;&nbsp;";\r\n\r\nforeach($orders as $key=>$value){\r\n\r\nprint "<a href=''".str_replace(array(''{orderby}'',''{sort}''),array($key,''asc''),$page_string)."'' class=''path_link''>".iif($orderby==$key,"<b>").$value.iif($orderby==$key,"</b>")."</a>";\r\n\r\n\r\nif($orderby==$key && $sort=="asc"){\r\nprint "<img src=''images/arr_asc_disabled.gif'' border=0 title=\\"$value $phrases[asc]\\"></a>";\r\n}else{\r\nprint "<a href=''".str_replace(array(''{orderby}'',''{sort}''),array($key,''asc''),$page_string)."'' class=''path_link''><img src=''images/arr_asc.gif'' border=0 title=\\"$value $phrases[asc]\\"></a>";\r\n}\r\n\r\nif($orderby==$key && $sort=="desc"){\r\nprint "<img src=''images/arr_desc_disabled.gif'' border=0 title=\\"$value $phrases[desc]\\">";\r\n}else{\r\nprint "<a href=''".str_replace(array(''{orderby}'',''{sort}''),array($key,''desc''),$page_string)."'' class=''path_link''><img src=''images/arr_desc.gif'' border=0 title=\\"$value $phrases[desc]\\"></a>";\r\n}\r\n\r\nprint "&nbsp;";\r\n\r\n}\r\n\r\n\r\nprint "</span><br><br>";\r\n\r\n?>', 1, 1, 0),
(120, '', 'movie_file_icons', '<?\r\nglobal $player_data,$links,$phrases,$file_id;\r\n\r\n if($player_data[''int_enabled'']){\r\n           print "<a href=\\"".str_replace("{id}",$file_id[''id''],$links[''file_watch''])."\\" onClick=\\"return show_player($file_id[id],$player_data[id],$player_data[view_style]);\\"><img src=\\"{$player_data[''int_icon'']}\\" title=\\"".str_replace("{views}",$file_id[''views''],$player_data[''int_icon_alt''])."\\" border=0></a>";\r\n          }\r\n          \r\n          if($player_data[''ext_enabled'']){\r\n           print "<a href=\\"".str_replace("{id}",$file_id[''id''],$links[''file_watch_ext''])."\\"><img src=\\"{$player_data[''ext_icon'']}\\" title=\\"".str_replace("{views}",$file_id[''views''],$player_data[''ext_icon_alt''])."\\" border=0></a>";\r\n          }\r\n          \r\n          if($player_data[''download_enabled'']){\r\n           print "<a href=\\"".str_replace("{id}",$file_id[''id''],$links[''file_download''])."\\"><img src=\\"{$player_data[''download_icon'']}\\" title=\\"".str_replace("{downloads}",$file_id[''downloads''],$player_data[''download_icon_alt''])."\\" border=0></a>";\r\n          }\r\n?>', 1, 1, 0),
(121, '', 'movie_files_list', '<?\r\nglobal $tr_color,$data,$player_data,$links,$phrases,$settings,$style;\r\n\r\nprint "<tr class=''$tr_color''><td>$data[name]</td>";\r\n       \r\n         \r\n if(is_array($player_data)){\r\n\r\n if($player_data[''int_enabled'']){\r\n print "<td width=5% align=center><a href=\\"".str_replace("{id}",$data[''id''],$links[''file_watch''])."\\" onClick=\\"return show_player($data[id],$player_data[id],$player_data[view_style]);\\"><img src=\\"{$player_data[''int_icon'']}\\" title=\\"".str_replace("{views}",$data[''views''],$player_data[''int_icon_alt''])."\\" border=0></a></td>";\r\n }\r\n          \r\n if($player_data[''ext_enabled'']){\r\n           print "<td width=5% align=center><a href=\\"".str_replace("{id}",$data[''id''],$links[''file_watch_ext''])."\\"><img src=\\"{$player_data[''ext_icon'']}\\" title=\\"".str_replace("{views}",$data[''views''],$player_data[''ext_icon_alt''])."\\" border=0></a></td>";\r\n          }\r\n          \r\n          if($player_data[''download_enabled'']){\r\n           print "<td width=5% align=center><a href=\\"".str_replace("{id}",$data[''id''],$links[''file_download''])."\\"><img src=\\"{$player_data[''download_icon'']}\\" title=\\"".str_replace("{downloads}",$data[''downloads''],$player_data[''download_icon_alt''])."\\" border=0></a></td>";\r\n          }\r\n          \r\n          \r\nif($settings[''reports_enabled'']){\r\n           print "<td width=5% align=center><a href=\\"javascript:;\\" onClick=\\"report($data[id],''movie_file'');\\"><img src=\\"$style[images]/report.gif\\" title=\\"$phrases[report_do]\\" border=0></a></td>";\r\n           }\r\n           \r\n        \r\n         \r\n          }else{\r\n              print "<td>Error : no player</td>";\r\n          }\r\n        \r\n        print "</tr>";  \r\n?>', 1, 1, 0),
(122, '', 'movie_subtitles_list', '<?\r\nglobal $tr_color,$data,$links,$phrases,$style;\r\n\r\n print "<tr class=''$tr_color''><td>$data[name]</td><td width=''24''>\r\n       <a href=\\"".str_replace("{id}",$data[''id''],$links[''subtitle_download''])."\\" title=\\"$phrases[download]\\">\r\n       <img src=\\"$style[images]/download.gif\\" border=0></a></td></tr>";\r\n?>\r\n', 1, 1, 0),
(124, 'نوذج رسالة الاتصال بنا', 'contactus_msg', '<html dir=rtl>\r\n<body>\r\n\r\nاسم المرسل : {name} <br>\r\nبريد المرسل : {email} <br><br>\r\n\r\n----------------------------------<br><br>\r\n\r\n{message}\r\n\r\n<br><br>\r\n\r\n---------------------------------\r\n\r\n</body>\r\n</html>', 1, 1, 0),
(125, 'تفاصيل الفيلم', 'movie_info', '<?\r\nglobal $data,$phrases,$settings,$director,$custom_fields,$global_align_x,$style,$movie_files_count,$movie_subtitles_count,$rating,$links;\r\n\r\nprint "<table width=100%><tr>\r\n          <td align=center width=\\"".($settings[''movie_cover_thumb_width'']+10)."\\" rowspan=2>";\r\n        \r\n          if($data[''thumb'']){\r\n          print "<a href=\\"javascript:enlarge_pic(''".$data[''img'']."'',''".htmlspecialchars(str_replace(array("?","''"),"",$data[''name'']))."'')\\"><img border=0 src=\\"".get_image($data[''thumb''])."\\" title=\\"$data[name]\\n$phrases[enlarge_pic]\\"></a>";\r\n          }else{\r\nprint "<img border=0 src=''".get_image($data[''thumb''],$style[''images'']."/no_pic_movie.gif")."''>";\r\n        }\r\n                  \r\n       \r\n         print "\r\n         <br><br>";\r\n         \r\nprint_rating(''movie'',$data[''id''],$rating);\r\n        \r\n          \r\nprint "</td><td>\r\n         <img src=''$style[images]/add_date.gif''> &nbsp; <b>$phrases[add_date] : </b> ".date($settings[''date_format''],$data[''date'']);\r\n          \r\n//---------------- director ------\r\n          if($director[''name'']){\r\n              print "<br><img src=''images/director.gif''> &nbsp;<b> $phrases[the_director] : </b>";\r\n           if($director[''id'']){\r\n             print "<a href=\\"".str_replace("{id}",$director[''id''],$links[''links_actor_details''])."\\" title=\\"$director[name]\\">$director[name]</a>";        \r\n              }else{\r\n             print "$director[name]";\r\n              }\r\n          }\r\n          //-------------------\r\n          \r\n    \r\n   foreach($custom_fields as $field){\r\n\r\nprint "<br><img src=''$style[images]/info.gif''> &nbsp;<b>$field[name] : </b> ".iif($field[''search''],"<a href=\\"search.php?field_id=$field[id]&keyword=".$field[''value'']."\\">").$field[''value''].iif($field[''search''],"</a>");\r\n\r\n}       \r\n          \r\n          \r\n  if($movie_files_count){print "<br><img src=''$style[images]/files.gif''> &nbsp;<b> $phrases[the_files_count] : </b> $movie_files_count";}\r\n\r\n\r\nif($movie_subtitles_count){print "<br><img src=''$style[images]/subtitles_count.gif''> &nbsp;<b> $phrases[the_subtitles_count] : </b> $movie_subtitles_count";} \r\n\r\nif($data[''year'']){\r\nprint "<br> <img src=''$style[images]/year.gif''> &nbsp; <b>$phrases[release_year] : </b>$data[year]";\r\n}\r\n\r\n\r\nprint "<br> <img src=''$style[images]/views.gif''> &nbsp; <b>$phrases[views] : </b>$data[views]";\r\n\r\n\r\n           \r\n            \r\n          print "<br><br>\r\n          $data[details]<br>\r\n\r\n          </td></tr><tr><td align=''$global_align_x'' valign=bottom>";\r\n          run_template(''movie_icons'');\r\n          print "</td></tr></table>";\r\n\r\n?>', 1, 1, 2),
(126, '', 'news_cats_header', '<?\r\nopen_table();\r\nprint "<table width=100%><tr>";\r\n?>', 1, 1, 1),
(127, '', 'news_cats', '<?\r\nglobal $data,$links,$style;\r\n\r\nprint "<td align=center><a href=\\"".str_replace(''{cat}'',$data[''id''],$links[''links_browse_news''])."\\"><img src=\\"".get_image($data[''img''],"$style[images]/folder.gif")."\\" title=\\"$data[name]\\"><br>$data[name]</a></td>";\r\n\r\n\r\n?>', 1, 1, 2),
(128, '', 'news_cats_sep', '</tr><tr>', 1, 1, 1),
(129, '', 'news_cats_footer', '<?\r\nprint "</tr></table>";\r\nclose_table();\r\n?>', 1, 1, 1),
(130, '', 'browse_news_header', '<?\r\nglobal $phrases;\r\nopen_table("$phrases[the_news]");\r\nprint "<hr class=separate_line size=\\"1\\">";    \r\n?>', 1, 1, 1),
(131, '', 'browse_news_sep', '', 1, 1, 1),
(132, '', 'browse_news_footer', '<?\r\nclose_table();\r\n?>', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `movies_templates_cats`
--

CREATE TABLE IF NOT EXISTS `movies_templates_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `selectable` int(11) NOT NULL default '0',
  `images` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `movies_templates_cats`
--

INSERT INTO `movies_templates_cats` (`id`, `name`, `selectable`, `images`) VALUES
(1, 'الستايل الافتراضي', 1, 'images');

-- --------------------------------------------------------

--
-- Table structure for table `movies_user`
--

CREATE TABLE IF NOT EXISTS `movies_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `group_id` int(11) NOT NULL default '0',
  `cp_permisions` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_user`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_votes`
--

CREATE TABLE IF NOT EXISTS `movies_votes` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `cnt` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `movies_votes`
--

INSERT INTO `movies_votes` (`id`, `title`, `cnt`, `cat`) VALUES
(1, 'ممتاز', 16, 1),
(2, 'جيد', 11, 1),
(3, 'سيء', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `movies_votes_cats`
--

CREATE TABLE IF NOT EXISTS `movies_votes_cats` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `active` (`active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `movies_votes_cats`
--

INSERT INTO `movies_votes_cats` (`id`, `title`, `active`) VALUES
(1, 'ما رأيك في الموقع ؟', 1),
(2, 'اختبار', 0);
