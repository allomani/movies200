-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 26, 2011 at 08:59 PM
-- Server version: 5.0.67
-- PHP Version: 5.2.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `movies200_en`
--

-- --------------------------------------------------------

--
-- Table structure for table `info_best_visitors`
--

CREATE TABLE IF NOT EXISTS `info_best_visitors` (
  `time` varchar(255) NOT NULL,
  `v_count` int(11) NOT NULL default '0',
  KEY `v_count` (`v_count`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_best_visitors`
--

INSERT INTO `info_best_visitors` (`time`, `v_count`) VALUES
('20-Dec-2010 at: 04:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `info_browser`
--

CREATE TABLE IF NOT EXISTS `info_browser` (
  `name` varchar(20) NOT NULL,
  `count` int(11) NOT NULL default '0',
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_browser`
--

INSERT INTO `info_browser` (`name`, `count`) VALUES
('Netscape', 0),
('MSIE', 118),
('Lynx', 0),
('Opera', 0),
('WebTV', 0),
('Konqueror', 0),
('Bot', 0),
('Other', 0),
('Chrome', 1690),
('Firefox', 4),
('Nokia', 0),
('BlackBerry', 0),
('iPhone', 0),
('iPod', 0),
('Android', 0);

-- --------------------------------------------------------

--
-- Table structure for table `info_hits`
--

CREATE TABLE IF NOT EXISTS `info_hits` (
  `date` varchar(20) NOT NULL,
  `hits` int(11) NOT NULL default '0',
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_hits`
--

INSERT INTO `info_hits` (`date`, `hits`) VALUES
('26-04-2011', 2);

-- --------------------------------------------------------

--
-- Table structure for table `info_online`
--

CREATE TABLE IF NOT EXISTS `info_online` (
  `time` int(15) NOT NULL default '0',
  `ip` varchar(40) NOT NULL default '',
  `uid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`time`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_online`
--

INSERT INTO `info_online` (`time`, `ip`, `uid`) VALUES
(1303837103, '127.0.0.1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `info_os`
--

CREATE TABLE IF NOT EXISTS `info_os` (
  `name` varchar(20) NOT NULL,
  `count` int(11) NOT NULL default '0',
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info_os`
--

INSERT INTO `info_os` (`name`, `count`) VALUES
('Windows', 1812),
('Mac', 0),
('Linux', 0),
('FreeBSD', 0),
('SunOS', 0),
('IRIX', 0),
('BeOS', 0),
('OS/2', 0),
('AIX', 0),
('Other', 0),
('BlackBerry', 0),
('Symbian', 0);

-- --------------------------------------------------------

--
-- Table structure for table `movies_access_log`
--

CREATE TABLE IF NOT EXISTS `movies_access_log` (
  `id` int(11) NOT NULL auto_increment,
  `username` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `status` text NOT NULL,
  `ip` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `movies_access_log`
--

INSERT INTO `movies_access_log` (`id`, `username`, `date`, `status`, `ip`) VALUES
(1, 'admin', '2011-04-26 07:54:55', 'Login Done', '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `movies_actors`
--

CREATE TABLE IF NOT EXISTS `movies_actors` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `img` text NOT NULL,
  `thumb` text NOT NULL,
  `details` text NOT NULL,
  `views` int(11) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_actors`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_actors_index`
--

CREATE TABLE IF NOT EXISTS `movies_actors_index` (
  `id` int(11) NOT NULL auto_increment,
  `actor_id` int(11) NOT NULL default '0',
  `movie_id` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `movie_id` (`movie_id`),
  KEY `actor_id` (`actor_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_actors_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_actors_photos`
--

CREATE TABLE IF NOT EXISTS `movies_actors_photos` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `cat` int(11) NOT NULL default '0',
  `img` text NOT NULL,
  `img_resized` text NOT NULL,
  `thumb` text NOT NULL,
  `date` int(10) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_actors_photos`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_actors_photos_tags`
--

CREATE TABLE IF NOT EXISTS `movies_actors_photos_tags` (
  `id` int(11) NOT NULL auto_increment,
  `photo_id` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `actor_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `actor_id` (`actor_id`),
  KEY `photo_id` (`photo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_actors_photos_tags`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_banners`
--

CREATE TABLE IF NOT EXISTS `movies_banners` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `img` text NOT NULL,
  `date` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `type` varchar(20) NOT NULL,
  `views` int(11) NOT NULL default '0',
  `clicks` int(11) NOT NULL default '0',
  `menu_id` int(11) NOT NULL default '0',
  `menu_pos` varchar(1) NOT NULL,
  `pages` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `c_type` varchar(20) NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pages` (`pages`),
  KEY `active` (`active`),
  KEY `menu_pos` (`menu_pos`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `movies_banners`
--

INSERT INTO `movies_banners` (`id`, `title`, `url`, `img`, `date`, `ord`, `type`, `views`, `clicks`, `menu_id`, `menu_pos`, `pages`, `content`, `c_type`, `active`) VALUES
(1, 'Allomani', 'http://allomani.com', 'http://allomani.com/allomani_banner.gif', 1294566798, 0, 'header', 116, 0, 0, 'r', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', '', 'img', 1),
(2, 'Allomani', 'http://allomani.com', 'http://allomani.com/allomani_banner.gif', 1294568994, 0, 'footer', 114, 0, 0, 'r', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', '', 'img', 1);

-- --------------------------------------------------------

--
-- Table structure for table `movies_blocks`
--

CREATE TABLE IF NOT EXISTS `movies_blocks` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `pos` varchar(2) NOT NULL default '',
  `file` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `template` varchar(255) NOT NULL default '0',
  `pages` varchar(255) NOT NULL default '',
  `hide_title` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `active` (`active`),
  KEY `pages` (`pages`),
  KEY `pos` (`pos`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `movies_blocks`
--

INSERT INTO `movies_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`, `hide_title`, `cat`) VALUES
(10, 'Search', 'l', '<form method="postt" action="search.php">\r\n<input type=text name="keyword" size="15" tabindex="1">\r\n<br>\r\n<select name="op">\r\n<option value="movies">Movies</option>\r\n<option value="news">News</option>\r\n<input type=submit value="Search" tabindex="1">\r\n</form>', 4, 1, '0', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', 0, 0),
(8, 'Main Menu', 'l', '<b>::</b> <a href=''index.php''>Main Page</a><br>\r\n<b>::</b> <a href=''browse.html''>Browse Movies</a><br>\r\n\r\n<b>::</b> <a href=''actors.html''>Actors</a><br>\r\n\r\n\r\n<b>::</b> <a href=''news.html''>News</a><br>\r\n<b>::</b> <a href=''statistics.php''>Statistics</a><br>\r\n<b>::</b> <a href=''contactus.php''>Contact Us</a><br>\r\n ', 0, 1, '0', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', 0, 0),
(29, 'Last Updates', 'c', '<?\r\nglobal $settings,$data;\r\n\r\n$qr=db_query("select * from movies_data order by date DESC limit 8") ;\r\n\r\nrun_template(''browse_movies_header'');\r\n\r\n$c=0 ;\r\n\r\n\r\nwhile ($data =db_fetch($qr)){\r\n\r\n   \r\nif ($c==$settings[''movies_cells'']) {\r\nrun_template(''browse_movies_sep'');\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\nrun_template(''browse_movies'');\r\n              \r\n}\r\nrun_template(''browse_movies_footer'');\r\n?>', 1, 1, '0', 'main,', 0, 0),
(11, 'Votes', 'r', '<?\r\n$qr_title = db_query("select * from movies_votes_cats  where active=1");\r\nif(db_num($qr_title)){\r\n\r\n$data_title = db_fetch($qr_title);\r\nprint "<center>$data_title[title]</center>";\r\n$qr = mysql_query("select * from movies_votes where cat=$data_title[id]");\r\nprint "<form action=\\"votes.php\\" method=\\"post\\">\r\n<input type=''hidden'' name=''action'' value=''vote_add''>\r\n";\r\n\r\n while ($data = mysql_fetch_array($qr)){\r\n\r\n        print "<input type=''radio'' value=''$data[id]'' name=''vote_id''>$data[title]<br>";\r\n\r\n\r\n\r\n }\r\nprint "<center><br><input type=''submit'' value=''Vote''> <br><br><a href=''votes.php''>Results</a></center></form>";\r\n}else{\r\nprint "<center>  No Active Votes </center>";\r\n}\r\n?>', 1, 1, '0', 'main,browse.php,movie_info.php,news.php,pages,search.php,votes.php,statics,contactus.php,', 0, 0),
(4, 'Online', 'l', '<?\r\nglobal $counter,$settings ;\r\n\r\nprint "<p align=center> There are $counter[online_users] Visitor ";\r\n\r\nif($settings[''online_members_count'']){\r\nprint " , $counter[online_members] Member ";\r\n}\r\n\r\nprint " Currently Browsing</p>";\r\n\r\nprint "<p dir=ltr align=center>Most Online Visitors are $counter[best_visit] in : <br> $counter[best_visit_time] <br></p>";\r\n\r\n', 3, 1, '0', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', 0, 0),
(18, 'Last News', 'c', '<?\r\nglobal $data,$phrases;\r\n$qr = db_query("select * from movies_news order by id DESC limit 4");\r\n\r\nif(db_num($qr)){\r\nprint "\r\n<hr width=100% class=separate_line size=\\"1\\">" ;\r\n\r\nwhile($data = db_fetch($qr)){\r\n\r\n\r\nrun_template(''browse_news'');  \r\n\r\n\r\n        }\r\n\r\n}else{\r\nprint "<center> $phrases[no_news]</center>";\r\n}\r\n       ?>', 5, 1, '0', 'main,', 0, 0),
(37, 'Most Rated', 'c', '<?\r\nglobal $settings,$data,$links,$phrases;\r\n\r\n$qr=db_query("select *  from movies_data where votes > 0 order by (votes / votes_total) DESC limit 4");\r\n\r\nif(db_num($qr)){\r\ncompile_template(get_template(''browse_movies_header''));\r\n\r\n$c=0 ;\r\n\r\n\r\nwhile ($data =db_fetch($qr)){\r\n\r\n   \r\nif ($c==$settings[''movies_cells'']) {\r\ncompile_template(get_template(''browse_movies_sep''));\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\ncompile_template(get_template(''browse_movies''));\r\n              \r\n}\r\ncompile_template(get_template(''browse_movies_footer''));\r\n}else{\r\nprint "<center> $phrases[no_movies]</center>";\r\n}\r\n?>', 4, 1, '0', 'main,', 0, 35),
(21, 'Categories', 'l', '<?\r\nglobal $links,$cats,$phrases;\r\n?>\r\n\r\n<script type="text/javascript" src="js/cats_menu.js"></script>\r\n\r\n<?\r\n$qr = db_query("select id,cat,name from movies_cats where active=1 order by cat,ord asc");\r\nif(db_num($qr)){\r\n\r\nwhile($data = db_fetch($qr)){\r\n    $cats[$data[''cat'']][]= array("id"=>$data[''id''],"name"=>$data[''name'']);\r\n}\r\nunset($data);\r\n\r\nprint "<ul id=\\"cats_menu\\">";\r\nforeach($cats[0] as $data){\r\nget_expand_menu_items($data);\r\n    \r\n}\r\nprint "</ul>";\r\n\r\n?>\r\n<script type="text/javascript">\r\nexpanded_initiate(); \r\n</script>\r\n\r\n<?\r\n}else{\r\nprint "<center>".$phrases[''no_cats'']."</center>";\r\n}\r\n\r\nfunction get_expand_menu_items($dx){\r\n    global $cats,$links;\r\n print "<li>\r\n<a href=\\"".str_replace("{id}",$dx[''id''],$links[''links_cats''])."\\" title=\\"$dx[name]\\"><img src=''images/folder_small.gif''>&nbsp;$dx[name]</a>";\r\n\r\nif(count($cats[$dx[''id'']])){\r\n    print "<ul>";\r\n foreach($cats[$dx[''id'']] as $dx2){\r\n get_expand_menu_items($dx2);\r\n    }   \r\n    \r\n    print "</ul>";\r\n}\r\n\r\nprint "</li>";\r\n}\r\n?>', 1, 1, '0', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', 0, 0),
(23, 'Statistics', 'l', '<?\r\nglobal $phrases;\r\n\r\n   $cnt_movies = db_qr_fetch("select count(id) as count from movies_data");\r\n\r\n$cnt_files = db_qr_fetch("select count(id) as count from movies_files");\r\n\r\n\r\n    $cnt_cats = db_qr_fetch("select count(id) as count from movies_cats");\r\n\r\n\r\nprint "\r\n\r\n<b> $phrases[cats_count] : </b> $cnt_cats[count] <br>\r\n <b>  $phrases[movies_count] : </b> $cnt_movies[count] <br>\r\n\r\n <b>  $phrases[files_count] : </b> $cnt_files[count] <br>\r\n";\r\n?>', 5, 1, '0', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', 0, 0),
(24, 'New !', 'r', '<?\r\nglobal $links;\r\n\r\n$qr = db_query("select movies_data.* from movies_new_menu,movies_data where movies_data.id=movies_new_menu.movie_id order by movies_new_menu.ord asc");\r\nprint "<center>";\r\n\r\nwhile($data=db_fetch($qr)){\r\n\r\n\r\nprint "<a href=\\"".str_replace("{id}",$data[''id''],$links[''links_movie_info''])."\\" title=\\"$data[name]\\"><img width=70 src=\\"".get_image($data[''thumb''])."\\" title=\\"$data[name]\\" border=0><br>$data[name]</a>".iif($data[''year''],"<br><span dir=''ltr''>( $data[year] )</span>")."<br><br>";\r\n}\r\n', 0, 1, '0', 'main,browse.php,movie_info.php,news.php,pages,search.php,votes.php,statics,contactus.php,', 0, 0),
(30, 'Members', 'l', '<? if(check_member_login()){\r\nglobal $member_data,$style ;\r\n\r\n\r\nprint "<center>  Welcome $member_data[username] <br> <br>" ;\r\n$nw_msgs = db_qr_fetch("select count(id) as count from movies_msgs where user=''$member_data[id]'' and opened=0 and sent=0");\r\n\r\nif($nw_msgs[''count''] >0){\r\nprint "<font color=red> You Have $nw_msgs[count] New Messages </font><br><br>";\r\n}\r\n\r\nprint "</center>\r\n\r\n<a href=''usercp.php''><img src=''$style[images]/my_favorite.gif''>&nbsp; Favorites</a><br>\r\n\r\n\r\n<a href=''messages.php''><img src=''$style[images]/my_messages.gif''>&nbsp; Messages</a><br>\r\n\r\n<a href=''usercp.php?action=profile''><img src=''$style[images]/my_profile.gif''>&nbsp; Profile</a><br>\r\n\r\n<a href=''usercp.php?action=friends''><img src=''$style[images]/friends_list.gif''>&nbsp; Friends </a><br>\r\n\r\n<a href=''usercp.php?action=black_list''><img src=''$style[images]/black_list.gif''>&nbsp; Black List</a><br>\r\n\r\n<a href=''login.php?action=logout''><img src=''$style[images]/logout.gif''>&nbsp; Logout </a>\r\n</center><br>";\r\n}else{\r\n?>\r\n<form method="POST" action="login.php">\r\n<input type=hidden name=action value=login>\r\n<input type=hidden name=re_link value="<? print $_SERVER[REQUEST_URI] ; ?>">\r\n<table border="0" width="100%">\r\n	<tr>\r\n		<td height="15"><span lang="ar-sa">Username :</span></td></tr><tr>\r\n		<td height="15"><input type="text" name="username" size="10"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="12"><span lang="ar-sa">Password :</span></td></tr><tr>\r\n		<td height="12" ><input type="password" name="password" size="10"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="23">\r\n		<p align="center"><input type="submit" value="Login"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="38"><span lang="ar-sa">\r\n		<a href="register.php">New Member ?</a><br>\r\n		<a href="index.php?action=forget_pass">Forgot Your Password ?</a></span></td>\r\n	</tr>\r\n</table>\r\n</form>\r\n\r\n<?\r\n}\r\n?>', 2, 1, '0', 'main,browse.php,movie_info.php,movie_actors.php,movie_photos.php,news.php,pages,search.php,votes.php,actor_photos.php,statics,contactus.php,', 0, 0),
(36, 'Most Downloaded', 'c', '<?\r\nglobal $settings,$data,$links;\r\n\r\n$qr=db_query("select movies_data.*  from movies_files,movies_data where movies_data.id=movies_files.cat group by movies_files.cat order by movies_files.downloads DESC limit 4");\r\n\r\ncompile_template(get_template(''browse_movies_header''));\r\n\r\n$c=0 ;\r\n\r\n\r\nwhile ($data =db_fetch($qr)){\r\n\r\n   \r\nif ($c==$settings[''movies_cells'']) {\r\ncompile_template(get_template(''browse_movies_sep''));\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\ncompile_template(get_template(''browse_movies''));\r\n              \r\n}\r\ncompile_template(get_template(''browse_movies_footer''));\r\n?>', 3, 1, '0', 'main,', 0, 35),
(35, 'Most Views', 'c', '<?\r\nglobal $settings,$data,$links;\r\n\r\n$qr=db_query("select movies_data.*  from movies_files,movies_data where movies_data.id=movies_files.cat group by movies_files.cat order by movies_files.views DESC limit 4");\r\n\r\ncompile_template(get_template(''browse_movies_header''));\r\n\r\n$c=0 ;\r\n\r\n\r\nwhile ($data =db_fetch($qr)){\r\n\r\n   \r\nif ($c==$settings[''movies_cells'']) {\r\ncompile_template(get_template(''browse_movies_sep''));\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\ncompile_template(get_template(''browse_movies''));\r\n              \r\n}\r\ncompile_template(get_template(''browse_movies_footer''));\r\n?>', 2, 1, '0', 'main,', 0, 0),
(38, 'Offers', 'c', '<?\r\n\r\n$qr=db_query("select * from movies_banners where `type` like ''offer'' and active=1 order by ord");\r\nif(db_num($qr)){\r\n\r\ninclude_once("includes/class_slider.php");\r\n\r\nopen_table();\r\n$slider = new slider("slider");      \r\n\r\nwhile($data=db_fetch($qr)){\r\n\r\n$ids[] = $data[''id''];\r\n\r\n$slider->start($data[''id'']);\r\nprint "<center>".iif($data[''url''],"<a href=\\"banner.php?id=$data[id]\\" target=_blank>").iif($data[''img''],"<img border=0 src=\\"$data[img]\\" alt=\\"$data[title]\\"><br><br>").$data[''content''].iif($data[''url''],"</a>")."</center>";\r\n\r\n$slider->end();  \r\n}\r\n\r\n\r\n$slider->run();\r\ndb_query("update movies_banners set views=views+1 where id IN (".implode(",",$ids).")");\r\nclose_table();\r\n}\r\n?>\r\n', 0, 1, 'no_title_no_border', 'main,', 1, 0),
(39, 'RSS & Sitemap', 'r', '<center>\r\n<a href=''rss.php''><img src=''images/rss.gif'' title=''RSS'' border=0><br>RSS</a>\r\n\r\n<hr class=separate_line size=1>\r\n<br>\r\n<a href=''sitemap.xml''><img src=''images/sitemap.gif'' title=''Sitemap'' border=0><br>Site Map</a>\r\n</center>', 2, 1, '0', 'main,browse.php,movie_info.php,news.php,pages,search.php,votes.php,statics,contactus.php,', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `movies_cats`
--

CREATE TABLE IF NOT EXISTS `movies_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `img` varchar(255) NOT NULL default '',
  `cat` int(11) NOT NULL default '0',
  `active` int(1) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `path` varchar(255) NOT NULL default '',
  `users` varchar(255) NOT NULL default '',
  `page_title` text NOT NULL,
  `page_description` text NOT NULL,
  `page_keywords` text NOT NULL,
  `download_for_members` int(1) NOT NULL,
  `watch_for_members` int(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `active` (`active`),
  KEY `cat` (`cat`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `movies_cats`
--

INSERT INTO `movies_cats` (`id`, `name`, `img`, `cat`, `active`, `ord`, `path`, `users`, `page_title`, `page_description`, `page_keywords`, `download_for_members`, `watch_for_members`) VALUES
(1, 'Movies', '', 0, 1, 1, '1,0', '', '', '', '', 0, 0),
(2, 'Series', '', 0, 1, 2, '2,0', '10', '', '', '', 0, 0),
(3, 'Arabic Movies', '', 1, 1, 1, '3,1,0', '', '', '', '', 0, 0),
(4, 'English Movies', '', 1, 1, 0, '4,1,0', '10', '', '', '', 0, 0),
(5, 'Indian Movies', '', 1, 1, 2, '5,1,0', '', '', '', '', 0, 0),
(6, 'Arabic Series', '', 2, 1, 2, '6,2,0', '', '', '', '', 0, 0),
(7, 'English Series', '', 2, 1, 1, '7,2,0', '', '', '', '', 0, 0),
(8, 'Turkish Series', '', 2, 1, 0, '8,2,0', '', '', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `movies_comments`
--

CREATE TABLE IF NOT EXISTS `movies_comments` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL default '0',
  `fid` int(11) NOT NULL default '0',
  `comment_type` varchar(100) NOT NULL default '',
  `content` text NOT NULL,
  `time` int(14) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `movie_id` (`fid`,`comment_type`,`active`),
  KEY `active` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_confirmations`
--

CREATE TABLE IF NOT EXISTS `movies_confirmations` (
  `id` int(11) NOT NULL auto_increment,
  `type` text NOT NULL,
  `old_value` text NOT NULL,
  `new_value` text NOT NULL,
  `cat` int(11) NOT NULL default '0',
  `code` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_confirmations`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_countries`
--

CREATE TABLE IF NOT EXISTS `movies_countries` (
  `name` varchar(80) NOT NULL default '',
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movies_countries`
--

INSERT INTO `movies_countries` (`name`) VALUES
('Afghanistan'),
('Albania'),
('Algeria'),
('American Samoa'),
('Andorra'),
('Angola'),
('Anguilla'),
('Antarctica'),
('Antigua and Barbuda'),
('Argentina'),
('Armenia'),
('Aruba'),
('Australia'),
('Austria'),
('Azerbaijan'),
('Bahamas'),
('Bahrain'),
('Bangladesh'),
('Barbados'),
('Belarus'),
('Belgium'),
('Belize'),
('Benin'),
('Bermuda'),
('Bhutan'),
('Bolivia'),
('Bosnia and Herzegovina'),
('Botswana'),
('Bouvet Island'),
('Brazil'),
('British Indian Ocean Territory'),
('Brunei Darussalam'),
('Bulgaria'),
('Burkina Faso'),
('Burundi'),
('Cambodia'),
('Cameroon'),
('Canada'),
('Cape Verde'),
('Cayman Islands'),
('Central African Republic'),
('Chad'),
('Chile'),
('China'),
('Christmas Island'),
('Cocos (Keeling) Islands'),
('Colombia'),
('Comoros'),
('Congo'),
('Cook Islands'),
('Costa Rica'),
('Cote D''Ivoire'),
('Croatia'),
('Cuba'),
('Cyprus'),
('Czech Republic'),
('Denmark'),
('Djibouti'),
('Dominica'),
('Dominican Republic'),
('Ecuador'),
('Egypt'),
('El Salvador'),
('Equatorial Guinea'),
('Eritrea'),
('Estonia'),
('Ethiopia'),
('Faroe Islands'),
('Fiji'),
('Finland'),
('France'),
('Gabon'),
('Gambia'),
('Georgia'),
('Germany'),
('Ghana'),
('Gibraltar'),
('Greece'),
('Greenland'),
('Grenada'),
('Guadeloupe'),
('Guam'),
('Guatemala'),
('Guinea'),
('Guinea-Bissau'),
('Guyana'),
('Haiti'),
('Honduras'),
('Hong Kong'),
('Hungary'),
('Iceland'),
('India'),
('Indonesia'),
('Iraq'),
('Ireland'),
('Israel'),
('Italy'),
('Jamaica'),
('Japan'),
('Jordan'),
('Kazakhstan'),
('Kenya'),
('Kiribati'),
('Korea, Republic of'),
('Kuwait'),
('Kyrgyzstan'),
('Latvia'),
('Lebanon'),
('Lesotho'),
('Liberia'),
('Libyan Arab Jamahiriya'),
('Liechtenstein'),
('Lithuania'),
('Luxembourg'),
('Macao'),
('Madagascar'),
('Malawi'),
('Malaysia'),
('Maldives'),
('Mali'),
('Malta'),
('Marshall Islands'),
('Martinique'),
('Mauritania'),
('Mauritius'),
('Mayotte'),
('Mexico'),
('Monaco'),
('Mongolia'),
('Montserrat'),
('Morocco'),
('Mozambique'),
('Myanmar'),
('Namibia'),
('Nauru'),
('Nepal'),
('Netherlands'),
('Netherlands Antilles'),
('New Caledonia'),
('New Zealand'),
('Nicaragua'),
('Niger'),
('Nigeria'),
('Niue'),
('Norfolk Island'),
('Norway'),
('Oman'),
('Pakistan'),
('Palau'),
('Palestine'),
('Panama'),
('Papua New Guinea'),
('Paraguay'),
('Peru'),
('Philippines'),
('Pitcairn'),
('Poland'),
('Portugal'),
('Puerto Rico'),
('Qatar'),
('Reunion'),
('Romania'),
('Russian Federation'),
('Rwanda'),
('Saint Helena'),
('Saint Kitts and Nevis'),
('Saint Lucia'),
('Saint Pierre and Miquelon'),
('Samoa'),
('San Marino'),
('Sao Tome and Principe'),
('Saudi Arabia'),
('Senegal'),
('Serbia and Montenegro'),
('Seychelles'),
('Sierra Leone'),
('Singapore'),
('Slovakia'),
('Slovenia'),
('Solomon Islands'),
('Somalia'),
('South Africa'),
('Spain'),
('Sri Lanka'),
('Sudan'),
('Suriname'),
('Svalbard and Jan Mayen'),
('Swaziland'),
('Sweden'),
('Switzerland'),
('Syrian Arab Republic'),
('Taiwan, Province of China'),
('Tajikistan'),
('Thailand'),
('Timor-Leste'),
('Togo'),
('Tokelau'),
('Tonga'),
('Trinidad and Tobago'),
('Tunisia'),
('Turkey'),
('Turkmenistan'),
('Turks and Caicos Islands'),
('Tuvalu'),
('Uganda'),
('Ukraine'),
('United Arab Emirates'),
('United Kingdom'),
('United States'),
('Uruguay'),
('Uzbekistan'),
('Vanuatu'),
('Venezuela'),
('Viet Nam'),
('Virgin Islands, British'),
('Virgin Islands, U.s.'),
('Wallis and Futuna'),
('Western Sahara'),
('Yemen'),
('Zambia'),
('Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `movies_data`
--

CREATE TABLE IF NOT EXISTS `movies_data` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `details` text NOT NULL,
  `img` text NOT NULL,
  `thumb` text NOT NULL,
  `date` int(10) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL default '0',
  `year` int(11) NOT NULL default '0',
  `director` varchar(50) NOT NULL default '',
  `page_title` varchar(255) NOT NULL default '',
  `page_description` varchar(255) NOT NULL default '',
  `page_keywords` varchar(255) NOT NULL default '',
  `field_3` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_fields_sets`
--

CREATE TABLE IF NOT EXISTS `movies_fields_sets` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `style` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `enable_search` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `movies_fields_sets`
--

INSERT INTO `movies_fields_sets` (`id`, `name`, `details`, `type`, `value`, `style`, `ord`, `enable_search`) VALUES
(3, 'Type', '', 'select', 'Action\r\nComedy\r\nDrama\r\nRomance\r\nAnimation', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `movies_files`
--

CREATE TABLE IF NOT EXISTS `movies_files` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `url_watch` text NOT NULL,
  `date` int(11) NOT NULL default '0',
  `downloads` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `ord` (`ord`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_files`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_hooks`
--

CREATE TABLE IF NOT EXISTS `movies_hooks` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `hookid` varchar(255) NOT NULL,
  `code` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_hooks`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_links`
--

CREATE TABLE IF NOT EXISTS `movies_links` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `movies_links`
--

INSERT INTO `movies_links` (`id`, `name`, `value`) VALUES
(1, 'links_actor_photos', 'actor_{id}/photos.html'),
(2, 'links_movie_files', 'movie_{id}/files.html'),
(3, 'links_movie_actors', 'movie_{id}/actors.html'),
(4, 'links_movie_subtitles', 'movie_{id}/subtitles.html'),
(5, 'links_actor_photo', 'actor/photo_{id}.html'),
(6, 'file_watch', 'watch_{id}.html'),
(7, 'links_profile', 'profile_{id}.html'),
(8, 'links_movie_info', 'movie_{id}/index.html'),
(9, 'links_cats', 'cat_{id}.html'),
(10, 'links_pages', 'page_{id}.html'),
(11, 'links_browse_news', 'news_{cat}.html'),
(12, 'links_browse_news_w_pages', 'news_{cat}_{start}.html'),
(13, 'links_actor_details', 'actor_{id}/index.html'),
(14, 'links_actors', 'actors.html'),
(15, 'links_movie_photo', 'movie/photo_{id}.html'),
(16, 'links_movie_photos', 'movie_{id}/photos.html'),
(17, 'file_download', 'download_{id}'),
(18, 'subtitle_download', 'subtitle_download_{id}'),
(19, 'file_watch_ext', 'watch_{id}'),
(20, 'links_cats_w_pages', 'cat_{id}_{start}_{orderby}_{sort}.html'),
(21, 'news_details', 'news_view_{id}.html'),
(22, 'links_news', 'news.html'),
(23, 'actors_w_pages', 'actors_{start}.html');

-- --------------------------------------------------------

--
-- Table structure for table `movies_members`
--

CREATE TABLE IF NOT EXISTS `movies_members` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL default '',
  `password` varchar(100) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `active_code` varchar(255) NOT NULL default '',
  `date` int(11) NOT NULL default '0',
  `last_login` int(11) NOT NULL default '0',
  `usr_group` int(11) NOT NULL default '0',
  `birth` date NOT NULL default '0000-00-00',
  `country` varchar(90) NOT NULL default '',
  `gender` varchar(10) NOT NULL default '',
  `members_list` int(11) NOT NULL default '0',
  `img` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `pm_email_notify` int(1) NOT NULL,
  `field_6` text NOT NULL,
  `privacy_settings` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_members`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_members_black`
--

CREATE TABLE IF NOT EXISTS `movies_members_black` (
  `id` int(11) NOT NULL auto_increment,
  `uid1` int(11) NOT NULL,
  `uid2` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_members_black`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_members_favorites`
--

CREATE TABLE IF NOT EXISTS `movies_members_favorites` (
  `id` int(11) NOT NULL auto_increment,
  `fid` int(11) NOT NULL default '0',
  `uid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_members_favorites`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_members_friends`
--

CREATE TABLE IF NOT EXISTS `movies_members_friends` (
  `id` int(11) NOT NULL auto_increment,
  `uid1` int(11) NOT NULL,
  `uid2` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_members_friends`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_members_msgs`
--

CREATE TABLE IF NOT EXISTS `movies_members_msgs` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `owner` int(11) NOT NULL default '0',
  `uid` int(11) NOT NULL default '0',
  `username` varchar(255) NOT NULL,
  `opened` int(1) NOT NULL default '0',
  `date` int(11) NOT NULL default '0',
  `sent` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `user` (`owner`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_members_msgs`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_members_sets`
--

CREATE TABLE IF NOT EXISTS `movies_members_sets` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `style` varchar(255) NOT NULL,
  `required` int(1) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `required` (`required`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `movies_members_sets`
--

INSERT INTO `movies_members_sets` (`id`, `name`, `details`, `type`, `value`, `style`, `required`, `ord`) VALUES
(6, 'Telephone', '', 'text', '', '', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `movies_meta`
--

CREATE TABLE IF NOT EXISTS `movies_meta` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `title` text NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `movies_meta`
--

INSERT INTO `movies_meta` (`id`, `name`, `title`, `description`, `keywords`) VALUES
(1, 'movie_info', '{name} {year} - {cat}', 'Movie {name} {year} Details , Category {cat} , {cat} Movies , Download {name} , Watch {name}', 'Movie {name} {year} Details , Category {cat} , {cat} Movies , Download {name} , Watch {name}'),
(2, 'cats', '{name}{sp}{page}', 'Category {name} , {name} 2010 , {name} 2010 , Download {name} , Watch {name} {page}', 'Category {name} , {name} 2010 , {name} 2010 , Download {name} , Watch {name} {page}'),
(3, 'news', '{name}', '{name} , Read {name} , News {name} , Details {name}', '{name} , Read {name} , News {name} , Details {name}'),
(4, 'actor_details', '{name}', 'Info {name} , Details {name} , News{name} , Photos {name} , Movies {name}', 'Info {name} , Details {name} , News{name} , Photos {name} , Movies {name}'),
(5, 'movie_watch', 'Watch {file} - {movie} {year} - {cat}', 'Watch {movie} {year},Watch {file} , Download {movie} {year}, Download {file} , {cat}', 'Watch {movie} {year},Watch {file} , Download {movie} {year}, Download {file} , {cat}'),
(6, 'movie_photo', 'Picture {id} - {movie} {year} - {cat}', 'Picture {id} , {name} , {movie} , {year} , {cat}', 'Picture {id} , {name} , {movie} , {year} , {cat}'),
(7, 'movie_photos', 'Movie''s Photos - {movie} {year} - {cat}', 'Movie''s Photos , {movie} , {year} , {cat}', 'Movie''s Photos , {movie} , {year} , {cat}'),
(8, 'movie_actors', 'Actors of {movie} {year} - {cat}', '{movie} {year} Actors , {cat} , Watch {movie} , Download {movie}', '{movie} {year} Actors , {cat} , Watch {movie} , Download {movie}'),
(9, 'movie_files', '{movie} {year} Files - {cat}', '{movie} {year} Files , {cat} , Watch {movie} , Download {movie}', '{movie} {year} Files , {cat} , Watch {movie} , Download {movie}'),
(10, 'movie_subtitles', 'Movie''s Subtitles {movie} {year} - {cat}', 'Movie''s Subtitles {movie} {year} , {cat} , Watch {movie} , Download {movie}', 'Movie''s Subtitles {movie} {year} , {cat} , Watch {movie} , Download {movie}'),
(11, 'actor_photo', 'Photo {id} - {name}', 'Picture {id} , {name} Info ,{name} Details , News {name} , Photos {name} , Movies {name}', 'Picture {id} , {name} Info ,{name} Details , News {name} , Photos {name} , Movies {name}'),
(12, 'actor_photos', 'Actor''s Photos - {name}', 'Actor''s Photos , Info {name} , Detials {name} , News {name} , Photos of {name} , Movies {name}', 'Actor''s Photos , Info {name} , Detials {name} , News {name} , Photos of {name} , Movies {name}'),
(13, 'member_profile', '{name} - Profile', 'Profile {name} , {name} profile , Member {name} , Favorite Movies {name} , Contact {name}', 'Profile {name} , {name} profile , Member {name} , Favorite Movies {name} , Contact {name}'),
(14, 'pages', '{name}', 'Page {name} , Details of {name}', 'Page {name} , Details of {name}'),
(15, 'actors', 'Actors{sp}{page}', 'Actress, Director, Actors , Actors,  Producer {page}', 'Actress, Director, Actors , Actors,  Producer {page}'),
(16, 'news_cats', '{name}{sp}{page}', '{name} , News {name} , New {name} , {name} news , {name} Exclusive', '{name} , News {name} , New {name} , {name} news , {name} Exclusive');

-- --------------------------------------------------------

--
-- Table structure for table `movies_news`
--

CREATE TABLE IF NOT EXISTS `movies_news` (
  `id` int(11) NOT NULL auto_increment,
  `writer` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `details` text NOT NULL,
  `date` int(11) NOT NULL,
  `img` text NOT NULL,
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_news`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_news_cats`
--

CREATE TABLE IF NOT EXISTS `movies_news_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `ord` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_news_cats`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_new_menu`
--

CREATE TABLE IF NOT EXISTS `movies_new_menu` (
  `id` int(11) NOT NULL auto_increment,
  `movie_id` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `movie_id` (`movie_id`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_new_menu`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_pages`
--

CREATE TABLE IF NOT EXISTS `movies_pages` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `active` (`active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `movies_pages`
--

INSERT INTO `movies_pages` (`id`, `title`, `content`, `active`) VALUES
(1, 'Test Page', '<p>\r\n	Test Page</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `movies_photos`
--

CREATE TABLE IF NOT EXISTS `movies_photos` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `cat` int(11) NOT NULL default '0',
  `img` text NOT NULL,
  `img_resized` text NOT NULL,
  `thumb` text NOT NULL,
  `date` int(10) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`),
  KEY `ord` (`ord`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_photos`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_photos_tags`
--

CREATE TABLE IF NOT EXISTS `movies_photos_tags` (
  `id` int(11) NOT NULL auto_increment,
  `photo_id` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `actor_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `actor_id` (`actor_id`),
  KEY `photo_id` (`photo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_photos_tags`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_phrases`
--

CREATE TABLE IF NOT EXISTS `movies_phrases` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `cat` varchar(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1467 ;

--
-- Dumping data for table `movies_phrases`
--

INSERT INTO `movies_phrases` (`id`, `name`, `value`, `cat`) VALUES
(3, 'the_movies_count', 'No. of Movies', 'main'),
(5, 'last_update', 'Last Update', 'main'),
(9, 'download', 'Download', 'main'),
(12, 'send2friend', 'Send to Friend', 'main'),
(14, 'watch', 'Watch', 'main'),
(15, 'vote_video', 'Movie Rate', 'main'),
(20, 'err_no_videos', 'No Movies under this Category', 'main'),
(22, 'err_no_cats', 'No Categories', 'main'),
(39, 'subtitles', 'Subtitles', 'main'),
(38, 'err_no_subtitles', 'No Subtitles', 'main'),
(29, 'vote_video_thnx_msg', 'Movie Rating Done.', 'main'),
(1289, 'rating_expire_msg', 'Sorry, You can rate every {hours} Hour', 'cp'),
(46, 'the_files_count', 'No. of Files', 'main'),
(48, 'home_page', 'Main Page', 'main'),
(49, 'movie_pictures', 'Movie Pictures', 'main'),
(50, 'back_to_news', 'Back to News', 'main'),
(1442, 'no_banners', 'No Banners', 'cp'),
(1440, 'movies_list', 'Movies List', 'cp'),
(1441, 'the_movie', 'Movie', 'cp'),
(1438, 'watch_for_members', 'Watch for Members Only', 'cp'),
(1439, 'download_for_members', 'Download For Members Only', 'cp'),
(1454, 'movie_actors_cells', 'Movie''s Actors Cells', 'main'),
(1437, 'cat_del_warn', 'Deleting this category will delete all sub categories and movies , Continue ?', 'cp'),
(1455, 'movie_actors_max', 'No. of Actors in Movie''s Page', 'main'),
(1436, 'add_by_name', 'Add by Name', 'cp'),
(1434, 'news_votes', 'News Votes', 'cp'),
(1435, 'add_by_id', 'Add by ID', 'cp'),
(1452, 'movie_subtitles_list_max', 'No. of Subtitles in Movie''s Page', 'cp'),
(1433, 'news_views', 'News Views', 'cp'),
(1432, 'actors_photos_votes', 'Actors Photos Votes', 'cp'),
(64, 'sex', 'Gender', 'main'),
(65, 'male', 'Male', 'main'),
(66, 'female', 'Female', 'main'),
(1431, 'actors_photos_views', 'Actors Photos Views', 'cp'),
(1451, 'movie_files_list_max', 'No. of Files in Movie''s Page', 'cp'),
(1430, 'actors_votes', 'Actors Votes', 'cp'),
(1429, 'actors_views', 'Actors Views', 'cp'),
(1428, 'movies_photos_votes', 'Movies Photos Votes', 'cp'),
(1450, 'movie_photos_max', 'No. of Photos in Movie''s Page', 'cp'),
(1427, 'movies_photos_views', 'Movies Photos Views', 'cp'),
(1426, 'movies_votes', 'Movies Votes', 'cp'),
(1425, 'movies_views', 'Movies Views', 'cp'),
(1424, 'movies_files_downloads', 'Movies Files Downloads', 'cp'),
(1423, 'movies_files_views', 'Moives Files Views', 'cp'),
(1422, 'manage_movies_cats', 'Movies & Categories', 'cp'),
(1421, 'actor_name', 'Actor Name', 'cp'),
(1420, 'actors_list', 'Actors List', 'cp'),
(1449, 'movie_photos_cells', 'Movie''s Photos Cells', 'cp'),
(1447, 'movie_files_list_ajax', 'Ajax Movie''s files List', 'cp'),
(625, 'click_and_drag_to_change_order', 'Click and Drag to Change Order', 'cp'),
(626, 'access_log', 'Access Log', 'cp'),
(1294, 'comment_is_waiting_admin_review', 'Your Comment Added Successfully , Waiting for Admin Review', 'cp'),
(628, 'contact_us', 'Contact us', 'main'),
(629, 'no_results', 'No Results', 'main'),
(630, 'search_results', 'Search Results', 'main'),
(631, 'currency_mark', 'Currency Mark', 'cp'),
(633, 'admin_email', 'Admin Email', 'cp'),
(634, 'page_description', 'Page Description', 'cp'),
(635, 'hide_title', 'Hide Title', 'cp'),
(636, 'err_no_page', 'Sorry , This page is not exists', 'main'),
(637, 'type_search_keyword', 'Please type search keyword , Minimum {letters} Letters', 'main'),
(638, 'the_name', 'Name', 'main'),
(639, 'add_date', 'Add Date', 'main'),
(640, 'err_wrong_url', 'Wrong URL', 'main'),
(1388, 'page_number_x', 'Page # {x}', 'main'),
(642, 'the_details', 'Details', 'cp'),
(643, 'pages', 'Pages', 'main'),
(644, 'the_writer', 'Writer', 'main'),
(645, 'the_news_archive', 'News Archive', 'main'),
(647, 'the_price', 'The Price', 'main'),
(648, 'vote_select', 'Vote', 'main'),
(649, 'vote_do', 'Vote', 'main'),
(650, 'send2friend_subject', 'Invitation from Your Friend', 'main'),
(651, 'send2friend_done', 'Invitation sent to your Friend', 'main'),
(652, 'your_name', 'Your Name', 'main'),
(653, 'your_email', 'Your Email', 'main'),
(654, 'your_friend_email', 'Friend Email', 'main'),
(655, 'send', 'Send', 'main'),
(656, 'err_vote_expire_hours', 'Sorry, You can vote Every {vote_expire_hours} Hour', 'main'),
(657, 'add2favorite', 'Add to Favorite', 'main'),
(658, 'add2fav_success', 'Added to Favorite Successfully', 'main'),
(659, 'register_closed', 'Sorry , Registration is closed', 'main'),
(660, 'no_news', 'No News', 'main'),
(1293, 'please_select_movies', 'Please Select Movies', 'cp'),
(663, 'the_phrases', 'Phrases', 'cp'),
(664, 'welcome_to_cp', 'Welcome to Control Panel', 'cp'),
(665, 'php_version', 'PHP Version', 'cp'),
(666, 'mysql_version', 'MySQL Version', 'cp'),
(667, 'zend_version', 'Zend Optimizer Version', 'cp'),
(668, 'the_version', 'Version', 'cp'),
(669, 'cp_available', 'Available', 'cp'),
(670, 'cp_not_available', 'Not Available', 'cp'),
(671, 'gd_library', 'GD Library', 'cp'),
(672, 'gd_install_required', 'Gd library is not installed , without it script will not work fine.', 'cp'),
(673, 'cp_addons', 'Plugins', 'cp'),
(674, 'no_addons', 'No Plugins', 'cp'),
(675, 'edit', 'Edit', 'cp'),
(676, 'register', 'Register', 'main'),
(677, 'register_email_exists', 'Email Already Exists', 'main'),
(678, 'register_user_exists', 'Sorry , Username {username} Already Exists', 'main'),
(679, 'reg_complete', 'Registration Complete Successfully', 'main'),
(681, 'err_fileds_not_complete', 'Please Fill All Fields', 'main'),
(682, 'err_passwords_not_match', 'Password is not match it', 'main'),
(683, 'email', 'Email', 'main'),
(684, 'username', 'Username', 'main'),
(685, 'password', 'Password', 'main'),
(686, 'cp_login_do', 'Login', 'cp'),
(687, 'cp_username', 'Username', 'cp'),
(688, 'cp_password', 'Password', 'cp'),
(689, 'the_content_type', 'Content Type', 'cp'),
(690, 'the_url', 'URL', 'cp'),
(691, 'bnr_appearance_places', 'Appearance Places', 'cp'),
(692, 'bnr_appearance_pages', 'Appearance Pages', 'cp'),
(693, 'add_after_menu_number', 'Add After Menu #', 'cp'),
(694, 'login_do', 'Login', 'cp'),
(695, 'bnr_ctype_code', 'Code', 'cp'),
(696, 'bnr_ctype_img', 'Image / URL', 'cp'),
(697, 'the_code', 'Code', 'cp'),
(698, 'bnr_open', 'Site-Open', 'cp'),
(699, 'bnr_close', 'Site-Close', 'cp'),
(700, 'bnr_menu', 'Menu', 'cp'),
(701, 'bnr_header', 'Header', 'cp'),
(702, 'bnr_footer', 'Footer', 'cp'),
(703, 'bnr_menu_pos', 'on', 'cp'),
(704, 'the_left', 'The Left', 'cp'),
(705, 'the_center', 'The Center', 'cp'),
(706, 'the_right', 'The Rigth', 'cp'),
(707, 'bnr_the_menu', 'The Menu', 'cp'),
(708, 'bnr_the_visits', 'Visits', 'cp'),
(709, 'bnr_appearance_count', 'Appearance Count', 'cp'),
(710, 'add_button', 'Add', 'cp'),
(711, 'the_order', 'Order', 'cp'),
(712, 'the_image', 'Picture', 'cp'),
(713, 'the_title', 'Title', 'cp'),
(714, 'delete', 'Delete', 'cp'),
(715, 'pages_lang', 'Pages Language', 'cp'),
(716, 'pages_encoding', 'Pages Encoding', 'cp'),
(717, 'cp_enable_browsing', 'Enable Browsing', 'cp'),
(718, 'cp_opened', 'Opened', 'cp'),
(719, 'cp_closed', 'Closed', 'cp'),
(720, 'cp_browsing_closing_msg', 'Browsing Close Message', 'cp'),
(721, 'site_closed_for_visitors', 'Website Closed For Visitors', 'main'),
(722, 'cp_mailing_sending_to', 'Sending to', 'cp'),
(723, 'cp_send_as', 'Send As', 'cp'),
(724, 'cp_as_email', 'Email', 'cp'),
(725, 'next_page', 'Next Page', 'cp'),
(726, 'failed', 'Failed', 'cp'),
(727, 'cp_as_pm', 'Personal Message', 'cp'),
(728, 'cp_send_to', 'Send To', 'cp'),
(729, 'all_members', 'All Members', 'cp'),
(730, 'one_member', 'One Member', 'cp'),
(731, 'sender_name', 'Sender Name', 'cp'),
(732, 'sender_email', 'Sender Email', 'cp'),
(733, 'msg_type', 'Message Type', 'cp'),
(734, 'msg_encoding', 'Message Encoding', 'cp'),
(735, 'msg_subject', 'Message Subject', 'cp'),
(736, 'start_from', 'Start From', 'cp'),
(737, 'mailing_emails_perpage', 'Emails Per Page', 'cp'),
(738, 'auto_pages_redirection', 'Auto Pages Redirection', 'cp'),
(739, 'cp_url_fopen_disabled_msg', 'your server settings does not allow you to import file from external url', 'cp'),
(740, 'err_url_x_invalid', 'Url : {url} is invalid', 'cp'),
(741, 'local_file_uploader', 'Local File', 'cp'),
(742, 'external_file_uploader', 'External File', 'cp'),
(743, 'cp_photo_resize_width', 'width', 'cp'),
(744, 'cp_photo_resize_hieght', 'hieght', 'cp'),
(745, 'view', 'View', 'cp'),
(746, 'members_mailing', 'Members Mailing', 'cp'),
(747, 'yes', 'Yes', 'main'),
(748, 'no', 'No', 'main'),
(749, 'cp_mng_members', 'Members Managment', 'cp'),
(750, 'members_custom_fields', 'Members Custom Fields', 'cp'),
(751, 'cp_members_remote_db', 'Remote Database', 'cp'),
(752, 'the_members', 'Members', 'cp'),
(753, 'cp_add_new_template', 'Add New Template', 'cp'),
(754, 'the_description', 'Description', 'cp'),
(755, 'cp_edit_templates', 'Edit Templates', 'cp'),
(756, 'main_page', 'Main Page', 'cp'),
(757, 'the_templates', 'Templates', 'cp'),
(758, 'style_settings', 'Settings', 'cp'),
(759, 'add_style', 'Add new Styles', 'cp'),
(760, 'style_selectable', 'Selectable', 'cp'),
(761, 'template_name', 'Template Name', 'cp'),
(762, 'template_description', 'Template Description', 'cp'),
(763, 'add_new_template', 'Add New Template', 'cp'),
(764, 'are_you_sure', 'Are You Sure ?', 'cp'),
(765, 'the_database', 'The Database', 'cp'),
(766, 'backup', 'Backup', 'cp'),
(767, 'db_repair_tables_do', 'Repair Tables', 'cp'),
(768, 'cp_db_backup_do', 'Do Backup now', 'cp'),
(769, 'the_file_path', 'File Path', 'cp'),
(770, 'db_backup_saveto_server', 'Save on Your website space', 'cp'),
(771, 'db_backup_saveto_pc', 'Save on Your Computer', 'cp'),
(772, 'cp_db_backup', 'Database Backup', 'cp'),
(773, 'the_size', 'Size', 'cp'),
(774, 'the_table', 'Table', 'cp'),
(775, 'the_status', 'Status', 'cp'),
(776, 'please_select_tables_to_rapair', 'Please Select tables that you want to repair', 'cp'),
(777, 'cp_repairing_table', 'Repairing ', 'cp'),
(778, 'done', 'Done', 'cp'),
(779, 'cp_db_check_repair', 'Check / Repair', 'cp'),
(780, 'backup_done_successfully', 'Backup Done Successfully', 'cp'),
(781, 'the_search', 'Search', 'cp'),
(782, 'members_count', 'Members', 'cp'),
(783, 'cp_remote_members_db', 'Remote Members Database', 'cp'),
(784, 'use_remote_db', 'Use Remote Database', 'cp'),
(785, 'db_host', 'Database Host', 'cp'),
(786, 'db_name', 'Database Name', 'cp'),
(787, 'db_username', 'Database Username', 'cp'),
(788, 'members_table', 'Members Table Name', 'cp'),
(789, 'note', 'Note', 'cp'),
(790, 'members_remote_db_wizzard_note', 'when you use a new Members remote database you have to run Remote Database Wizzard to check if the database is compatible with script and setup it', 'cp'),
(791, 'members_remote_db_wizzard', 'Remote Database Wizard', 'cp'),
(792, 'chng_field_type_success', 'Field type changed successfully', 'cp'),
(793, 'chng_field_type_failed', 'unable to change field type , please change it manually from your database admin application', 'cp'),
(794, 'add_field_failed', 'unable to add field , please add it manually from your database admin application', 'cp'),
(795, 'add_field_success', 'Field added successfully', 'cp'),
(796, 'members_remote_db_compatible', 'Remote Database is compatible', 'cp'),
(797, 'members_remote_db_uncompatible', 'the database is not compatible with script, please check and correct the errors and run the wizzard again', 'cp'),
(798, 'wrong_remote_db_name', 'Wrong Remote Database name', 'cp'),
(799, 'wrong_remote_db_connect_info', 'Error while connecting to remote database , please check connection info', 'cp'),
(800, 'members_remote_db_disabled', 'System is disabled', 'cp'),
(801, 'no_members_custom_fields', 'No Custom Fields', 'cp'),
(802, 'add_member_custom_field', 'Add New Field', 'cp'),
(803, 'the_type', 'Type', 'cp'),
(804, 'textbox', 'Text box', 'cp'),
(805, 'textarea', 'Text Area', 'cp'),
(806, 'select_menu', 'Select Menu', 'cp'),
(807, 'radio_button', 'Radio Button', 'cp'),
(808, 'checkbox', 'Checkbox', 'cp'),
(809, 'default_value', 'Default Value', 'cp'),
(810, 'put_every_option_in_sep_line', 'For Options , put every option in new line', 'cp'),
(811, 'required', 'Required', 'cp'),
(812, 'addition_style', 'Field Style', 'cp'),
(813, 'addition_fields', 'Addition Fields', 'cp'),
(814, 'this_member_not_exists', 'This Member is not exists', 'cp'),
(815, 'members_local_db_clean_wizzard', 'Local Database Clean Wizard', 'cp'),
(816, 'members_local_db_clean_note', 'When you use a remote or local database , some members data like private messages , favorites , custom fields , etc..  is stored on local database , so it', 'cp'),
(817, 'members_local_db_clean_description', 'Wizard will delete any members data as listed , please make sure that tables does not containing any important data then click on process button', 'cp'),
(818, 'members_msgs_table', 'Members Private Messages Table', 'cp'),
(819, 'members_favorite_table', 'Members Favorite files Table', 'cp'),
(820, 'members_custom_fields_table', 'Members Custom Fields Table', 'cp'),
(821, 'members_confirmations_table', 'Members Confirmations Table', 'cp'),
(822, 'process_done_successfully', 'Process Done Successfully', 'cp'),
(823, 'from', 'From', 'cp'),
(824, 'plz_enter_username_and_pwd', 'Please Enter the username and Password', 'main'),
(825, 'pwd_rest_request_msg_subject', 'Rest Password Request', 'cp'),
(826, 'rest_pwd_request_msg_sent', 'changing password confirmation email sent to you', 'cp'),
(827, 'pwd_rest_done_msg_subject', 'Your New Password !', 'cp'),
(828, 'pwd_rest_done', 'Your password changed and sent to your email', 'cp'),
(829, 'security_code', 'Security Code', 'cp'),
(830, 'email_activation_msg_subject', 'Email Activation', 'cp'),
(831, 'upload_file', 'Upload File', 'cp'),
(832, 'search_do', 'Search', 'cp'),
(833, 'birth', 'Birth', 'main'),
(834, 'country', 'Country', 'main'),
(835, 'select_from_menu', 'Select From Menu', 'main'),
(836, 'register_do', 'Register', 'main'),
(837, 'registered_before', 'You are already registered', 'main'),
(838, 'click_here', 'Click Here', 'main'),
(839, 'forgot_pass', 'Forgot your Password?', 'main'),
(840, 'login_info_sent', 'Login info sent to your email', 'main'),
(841, 'email_not_exists', 'Sorry , This Email is not Exists', 'main'),
(842, 'continue', 'Continue', 'main'),
(843, 'active_account', 'Account Activation', 'main'),
(844, 'active_acc_succ', 'Your Account Activated Successfullu', 'main'),
(845, 'active_acc_err', 'Sorry , Wrong URL or Account Already Activated', 'main'),
(1466, 'commets_per_request', 'Comments Per Request', 'cp'),
(846, 'login', 'Login', 'main'),
(847, 'newuser', 'New Member ?', 'main'),
(848, 'err_function_usage_denied', 'Error : You can', 'main'),
(849, 'err_emails_not_match', 'Email is not matching it', 'main'),
(850, 'email_confirm', 'Email Confirm', 'main'),
(851, 'err_sec_code_not_valid', 'Security code is not valid', 'main'),
(852, 'registration', 'Registration', 'cp'),
(853, 'as_every_cat_settings', 'as Every Category Settings', 'cp'),
(854, 'enabled_for_all', 'Enabled For All', 'cp'),
(855, 'security_code_in_registration', 'Registration Security Code', 'cp'),
(856, 'auto_email_activate', 'Auto Email Activation', 'cp'),
(857, 'username_min_letters', 'username Min Letters', 'cp'),
(858, 'username_exludes', 'username Excludes', 'cp'),
(859, 'emails_msgs_default_type', 'Emails Default Messages Type', 'cp'),
(860, 'emails_msgs_default_encoding', 'Emails Default Messages Encoding', 'cp'),
(1465, 'show_online_members_count', 'Show No. of Online Members', 'main'),
(861, 'leave_blank_to_use_site_encoding', 'leave it blank to use site encoding', 'cp'),
(862, 'uploader_system', 'Uploader System', 'cp'),
(863, 'disable_uploader_msg', 'Uploader Disable Message', 'cp'),
(864, 'uploader_path', 'Uploading Path', 'cp'),
(865, 'uploader_allowed_types', 'Allowed Types', 'cp'),
(866, 'enabled', 'Enabled', 'cp'),
(867, 'disabled', 'Disable', 'cp'),
(868, 'password_confirm', 'Password Confirm', 'main'),
(869, 'err_username_min_letters', 'Error , username lenght is not meeting the minimum letters lenght', 'main'),
(870, 'err_email_not_valid', 'invalid Email address', 'main'),
(871, 'err_username_not_allowed', 'Username not allowed , please select another one', 'main'),
(872, 'reg_complete_need_activation', 'Registration done , please check your email for activation message.', 'main'),
(1463, 'news_comments', 'News Comments', 'main'),
(1464, 'comments_auto_activate', 'Comments Auto Activate', 'main'),
(873, 'req_addition_info', 'Required Addition Info', 'main'),
(874, 'not_req_addition_info', 'Not Required Addition Info', 'main'),
(875, 'your_email_changed_successfully', 'Your Email Changed Successfully', 'main'),
(876, 'this_account_already_activated', 'This Account Already Activated', 'main'),
(877, 'closed_account_cannot_activate', 'Sorry, This is Closed Account , you can not Activate it', 'main'),
(878, 'activation_msg_sent_successfully', 'Activation Message Sent Successfully', 'main'),
(879, 'register_date', 'Registration Date', 'cp'),
(880, 'last_login', 'Last Login', 'cp'),
(882, 'member_added_successfully', 'Member Added Successfully', 'cp'),
(883, 'please_fill_all_fields', 'Please Fill All Fields', 'cp'),
(884, 'member_edited_successfully', 'Member Edited successfully', 'cp'),
(885, 'add_member', 'Add Client', 'cp'),
(886, 'records_perpage', 'Records Per Page', 'cp'),
(887, 'member_edit', 'Edit Member', 'cp'),
(888, 'member_acc_type', 'Account type', 'cp'),
(1307, 'pages_links_settings', 'Pages Links Settings', 'cp'),
(890, 'acc_type_not_activated', 'Not Activated', 'cp'),
(891, 'acc_type_activated', 'Activated', 'cp'),
(892, 'acc_type_closed', 'Closed', 'cp'),
(893, 'leave_blank_for_no_change', 'Leave blank to not change', 'cp'),
(894, 'this_account_closed_cant_login', 'Sorrry , This Account is Closed', 'main'),
(895, 'this_account_not_activated', 'Sorry , This account is not activated', 'main'),
(896, 'chng_email_msg_subject', 'Changing email Confirm', 'main'),
(897, 'resend_activation_msg', 'resend Activation Message', 'main'),
(898, 'invalid_pwd', 'Sorry , Invalid Password', 'main'),
(899, 'invalid_username', 'Sorry , Invalid Username', 'main'),
(900, 'usercp_menu', 'Member Menu', 'main'),
(901, 'usercp_welcome_msg', 'Welcome {username} to Member Control Panel', 'main'),
(902, 'cp_hooks_fix_order', 'Fix Order', 'cp'),
(903, 'cp_hooks', 'Plugins / Hooks', 'cp'),
(904, 'no_hooks', 'No Hooks', 'cp'),
(905, 'add', 'Add', 'cp'),
(906, 'the_place', 'The Place', 'cp'),
(907, 'the_options', 'Options', 'cp'),
(908, 'the_default_template', 'Default Template', 'cp'),
(910, 'the_news', 'News', 'cp'),
(911, 'the_votes', 'Votes', 'cp'),
(912, 'the_statics', 'Statics', 'cp'),
(913, 'appearance_places', 'Appearance Places', 'cp'),
(914, 'the_blocks', 'Blocks', 'cp'),
(915, 'the_position', 'Position', 'cp'),
(916, 'right', 'Right', 'cp'),
(917, 'center', 'Center', 'cp'),
(918, 'left', 'Left', 'cp'),
(919, 'the_template', 'Template', 'cp'),
(920, 'to_up', 'To up', 'cp'),
(921, 'to_down', 'To down', 'cp'),
(922, 'enable', 'Enable', 'cp'),
(923, 'disable', 'Disable', 'cp'),
(924, 'cp_blocks_fix_order', 'Fix Order', 'cp'),
(925, 'cp_no_blocks', 'No Blocks', 'cp'),
(926, 'the_content', 'Content', 'cp'),
(927, 'logout', 'Logout', 'cp'),
(928, 'the_settings', 'Settings', 'cp'),
(929, 'do_button', 'Process', 'cp'),
(930, 'news_add', 'Add News', 'cp'),
(931, 'news_short_content', 'Short Details', 'cp'),
(932, 'auto_short_content_create', 'Auto Short details Create', 'cp'),
(933, 'the_date', 'Date', 'main'),
(934, 'all', 'All', 'main'),
(935, 'view_do', 'View', 'main'),
(936, 'os_and_browsers_statics', 'OS &amp; Browsers Statics', 'cp'),
(937, 'visitors_hits_statics', 'Visitors Hits Statics', 'cp'),
(938, 'online_visitors_statics', 'Online Visitors Statics', 'cp'),
(939, 'default_style', 'Default Style', 'cp'),
(940, 'search_min_letters', 'Search Minimum Letters', 'cp'),
(941, 'sorry_search_disabled', 'Sorry , Search Disabled', 'main'),
(1462, 'actor_photo_comments', 'Actor''s Photo Comments', 'main'),
(942, 'uploader_title', 'Uploader', 'cp'),
(943, 'pixel', 'Pixel', 'cp'),
(944, 'this_filetype_not_allowed', 'File type not allowed', 'cp'),
(945, 'the_file', 'File', 'cp'),
(946, 'auto_photos_resize', 'Auto Pictures Resize', 'cp'),
(947, 'upload_file_do', 'Upload', 'cp'),
(948, 'allowed_filetypes', 'Allowed Types', 'cp'),
(949, 'please_login_first', 'Please Login First', 'cp'),
(950, 'uploader_thumb_width', 'Uploader - Thumb Max Width', 'cp'),
(951, 'uploader_thumb_hieght', 'Uploader - Thumb Max Hieght', 'cp'),
(952, 'fixed', 'Fixed', 'cp'),
(953, 'send2friend_failed', 'Error whie sending , please try again later', 'main'),
(954, 'invalid_from_or_to_email', 'Invalid From or To Email Address', 'main'),
(955, 'urls_fields_add', 'Add new Field', 'cp'),
(956, 'access_denied', 'Access Denied', 'cp'),
(1305, 'seo_settings', 'SEO Settings', 'cp'),
(1306, 'pages_meta_settings', 'Pages Meta Data Settings', 'cp'),
(958, 'the_cat', 'Category', 'cp'),
(959, 'show_paid_option', 'Show Paid Option', 'cp'),
(960, 'no_new_files', 'No New Files', 'cp'),
(961, 'err_autosearch_folder_not_exists', 'Error, Auto Search folder is invalid', 'cp'),
(1461, 'actors_comments', 'Actor''s Comments', 'main'),
(962, 'auto_search', 'Auto Search', 'cp'),
(1413, 'months_ago', 'Months Ago', 'main'),
(1414, 'weeks_ago', 'Weeks Ago', 'main'),
(964, 'images_folder', 'Images Folder', 'cp'),
(965, 'edit_templates', 'Edit Templates', 'cp'),
(966, 'the_banners', 'Banners', 'cp'),
(967, 'users_and_permissions', 'Users &amp; Permissions', 'cp'),
(968, 'permissions_manage', 'Permissions Manage', 'cp'),
(969, 'cp_sections_permissions', 'Sections Permissions', 'cp'),
(971, 'cp_err_username_exists', 'Error , Username already Exists', 'cp'),
(972, 'cp_plz_enter_usr_pwd', 'Please Enter username and password', 'cp'),
(973, 'cp_edit_user_success', 'Edit User Done Successfully', 'cp'),
(974, 'cp_add_user', 'Add User', 'cp'),
(975, 'cp_email', 'Email', 'cp'),
(976, 'cp_user_group', 'Group', 'cp'),
(977, 'cp_user_admin', 'Administrator', 'cp'),
(978, 'cp_user_mod', 'Moderator', 'cp'),
(979, 'the_users', 'Users', 'cp'),
(980, 'edit_personal_acc_only', 'Sorry , You can only edit your account info', 'cp'),
(981, 'click_here_to_edit_ur_account', 'To edit your account click here', 'cp'),
(982, 'the_pages', 'Pages', 'cp'),
(983, 'pages_add', 'Add New Page', 'cp'),
(984, 'no_pages', 'No Pages', 'cp'),
(985, 'err_cat_access_denied', 'Category Access Denied', 'cp'),
(1460, 'movie_photo_comments', 'Movie''s Photo Comments', 'main'),
(986, 'you_can_edit_this_values_from_config_file', 'You can edit this values from config.php file', 'cp'),
(987, 'no_data', 'No Data', 'cp'),
(989, 'field_style', 'Field Style', 'cp'),
(991, 'asc', 'ASC', 'cp'),
(992, 'desc', 'DESC', 'cp'),
(993, 'payment_methods', 'Payment Methods', 'cp'),
(994, 'the_most_voted', 'Most Voted', 'cp'),
(998, 'store_field_add', 'Add', 'cp'),
(999, 'new', 'New', 'main'),
(1000, 'features', 'Features', 'main'),
(1002, 'fields_options_add_note', 'you can edit options by click on edit button after adding the field', 'cp'),
(1003, 'printable_copy', 'Print', 'main'),
(1004, 'kg', 'Kg', 'main'),
(1330, 'black_list_note', 'Members in this list cannot see your profile or send you private messages ', 'main'),
(1006, 'the_favorite', 'Favorite', 'main'),
(1007, 'no_files', 'No Files', 'main'),
(1008, 'send_new_msg', 'Send New Message', 'main'),
(1009, 'the_messages', 'Messages', 'main'),
(1010, 'used_messages', 'Used Messages', 'main'),
(1011, 'pm_box_full_warning', 'Warning : Your Box is Full and you can', 'main'),
(1459, 'movies_comments', 'Movies Comments', 'main'),
(1012, 'no_messages', 'No Messages', 'main'),
(1013, 'the_sender', 'Sender', 'main'),
(1014, 'the_subject', 'Subject', 'main'),
(1015, 'reply', 'Reply', 'main'),
(1016, 'err_sendto_pm_box_full', 'Error, Box that you trying to sent to is full.', 'main'),
(1017, 'pm_sent_successfully', 'Your Message Sent Successfully', 'main'),
(1018, 'err_sendto_username_invalid', 'Error , Receiver username is invalid', 'main'),
(1458, 'comments_max_letters', 'Max Length', 'main'),
(1019, 'the_message', 'Message', 'main'),
(1020, 'chng_email_conf_msg_sent', 'your new email confirmation message sent to your email', 'main'),
(1021, 'your_profile_updated_successfully', 'Your Profile Updated Successfully', 'main'),
(1022, 'the_profile', 'Profile', 'main'),
(1023, 'err_wrong_uploader_folder', 'Wrong Uploader Folder', 'cp'),
(1024, 'register_email_exists2', 'if this is your email and you forgot the password ', 'cp'),
(1025, 'the_statics_and_counters', 'Statistics & Counters', 'cp'),
(1026, 'cp_visitors_statics', 'Visitors Statics', 'cp'),
(1027, 'cp_counters_start_date', 'Counters start Date', 'cp'),
(1028, 'cp_total_visits', 'Total Visits', 'cp'),
(1029, 'the_hour', 'Hour', 'cp'),
(1030, 'operating_systems', 'Operating Systems', 'main'),
(1031, 'the_browsers', 'Browser', 'main'),
(1032, 'monthly_statics_for', 'Monthly Statics for ', 'main'),
(1033, 'daily_statics_for', 'Daily Statics for', 'main'),
(1034, 'the_year', 'Year', 'main'),
(1035, 'the_month', 'Month', 'main'),
(1036, 'right_to_left', 'Right to Left', 'cp'),
(1037, 'left_to_right', 'Left to Right', 'cp'),
(1038, 'page_dir', 'Page Direction', 'cp'),
(1039, 'mailing_email', 'Mailing Email', 'cp'),
(1040, 'copyrights_sitename', 'Copyrights Site Name', 'cp'),
(1041, 'section_name', 'Section Name', 'cp'),
(1042, 'site_name', 'Site Name', 'cp'),
(1043, 'page_keywords', 'Keywords', 'cp'),
(1044, 'votes_expire_time', 'Time period between votes', 'cp'),
(1045, 'hour', 'Hour', 'cp'),
(1046, 'the_weight', 'Weight', 'main'),
(1047, 'not_available_now', 'Not Available Now', 'main'),
(1048, 'bnr_views', 'View', 'cp'),
(1049, 'bnr_visits', 'Visit', 'cp'),
(1050, 'update', 'Update', 'main'),
(1051, 'orderby', 'Sort by', 'main'),
(1052, 'remove_from_fav', 'Remove from Favorites', 'main'),
(1053, 'to', 'To', 'main'),
(1054, 'search_in_subcats', 'Search in Sub-Categories', 'main'),
(1055, 'enlarge_pic', 'Click to Enlarge', 'main'),
(1057, 'not_selected', 'Not Selected', 'main'),
(1058, 'availability', 'Availability', 'main'),
(1412, 'year_ago', 'Years Ago', 'main'),
(1446, 'movies_perpage', 'Movies Per Page', 'cp'),
(1061, 'the_cats', 'Categories', 'cp'),
(1316, 'for_members_only', 'For Members Only', 'cp'),
(1064, 'add_cat', 'Add Category', 'cp'),
(1419, 'pm_send_denied', 'Sorry , You can''t send a message to this member', 'main'),
(1067, 'default', 'Default', 'cp'),
(1068, 'view_page', 'View Page', 'cp'),
(1069, 'vote_add', 'Add new Vote', 'cp'),
(1070, 'set_default', 'Set as Default', 'cp'),
(1071, 'edit_or_options', 'Edit / Options', 'cp'),
(1072, 'add_options', 'Add Options', 'cp'),
(1404, 'add_to_friends_list', 'Add to Friends List', 'main'),
(1074, 'images_cells_count', 'No. of Images Cells ', 'cp'),
(1075, 'news_perpage', 'News Per Page', 'cp'),
(1076, 'back_to_cats', 'Back to Categories', 'cp'),
(1411, 'last_page', 'Last Page', 'main'),
(1445, 'movies_add_fields', 'Movies Add Fields', 'cp'),
(1410, 'prev_page', 'Prev. Page', 'main'),
(1080, 'move_from', 'Move From', 'cp'),
(1081, 'move_to', 'Move to', 'cp'),
(1418, 'seconds_ago', 'Seconds Ago', 'main'),
(1083, 'next', 'Next', 'cp'),
(1084, 'move_do', 'Move', 'cp'),
(1085, 'redirection_msg', 'Redirecting , if your browser not support redirecting', 'main'),
(1457, 'actor_photos_max', 'No. of Photos in Movie''s Page', 'main'),
(1086, 'checkout', 'Checkout', 'main'),
(1087, 'no_payment_gateways_available', 'No Payment Gateways Available', 'main'),
(1088, 'select_all', 'Check All', 'cp'),
(1089, 'select_none', 'Uncheck All', 'cp'),
(1090, 'change_comment', 'Change Comment', 'cp'),
(1091, 'payment_gateways', 'Payment Gateways', 'main'),
(1315, 'download_for_all', 'For All', 'cp'),
(1093, 'count', 'Qty', 'main'),
(1292, 'the_subtitles_count', 'No. of Subtitles', 'cp'),
(1095, 'without_comment', 'Without Comment', 'cp'),
(1096, 'the_comment', 'Comment', 'cp'),
(1097, 'fields_count', 'No. of Fields', 'cp'),
(1098, 'prev_votes', 'Prev. Votes', 'main'),
(1099, 'no_options', 'No Options', 'main'),
(1100, 'users_count', 'Users', 'cp'),
(1101, 'show_sitename_in_subpages', 'Show Site name in sub-pages', 'cp'),
(1102, 'show_section_name_in_subpages', 'Show Section name in sub-pages', 'cp'),
(1103, 'bill_payment', 'Invoice Payment', 'main'),
(1104, 'not_available', 'Not Available', 'main'),
(1409, 'first_page', 'First Page', 'main'),
(1106, 'msgs_count_limit', 'Member Messages Limit', 'cp'),
(1107, 'message', 'Message', 'cp'),
(1108, 'paid', 'Paid', 'main'),
(1408, 'for_no_one', 'No One', 'main'),
(1407, 'for_any_one', 'Any One', 'main'),
(1111, 'the_invoice', 'The Invoice', 'main'),
(1113, 'payment_method', 'Payment Method', 'main'),
(1115, 'ram_banner_width', 'Banners window width', 'cp'),
(1116, 'ram_banner_height', 'Banners window height', 'cp'),
(1119, 'not_saved', 'Not Saved', 'main'),
(1417, 'minutes_ago', 'Minutes Ago', 'main'),
(1122, 'telephone', 'Tel.', 'main'),
(1416, 'hours_ago', 'Hours Ago', 'main'),
(1124, 'city', 'City', 'main'),
(1415, 'days_ago', 'Days Ago', 'main'),
(1127, 'the_count', 'Qty', 'main'),
(1129, 'the_total', 'Total', 'main'),
(1291, 'the_director', 'Director', 'cp'),
(1131, 'err_invalid_id', '<b>Error : </b>  Invalid ID', 'cp'),
(1132, 'the_id', 'ID', 'cp'),
(1133, 'without_title', 'No Title', 'cp'),
(1134, 'cp_rest_counters', 'Rest Counters', 'cp'),
(1135, 'cp_rest_counters_do', 'Rest Counters', 'cp'),
(1136, 'visitors_statics_rest_done', 'Rest Counters Done', 'cp'),
(1137, 'cp_no_phrases', 'No Phrases', 'cp'),
(1138, 'cp_no_templates', 'No Templates', 'cp'),
(1139, 'cp_invalid_pwd', 'invalid password', 'cp'),
(1140, 'cp_invalid_username', 'invalid username', 'cp'),
(1141, 'cp_welcome_msg', 'Welcome {username}', 'cp'),
(1142, 'cp_statics', 'Statics', 'cp'),
(1143, 'search', 'Search', 'cp'),
(1144, 'forgot_pwd_msg_subject', 'Recover your password', 'cp'),
(1145, 'without_selection', 'None', 'cp'),
(1146, 'create_main_user', 'Create Main User', 'cp'),
(1317, 'gender', 'Gender', 'main'),
(1148, 'tabbed_to', 'Tabbed To', 'cp'),
(1149, 'without_tabbed_menu', 'Not Tabbed', 'cp'),
(1150, 'prev', 'Prev.', 'main'),
(1151, 'offers_menu', 'Offers Menu', 'main'),
(1313, 'default_value_or_options', 'Default Value / Options', 'cp'),
(1312, 'send_msg_to_member', 'Contact the Member', 'cp'),
(1154, 'show_prev_votes', 'Show Prev. Votes', 'cp'),
(1156, 'max_count', 'Max Count', 'cp'),
(1157, 'random', 'Random', 'cp'),
(1158, 'cats_permissions', 'Categories Permissions', 'cp'),
(1159, 'cats_permissions_note', 'You can edit Categories Permission by click on edit button for each Category', 'cp'),
(1456, 'actor_photos_cells', 'Actor''s Photos Cells', 'main'),
(1160, 'store_fields_note', 'You can choose Features &amp; Details for each category by edit button for each category', 'cp'),
(1406, 'for_friends_only', 'Friends Only', 'main'),
(1444, 'show_movies_in_groups', 'Show Movies in Groups', 'cp'),
(1405, 'add_to_black_list', 'Add to Black List', 'main'),
(1165, 'other', 'Other', 'main'),
(1303, 'manage_movie_meta', 'Page Setting', 'cp'),
(1304, 'leave_blank_to_use_default_settings', 'Leave it Blank to use default settings', 'cp'),
(1299, 'activate', 'Activate', 'cp'),
(1300, 'the_member', 'Member', 'main'),
(1356, 'delete_picture', 'Delete Picture', 'main'),
(1170, 'the_total_price', 'Total Price', 'cp'),
(1171, 'update_data', 'Update Data', 'cp'),
(1172, 'cannot_disable_default_status', 'Can not Disable Default Status', 'cp'),
(1173, 'cannot_delete_default_status', 'Can not Delete Default Status', 'cp'),
(1176, 'text_color', 'Text Color', 'cp'),
(1177, 'show_payment_options', 'Show Payment Options', 'cp'),
(1178, 'sending_form_code', 'Sending Form Code', 'cp'),
(1179, 'is_gateway', 'is Gateway ?', 'cp'),
(1180, 'short_description', 'Short Description', 'cp'),
(1181, 'fields_search_menu', 'Search Menu', 'cp'),
(1182, 'options_edit', 'Edit Options', 'cp'),
(1183, 'the_value', 'Value', 'cp'),
(1184, 'without_main_cat', 'without main Category', 'cp'),
(1311, 'sent_messages', 'Sent Messages', 'main'),
(1310, 'received_msgs', 'Inbox', 'main'),
(1187, 'move_the_cats', 'Move Categories', 'cp'),
(1188, 'please_select_cats_first', 'Please Select Categories first', 'cp'),
(1309, 'add2fav_already_exists', 'This Movie already added to favorites', 'main'),
(1190, 'err_invalid_cat_id', '<b> Error : </b> Invalid Category ID', 'cp'),
(1191, 'err_cats_not_selected', '<b> Error : </b> No Categories Selected', 'cp'),
(1192, 'move', 'Move', 'cp'),
(1403, 'profile_access_denied', 'Sorry , You can''t see this profile', 'main'),
(1194, 'the_moderators', 'Moderators', 'cp'),
(1195, 'page_custom_info', 'Page Custom Info', 'cp'),
(1196, 'the_page_keywords', 'Page Keywords', 'cp'),
(1298, 'comment_type', 'Comment Type', 'cp'),
(1308, 'add2fav_confirm_msg', 'Are you sure that you want to add "{name}" to favorites', 'main'),
(1201, 'photos_count', 'No. of Photos', 'cp'),
(1301, 'remaining_letters', 'Remaining Letters', 'cp'),
(1296, 'the_comments', 'Comments', 'cp'),
(1203, 'add_photos', 'Add Photos', 'cp'),
(1204, 'no_photos', 'No Photos', 'cp'),
(1205, 'no_moderators', 'No Moderators', 'cp'),
(1206, 'available', 'Available', 'cp'),
(1207, 'pay_now', 'Pay Now', 'main'),
(1295, 'comments_waiting_admin_review', 'Comments Waiting Admin Review', 'cp'),
(1302, 'write_your_comment', 'Write Your Comment', 'cp'),
(1210, 'phrases_name_exists', 'Cannot be Added , this name already used', 'cp'),
(1211, 'the_players', 'Players', 'cp'),
(1212, 'no_players', 'No Players', 'cp'),
(1213, 'extensions', 'Extensions', 'cp'),
(1214, 'players_add', 'Add Player', 'cp'),
(1215, 'ioncube_version', 'ionCube Version', 'cp'),
(1216, 'internal_player', 'Internal Player', 'cp'),
(1217, 'external_player', 'External Player', 'cp'),
(1218, 'the_download', 'Download', 'cp'),
(1219, 'file_name', 'File Name', 'cp'),
(1220, 'the_icon_url', 'Icon URL', 'cp'),
(1221, 'the_icon_alt', 'Icon Title', 'cp'),
(1222, 'use_comma_between_types', 'Use (Comma) Between Types', 'cp'),
(1223, 'the_movies', 'Movies', 'main'),
(1224, 'no_cats', 'No Categories', 'main'),
(1225, 'add_movie', 'Add Movie', 'cp'),
(1226, 'close', 'Close', 'main'),
(1227, 'no_movies', 'No Movies', 'main'),
(1228, 'add_to_new_movies_list', 'Add to New Movies List', 'cp'),
(1229, 'new_movies_list', 'New Movies List', 'cp'),
(1230, 'movie_del_warn', 'Deleting this movie will delete all photos and subtitles related to this movie , Continue ?', 'cp'),
(1231, 'download_url', 'Download URL', 'cp'),
(1232, 'watch_url', 'Watch URL', 'cp'),
(1233, 'custom_watch_url', 'Custom Watch URL', 'cp'),
(1234, 'add_files', 'Add Files', 'cp'),
(1235, 'browse_movies', 'Browse Movies', 'cp'),
(1236, 'movie_info', 'Movie Info', 'cp'),
(1237, 'members_comments', 'Members Comments', 'main'),
(1238, 'the_actors', 'Actors', 'main'),
(1239, 'no_actors', 'No Actors', 'main'),
(1240, 'actor_movies', 'Actor''s Movies', 'main'),
(1241, 'manage_files', 'Manage Files', 'cp'),
(1242, 'manage_actors', 'Manage Actors', 'cp'),
(1243, 'manage_subtitles', 'Manage Subtitles', 'cp'),
(1244, 'manage_photos', 'Manage Photos', 'cp'),
(1245, 'add_actor', 'Add Actor', 'cp'),
(1246, 'player_view_style', 'View Style', 'cp'),
(1247, 'player_view_in_page_ajax', 'In Page Ajax', 'cp'),
(1248, 'player_view_dialog_ajax', 'Ajax Dialog', 'cp'),
(1249, 'player_view_ext_page', 'External Page', 'cp'),
(1250, 'movie_photos', 'Movie Photos', 'cp'),
(1251, 'next_photo', 'Next Photo', 'cp'),
(1252, 'the_photo', 'Photo', 'cp'),
(1253, 'prev_photo', 'Prev. Photo', 'cp'),
(1254, 'full_photo_size', 'Full Size', 'cp'),
(1453, 'actors_per_page', 'Actors per Page', 'main'),
(1256, 'movie_description', 'Movie Description', 'cp'),
(1257, 'cover_photo', 'Cover Photo', 'cp'),
(1258, 'delete_cover', 'Delete Photo', 'cp'),
(1259, 'movie_files_add', 'Add Files', 'cp'),
(1260, 'movie_photos_add', 'Add Photos', 'cp'),
(1261, 'cover_photo_save_error', 'Cannot save Movie Cover , Please try again', 'cp'),
(1262, 'movie_cover_photo', 'Movie Cover Photo', 'cp'),
(1263, 'movie_cover_thumb', 'Movie Cover Thumb', 'cp'),
(1264, 'movie_cover_thumb_width', 'Movie''s Cover''s Thumb Width', 'cp'),
(1265, 'movie_cover_thumb_height', 'Movie''s Cover''s Thumb Height', 'cp'),
(1266, 'actor_thumb', 'Actor Thumb', 'main'),
(1267, 'actor_thumb_width', 'Actor Thumb Width', 'main'),
(1268, 'actor_thumb_height', 'Actor Thumb Height', 'main'),
(1269, 'actor_photo_save_error', 'Cannot save the pictures , please try again', 'main'),
(1270, 'actors_show_in_groups', 'Show Actors in Groups', 'main'),
(1271, 'release_year', 'Release Year', 'main'),
(1272, 'err', 'Error', 'main'),
(1273, 'edit_done', 'Edit Done Successfully', 'cp'),
(1274, 'please_select_photos', 'Please Select Photos', 'cp'),
(1275, 'actor_photos', 'Actor Photos', 'main'),
(1276, 'actor_photos_add', 'Add', 'cp'),
(1277, 'in_this_photo', 'In This Photo', 'main'),
(1278, 'more', 'More', 'main'),
(1279, 'movie_actors', 'Movie''s Actors', 'main'),
(1280, 'no_comments', 'No Comments', 'main'),
(1281, 'please_login', 'Please Login', 'main'),
(1282, 'err_empty_comment', 'Please Write your Comment', 'main'),
(1283, 'older_comments', 'Older Comments', 'main'),
(1284, 'no_files_selected', 'No Files Selected', 'main'),
(1285, 'the_files', 'Files', 'main'),
(1286, 'activated', 'Activated', 'cp'),
(1287, 'not_activated', 'Not Active', 'cp'),
(1288, 'since', 'Since', 'cp'),
(1290, 'rating_done', 'Rating Done', 'cp'),
(1318, 'report_file', 'Report File', 'cp'),
(1350, 'comment_is_not_exist', 'Comment Does not Exist', 'cp'),
(1349, 'report_number_x', 'Report #', 'cp'),
(1347, 'security_code_in_report', 'Security Code', 'main'),
(1348, 'security_code_in_send', 'Security Code', 'main'),
(1322, 'err_upload_max_size', 'Please make sure that file size under', 'main'),
(1323, 'photo_not_saved', 'Photo did not saved', 'main'),
(1324, 'new_pm_email_notify', 'Email Notify when receiving a new private Message', 'main'),
(1325, 'pm_email_notify_subject', 'New Private Message', 'main'),
(1326, 'not_classified', 'Not Classified', 'main'),
(1327, 'sort_by', 'Sort By', 'main'),
(1328, 'visitors_can_sort_movies', 'Visitors Can Sort Movies', 'cp'),
(1329, 'movies_default_sort', 'Movies Default Sort', 'cp'),
(1331, 'online_status', 'Online Status', 'main'),
(1332, 'online', 'Online', 'main'),
(1333, 'offline', 'Offline', 'main'),
(1334, 'movies_fields', 'Movies Custom Fields', 'cp'),
(1335, 'no_movies_fields', 'No Custom Fields', 'cp'),
(1336, 'enable_search', 'Enable Search', 'cp'),
(1337, 'add_custom_field', 'Add Custom Field', 'cp'),
(1338, 'report_sent', 'Thank You , Report sent', 'main'),
(1339, 'the_explanation', 'Explanation', 'main'),
(1340, 'new_reports', 'New Reports', 'main'),
(1341, 'report_type', 'Report Type', 'main'),
(1342, 'the_reports', 'Reports', 'cp'),
(1343, 'no_reports', 'No Reports', 'cp'),
(1344, 'reports_count', 'No. of Reports', 'cp'),
(1345, 'movies_files', 'Movies Files', 'cp'),
(1346, 'report_do', 'Report', 'main'),
(1351, 'member_is_not_exist', 'Member does not exist', 'cp'),
(1352, 'movie_is_not_exist', 'Movie does not exist', 'cp'),
(1353, 'comment_count', 'No. of Comments', 'cp'),
(1354, 'deactivate', 'Deactivate', 'cp'),
(1355, 'profile_picture', 'Profile Picture', 'main'),
(1357, 'profile_preview', 'Profile Preview', 'main'),
(1358, 'views', 'Views', 'main'),
(1359, 'date_format', 'Date Format', 'cp'),
(1360, 'the_counters', 'Counters', 'cp'),
(1361, 'contactus_send_successfully', 'Thank You , Your Message sent successfully', 'main'),
(1362, 'contactus_send_failed', 'Sorry , cannot send your message , please try again later', 'main'),
(1443, 'rating_exire_time', 'Time period between ratings', 'cp'),
(1363, 'without_subject', 'without subject', 'main'),
(1364, 'counters_reset', 'Counters Reset', 'cp'),
(1365, 'members_connectors', 'Members Connectors', 'cp'),
(1366, 'movies_count', 'No. of Movies', 'main'),
(1367, 'cats_count', 'No. of Categories', 'main'),
(1368, 'files_count', 'No. of Files', 'main'),
(1369, 'comments_count', 'No. of Comments', 'main'),
(1370, 'visitors_can_send_reports', 'Visitors Can Send Reports', 'cp'),
(1371, 'general_settings', 'General Settings', 'cp'),
(1372, 'mailing_settings', 'Mailing Settings', 'cp'),
(1373, 'default_privacy_settings', 'Privacy Default Settings', 'cp'),
(1374, 'pic_width', 'Picture Width', 'cp'),
(1375, 'pic_height', 'Picture Height', 'cp'),
(1376, 'pic_max_width', 'Picture Max Width', 'cp'),
(1377, 'pic_max_height', 'Picture Max Height', 'cp'),
(1378, 'thumb_width', 'Thumb Width', 'cp'),
(1379, 'thumb_height', 'Thumb Height', 'cp'),
(1380, 'the_photos', 'Photos', 'cp'),
(1381, 'actor_pic', 'Actor Picture', 'cp'),
(1382, 'vote_movie', 'Movie Vote', 'cp'),
(1383, 'send_movie', 'Send movie to Friend', 'cp'),
(1384, 'movies_order', 'Movies Sort', 'cp'),
(1385, 'news_cat_del_warn', 'Deleting this category will delete all news inside it , Continue ?', 'cp'),
(1448, 'movie_subtitles_list_ajax', 'Ajax Movie''s Subtitles List', 'cp'),
(1386, 'read_more', 'Read More', 'main'),
(1387, 'please_select_news_first', 'Please Select news First', 'cp'),
(1389, 'movies_photos', 'Movies Photos', 'cp'),
(1390, 'actors_photos', 'Actors Photos', 'cp'),
(1391, 'time_and_date', 'Date and Time', 'cp'),
(1392, 'timezone', 'Time Zone', 'cp'),
(1393, 'privacy_settings', 'Privacy Settings', 'main'),
(1394, 'profile_view', 'Profile View', 'main'),
(1395, 'fav_movies', 'Favorite Movies', 'main'),
(1396, 'receive_pm_from', 'Receive Private Messages From', 'main'),
(1397, 'this_member_exist_in_list', 'This Member Already exist in list', 'main'),
(1398, 'add_done_successfully', 'Add Done Successfully', 'main'),
(1399, 'friends_list', 'Friends List', 'main'),
(1400, 'no_friends_in_list', 'No Friends', 'main'),
(1401, 'black_list', 'Black List', 'main'),
(1402, 'no_members_in_list', 'No Members', 'main');

-- --------------------------------------------------------

--
-- Table structure for table `movies_phrases_cats`
--

CREATE TABLE IF NOT EXISTS `movies_phrases_cats` (
  `id` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movies_phrases_cats`
--

INSERT INTO `movies_phrases_cats` (`id`, `name`) VALUES
('cp', 'Control Panel / System'),
('main', 'General');

-- --------------------------------------------------------

--
-- Table structure for table `movies_players`
--

CREATE TABLE IF NOT EXISTS `movies_players` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `int_content` text NOT NULL,
  `exts` varchar(255) NOT NULL default '',
  `int_enabled` int(1) NOT NULL default '0',
  `ext_enabled` int(1) NOT NULL default '0',
  `int_icon` varchar(255) NOT NULL,
  `ext_icon` varchar(255) NOT NULL,
  `int_icon_alt` varchar(255) NOT NULL,
  `ext_icon_alt` varchar(255) NOT NULL,
  `ext_content` text NOT NULL,
  `ext_mime` varchar(100) NOT NULL default '',
  `ext_filename` varchar(255) NOT NULL default '',
  `download_icon` varchar(255) NOT NULL,
  `download_enabled` int(1) NOT NULL default '0',
  `download_icon_alt` varchar(255) NOT NULL,
  `view_style` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `movies_players`
--

INSERT INTO `movies_players` (`id`, `name`, `int_content`, `exts`, `int_enabled`, `ext_enabled`, `int_icon`, `ext_icon`, `int_icon_alt`, `ext_icon_alt`, `ext_content`, `ext_mime`, `ext_filename`, `download_icon`, `download_enabled`, `download_icon_alt`, `view_style`) VALUES
(1, 'المشغل الافتراضي', '<!-- begin embedded RealMedia file... -->\r\n      <table border=''0'' cellpadding=''0'' align="center">\r\n        <!-- begin video window... -->\r\n        <tr><td>\r\n        <OBJECT id=''rvocx'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n        width="500" height="300">\r\n        <param name=''src'' value="{url}">\r\n        <param name=''autostart'' value="true">\r\n        <param name=''controls'' value=''imagewindow''>\r\n        <param name=''console'' value=''video''>\r\n        <param name=''loop'' value="true">\r\n        <EMBED src="{url}" width="500" height="300" \r\n        loop="true" type=''audio/x-pn-realaudio-plugin'' controls=''imagewindow'' console=''video'' autostart="true">\r\n        </EMBED>\r\n        </OBJECT>\r\n        </td></tr>\r\n        <!-- ...end video window -->\r\n          <!-- begin control panel... -->\r\n          <tr><td>\r\n          <OBJECT id=''rvocx'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n          width="500" height=''30''>\r\n          <param name=''src'' value="{url}">\r\n          <param name=''autostart'' value="true">\r\n          <param name=''controls'' value=''ControlPanel''>\r\n          <param name=''console'' value=''video''>\r\n          <EMBED src="{url}" width="500" height=''30'' \r\n          controls=''ControlPanel'' type=''audio/x-pn-realaudio-plugin'' console=''video'' autostart="true">\r\n          </EMBED>\r\n          </OBJECT>\r\n          </td></tr>\r\n          <!-- ...end control panel -->\r\n          <!-- ...end embedded RealMedia file -->\r\n        <!-- begin link to launch external media player... -->\r\n       \r\n      </table>\r\n', '', 1, 0, 'images/watch.gif', 'images/watch.gif', 'مشاهدة ({views} مشاهدة)', 'مشاهدة خارجية ({views} مشاهدة)', '{url}', 'audio/x-pn-realaudio', 'watch.ram', 'images/download.gif', 1, 'تحميل ({downloads} تحميل)', 0),
(2, 'Flash Video Player', '<center>\r\n\r\n<OBJECT id="mpl" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="500" height="300"><PARAM name="movie" value="players/player.swf" /><PARAM name="quality" value="high" /><PARAM name="allowfullscreen" value="true" /><PARAM name="allowscriptaccess" value="always" /><PARAM name="flashvars" value="file={url}&autostart=true" />\r\n\r\n<embed\r\n   src="players/player.swf" \r\n   width="500"\r\n   height="300"\r\n   allowscriptaccess="always"\r\n   allowfullscreen="true"\r\n   id="player1"\r\n   name="player1"\r\n   flashvars="file={url}&dock=true&autostart=true"/>\r\n\r\n</OBJECT>\r\n\r\n\r\n</center>', '.flv,.mp4', 1, 0, 'images/watch.gif', '', 'مشاهدة ({views} مشاهدة)', '', '', '', '', 'images/download.gif', 1, 'تحميل ({downloads} تحميل)', 0),
(3, 'Windows Media Player', '    <table border=''0'' cellpadding=''0'' align="center">\r\n      <tr><td>\r\n      <OBJECT id=''mediaPlayer'' width="400" height="305"\r\n      classid=''CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95''\r\n      codebase=''http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701''\r\n      standby=''Loading Microsoft Windows Media Player components...'' type=''application/x-oleobject''>\r\n      <param name=''fileName'' value="{url}">\r\n      <param name=''animationatStart'' value=''true''>\r\n      <param name=''transparentatStart'' value=''true''>\r\n      <param name=''autoStart'' value="true">\r\n      <param name=''showControls'' value="true">\r\n      <param name=''loop'' value="false">\r\n      <EMBED type=''application/x-mplayer2''\r\n        pluginspage=''http://microsoft.com/windows/mediaplayer/en/download/''\r\n        id=''mediaPlayer'' name=''mediaPlayer'' displaysize=''4'' autosize=''-1''\r\n        bgcolor=''darkblue'' showcontrols="true" showtracker=''-1''\r\n        showdisplay=''0'' showstatusbar=''-1'' videoborder3d=''-1'' width="400" height="305"\r\n        src="{url}" autostart="true" designtimesp=''5311'' loop="false">\r\n      </EMBED>\r\n      </OBJECT>\r\n      </td></tr>\r\n      <!-- ...end embedded WindowsMedia file -->\r\n    <!-- begin link to launch external media player... -->\r\n      \r\n      </table>', '.wmv', 1, 0, 'images/watch.gif', '', 'مشاهدة ({views} مشاهدة)', '', '', '', '', 'images/download.gif', 1, 'تحميل ({downloads} تحميل)', 2),
(4, 'Divx Player', '<center>\r\n<object classid="clsid:67DABFBF-D0AB-41fa-9C46-CC0F21721616" width="600" height="358" codebase="http://go.divx.com/plugin/DivXBrowserPlugin.cab">\r\n  <param name="custommode" value="none" />\r\n  <param name="autoPlay" value="true" />\r\n  <param name="src" value="{url}" />\r\n  <embed type="video/divx"\r\n         src="{url}"\r\n         custommode="none"\r\n         width="600" height="358"\r\n         autoPlay="false"\r\n         pluginspage="http://go.divx.com/plugin/download/">\r\n  </embed>\r\n</object>\r\n', '.avi,.mkv', 1, 0, 'images/watch.gif', '', 'مشاهدة ({views} مشاهدة)', '', '', '', '', 'images/download.gif', 1, 'تحميل ({downloads} تحميل)', 2),
(5, 'YouTube', '<center>\r\n\r\n<OBJECT id="mpl" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="500" height="300"><PARAM name="movie" value="players/player.swf" /><PARAM name="quality" value="high" /><PARAM name="allowfullscreen" value="true" /><PARAM name="allowscriptaccess" value="always" /><PARAM name="flashvars" value="file={url}&autostart=true" />\r\n\r\n<embed\r\n   src="players/player.swf" \r\n   width="500"\r\n   height="300"\r\n   allowscriptaccess="always"\r\n   allowfullscreen="true"\r\n   id="player1"\r\n   name="player1"\r\n   flashvars="file={url}&dock=true"/>\r\n\r\n</OBJECT>\r\n\r\n\r\n</center>', 'youtube.com', 1, 0, 'images/watch.gif', '', 'مشاهدة ({views} مشاهدة)', '', '', '', '', 'images/youtube_watch.png', 1, 'مشاهدة في يوتيوب ({downloads} مشاهدة)', 1),
(6, 'Real Video Player', '<!-- begin embedded RealMedia file... -->\r\n      <table border=''0'' cellpadding=''0'' align="center">\r\n        <!-- begin video window... -->\r\n        <tr><td>\r\n        <OBJECT id=''rvocx'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n        width="500" height="300">\r\n        <param name=''src'' value="{url}">\r\n        <param name=''autostart'' value="true">\r\n        <param name=''controls'' value=''imagewindow''>\r\n        <param name=''console'' value=''video''>\r\n        <param name=''loop'' value="true">\r\n        <EMBED src="{url}" width="500" height="300" \r\n        loop="true" type=''audio/x-pn-realaudio-plugin'' controls=''imagewindow'' console=''video'' autostart="true">\r\n        </EMBED>\r\n        </OBJECT>\r\n        </td></tr>\r\n        <!-- ...end video window -->\r\n          <!-- begin control panel... -->\r\n          <tr><td>\r\n          <OBJECT id=''rvocx'' classid=''clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA''\r\n          width="500" height=''30''>\r\n          <param name=''src'' value="{url}">\r\n          <param name=''autostart'' value="true">\r\n          <param name=''controls'' value=''ControlPanel''>\r\n          <param name=''console'' value=''video''>\r\n          <EMBED src="{url}" width="500" height=''30'' \r\n          controls=''ControlPanel'' type=''audio/x-pn-realaudio-plugin'' console=''video'' autostart="true">\r\n          </EMBED>\r\n          </OBJECT>\r\n          </td></tr>\r\n          <!-- ...end control panel -->\r\n          <!-- ...end embedded RealMedia file -->\r\n        <!-- begin link to launch external media player... -->\r\n       \r\n      </table>\r\n', '.rm,.rmvb,.rv', 1, 0, 'images/watch.gif', 'images/watch.gif', 'مشاهدة ({views} مشاهدة)', 'مشاهدة خارجية ({views} مشاهدة)', '{url}', 'audio/x-pn-realaudio', 'watch.ram', 'images/download.gif', 1, 'تحميل ({downloads} تحميل)', 0);

-- --------------------------------------------------------

--
-- Table structure for table `movies_reports`
--

CREATE TABLE IF NOT EXISTS `movies_reports` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `report_type` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `date` int(11) NOT NULL,
  `opened` int(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `report_type` (`report_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_reports`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_settings`
--

CREATE TABLE IF NOT EXISTS `movies_settings` (
  `name` varchar(255) NOT NULL default '',
  `value` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movies_settings`
--

INSERT INTO `movies_settings` (`name`, `value`) VALUES
('snd2friend', '1'),
('vote_song', '1'),
('sitename', 'Allomani'),
('section_name', 'Movies v2.0'),
('movies_add_fields', '5'),
('letters_songs', '1'),
('letters_singers', '1'),
('html_dir', 'ltr'),
('header_keywords', 'Movies , Series , Actors , Cinema , DVD'),
('uploader', '0'),
('uploader_path', 'uploads'),
('uploader_msg', 'Sorry, Uploading Disabled in Demo Version'),
('uploader_types', 'jpg,gif,png,rm,mp3,zip,rar'),
('movies_add_limit', '5'),
('actor_photos_cells', '4'),
('movies_perpage', '30'),
('movies_cells', '4'),
('vote_movie', '1'),
('snd2friend_clip', '1'),
('max_cover_width', '150'),
('max_cover_hieght', '200'),
('movie_photos_cells', '4'),
('mailing_email', 'mailing@{domain_name}'),
('copyrights_sitename', 'Allomani'),
('votes_expire_hours', '24'),
('vote_file_expire_hours', '24'),
('search_min_letters', '3'),
('msgs_count_limit', '1000'),
('members_register', '1'),
('news_perpage', '20'),
('photo_thumb_width', '100'),
('photo_thumb_height', '100'),
('enable_browsing', '1'),
('disable_browsing_msg', '<center>\r\nthe Website Closed for Maintenance\r\n</center>\r\n'),
('actor_photos_max', '4'),
('uploader_thumb_width', '100'),
('uploader_thumb_hieght', '100'),
('site_pages_encoding', 'utf-8'),
('site_pages_lang', 'ar-sa'),
('default_styleid', '1'),
('section_name_in_subpages', '0'),
('sitename_in_subpages', '1'),
('mailing_default_use_html', '1'),
('mailing_default_encoding', ''),
('enable_comments', '1'),
('comments_auto_activate', '1'),
('photo_resized_height', '720'),
('photo_resized_width', '720'),
('enable_photos_comments', '1'),
('enable_photo_comments', '1'),
('cover_thumb_fixed', '1'),
('movie_cover_thumb_width', '135'),
('movie_cover_thumb_height', '200'),
('actor_thumb_width', '65'),
('actor_thumb_height', '65'),
('actor_thumb_fixed', '1'),
('actors_show_in_groups', '1'),
('comments_bad_words_replacement', '***'),
('comments_bad_words', 'حمار,كلب,سكس,fuck,sex'),
('movie_photos_max', '4'),
('movie_actors_cells', '5'),
('movie_actors_max', '5'),
('actor_img_width', '150'),
('actor_img_height', '200'),
('actor_img_fixed', '1'),
('commets_per_request', '10'),
('movie_files_list_ajax', '0'),
('movie_files_list_max', '10'),
('movie_subtitles_list_ajax', '1'),
('rating_expire_hours', '24'),
('movie_subtitles_list_ajax', '1'),
('movie_subtitles_list_max', '10'),
('comments_max_letters', '255'),
('header_description', 'Movies , Series , Actors , Cinema , DVD'),
('enable_news_comments', '1'),
('count_visitors_info', '1'),
('count_visitors_hits', '1'),
('count_online_visitors', '1'),
('enable_profiles', '1'),
('report_file_enabled', '1'),
('admin_email', 'no-reply@allomani.com'),
('members_profile_pictures', '1'),
('profile_pic_thumb_width', '30'),
('profile_pic_thumb_height', '30'),
('profile_pic_width', '100'),
('profile_pic_height', '100'),
('movies_groups', '1'),
('visitors_can_sort_movies', '1'),
('movies_default_orderby', 'year'),
('movies_default_sort', 'desc'),
('other_votes_show', '1'),
('other_votes_limit', '10'),
('other_votes_orderby', 'rand()'),
('enable_actor_comments', '1'),
('enable_actor_photo_comments', '1'),
('defualt_privacy_profile', '0'),
('defualt_privacy_fav_movies', '0'),
('defualt_privacy_messages', '0'),
('default_privacy_settings', 'a:9:{s:7:"profile";i:0;s:6:"gender";i:0;s:5:"birth";i:0;s:7:"country";i:0;s:10:"last_login";i:0;s:6:"online";i:0;s:7:"field_6";i:0;s:10:"fav_movies";i:0;s:8:"messages";i:0;}'),
('online_members_count', '0'),
('reports_enabled', '1'),
('', ''),
('register_sec_code', '1'),
('register_username_min_letters', '4'),
('', ''),
('register_username_exclude_list', 'admin,mod,webmaster'),
('report_sec_code', '1'),
('send_sec_code', '1'),
('date_format', 'D, d M Y'),
('reports_for_visitors', '1'),
('actors_per_page', '200'),
('timezone', 'Asia/Baghdad'),
('auto_email_activate', '0');

-- --------------------------------------------------------

--
-- Table structure for table `movies_subtitles`
--

CREATE TABLE IF NOT EXISTS `movies_subtitles` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `date` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `downloads` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_subtitles`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_templates`
--

CREATE TABLE IF NOT EXISTS `movies_templates` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `protected` int(1) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=134 ;

--
-- Dumping data for table `movies_templates`
--

INSERT INTO `movies_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`, `views`) VALUES
(1, 'Site Header', 'header', '<body onunload="pop_close()">\r\n\r\n<div class=''header-div''><img src=''images/logo.png''></div>\r\n\r\n<br><br>\r\n\r\n<div class=''container''>\r\n', 1, 1, 4),
(17, 'Page Head', 'page_head', '<?\r\nglobal $settings,$section_name,$title_sub,$sitename,$meta_keywords,$meta_description,$settings,$action,$scripturl;\r\n\r\nif(($section_name && $settings[''section_name_in_subpages'']) || $title_sub){\r\n$full_title = iif($sitename && ($settings[''sitename_in_subpages''] ||  (CFN == "index.php" && !$action)),$sitename,'''');\r\n}else{\r\n$full_title = $sitename;\r\n}\r\nif($section_name && ($settings[''section_name_in_subpages''] || (CFN == "index.php" && !$action))){\r\n$full_title .= iif($full_title," - $section_name",$section_name);\r\n}\r\n\r\nif($title_sub){\r\n$full_title .= iif($full_title," - $title_sub",$title_sub);\r\n}\r\n\r\n\r\nprint "<!DOCTYPE html PUBLIC \\"-//W3C//DTD XHTML 1.0 Transitional//EN\\"\r\n         \\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\\">\r\n\r\n<html xmlns=\\"http://www.w3.org/1999/xhtml\\" dir=\\"$settings[html_dir]\\">\r\n\r\n<head>\r\n<base href=\\"$scripturl/\\" />\r\n\r\n<meta http-equiv=\\"Content-Type\\" content=\\"text/html; charset=utf-8\\" />\r\n<meta http-equiv=\\"Content-Language\\" content=\\"$settings[site_pages_lang]\\" />\r\n\r\n";\r\nprint "<!-- no cache headers -->\r\n	<meta http-equiv=\\"Pragma\\" content=\\"no-cache\\" />\r\n	<meta http-equiv=\\"Expires\\" content=\\"-1\\" />\r\n	<meta http-equiv=\\"Cache-Control\\" content=\\"no-cache\\" />\r\n<!-- end no cache headers -->\r\n\r\n<meta name=\\"generator\\" content=\\"Allomani Movies v2.0\\" />\r\n\r\n<meta name=\\"keywords\\" content=\\"allomani,".$meta_keywords."\\" />\r\n<meta name=\\"description\\" content=\\"$meta_description\\" />\r\n<meta name=\\"abstract\\" content=\\"$meta_description\\" />\r\n\r\n<meta name=\\"robots\\" content=\\"index, follow\\" />\r\n<meta name=\\"rating\\" content=\\"General\\" /> \r\n<meta name=\\"distribution\\" content=\\"Global\\" />\r\n\r\n\r\n<link type=\\"text/css\\" rel=\\"stylesheet\\" href=\\"css.php\\" />";\r\n\r\nprint "<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS\\" href=\\"rss.php\\" />\r\n\r\n<title>$full_title</title>\r\n";\r\n\r\n?>\r\n<script type="text/javascript">\r\nvar scripturl="<?=$scripturl?>";\r\n</script>\r\n\r\n<script type="text/javascript" src="js/prototype.js"></script>\r\n<script type="text/javascript" src="js/javascript.js"></script>\r\n<?\r\n\r\nif(in_array(CFN,array("actor_details.php","actor_photos.php","movie_info.php","movie_photos.php","movie_files.php","news.php","profile.php"))){\r\nprint "<script type=''text/javascript'' src=''js/jquery.js''></script>\r\n<script> jQuery.noConflict(); </script>\r\n<script type=''text/javascript'' src=''js/jquery.raty.min.js''></script>";\r\n}\r\n\r\n\r\nif(in_array(CFN,array("movie_info.php","movie_files.php","profile.php"))){\r\nprint "<script type=''text/javascript'' src=''js/jquery.boxy.allomani.js''></script>";\r\n}\r\n\r\n?>\r\n', 1, 1, 2),
(2, 'Site Footer', 'footer', '</div>\r\n<div class=''footer-div''>\r\n\r\n <br>\r\n<div align=right>&nbsp;&nbsp;&nbsp;\r\n<?global $styleid;print_style_selection();?>\r\n</div><br>\r\n\r\n</div>\r\n\r\n</body>\r\n\r\n</html>\r\n        \r\n        \r\n        \r\n        \r\n        \r\n        ', 1, 1, 2),
(3, 'Block', 'block', '<table width="100%"  border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n	<tr>\r\n		<td>\r\n			<img src="images/table_01.gif" width="10" height="12" alt=""></td>\r\n		<td width="100%" height="12" background="images/table_02.gif"></td>\r\n		<td>\r\n			<img src="images/table_03.gif" width="10" height="12" alt=""></td>\r\n	</tr>\r\n	<tr>\r\n		<td background="images/table_04.gif" width="10">\r\n			<img src="images/table_04.gif" width="10" height="10" alt=""></td>\r\n		<td width="100%" bgcolor="#f9ecba" style="text-align:left;padding:5px" dir="ltr">\r\n			{title}{new_line}{content}</td>\r\n		<td background="images/table_06.gif" width="10">\r\n			<img src="images/table_06.gif" width="10" height="10" alt=""></td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<img src="images/table_07.gif" width="10" height="10" alt=""></td>\r\n		<td background="images/table_08.gif" width="100%" height="10">\r\n		</td>\r\n		<td>\r\n			<img src="images/table_09.gif" width="10" height="10" alt=""></td>\r\n	</tr>\r\n</table>\r\n', 1, 1, 4),
(4, 'Table', 'table', '<table width="100%" border="0" cellpadding="0" cellspacing="0" dir="ltr">\r\n	<tr>\r\n		<td>\r\n			<img src="images/table_01.gif" width="10" height="12" alt=""></td>\r\n		<td width="100%" height="12" background="images/table_02.gif"></td>\r\n		<td>\r\n			<img src="images/table_03.gif" width="10" height="12" alt=""></td>\r\n	</tr>\r\n	<tr>\r\n		<td background="images/table_04.gif" width="10">\r\n			<img src="images/table_04.gif" width="10" height="10" alt=""></td>\r\n		<td width="100%" bgcolor="#f9ecba" style="text-align:left;padding:5px" dir="ltr">\r\n			{title}{new_line}{content}</td>\r\n		<td background="images/table_06.gif" width="10">\r\n			<img src="images/table_06.gif" width="10" height="10" alt=""></td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<img src="images/table_07.gif" width="10" height="10" alt=""></td>\r\n		<td background="images/table_08.gif" width="100%" height="10">\r\n		</td>\r\n		<td>\r\n			<img src="images/table_09.gif" width="10" height="10" alt=""></td>\r\n	</tr>\r\n</table>\r\n<br>', 1, 1, 3),
(93, 'Browse Actors', 'browse_actors', '<?\r\nglobal $data,$links;\r\n\r\nprint "<a href=\\"".str_replace("{id}",$data[''id''],$links[''links_actor_details''])."\\" title=\\"$data[name]\\">\r\n        <img src=\\"".get_image($data[''thumb''])."\\" title=\\"$data[name]\\"><br>$data[name]</a>";\r\n?>', 1, 1, 1),
(97, 'Actor Details', 'actor_details', '<?\r\nglobal $data,$phrases,$style;\r\n\r\nprint "<table width=100%><tr><td>\r\n\r\n<DIV style=\\"FLOAT: right\\"><TABLE border=\\"0\\"><TBODY><TR><TD><TABLE border=\\"0\\"><TBODY><TR><TD align=\\"center\\">\r\n<img src=''".get_image($data[''img''])."''>\r\n</TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir=\\"ltr\\" align=\\"left\\">\r\n$data[details] \r\n</td></tr>\r\n</div>\r\n\r\n</td></tr></table>";\r\n\r\nif($data[''votes_total''] > 0 && $data[''votes''] > 0){\r\n$rating = $data[''votes'']/$data[''votes_total''] ;\r\n}else{ $rating = 0 ;}\r\n\r\n\r\nprint "<br><br><center>";\r\nprint_rating(''actor'',$data[''id''],$rating);    \r\nprint "</center>";\r\n\r\n print "<br><img src=\\"$style[images]/views.gif\\"> &nbsp; <b>$phrases[views] : </b>$data[views]";   ', 1, 1, 2),
(98, '', 'movie_actors_content', '<?\r\nglobal $c,$settings,$data,$links;\r\n\r\n  print "<li>\r\n        <a href=\\"".str_replace("{id}",$data[''id''],$links[''links_movie_info''])."\\" title=\\"$data[name]\\">\r\n$data[name]</a>".iif($data[''year''],"&nbsp;&nbsp;($data[year])")."</li>";\r\n\r\n?>\r\n', 1, 1, 0),
(99, '', 'movie_actors_header', '<?\r\nprint "<ul>"; \r\n?>', 1, 1, 0),
(100, '', 'movie_actors_footer', '<?\r\n  print "</ul>"; \r\n?>', 1, 1, 0),
(5, 'Contact us', 'contactus', '<?\r\nglobal $sec_img,$phrases;\r\n\r\n open_table("$phrases[contact_us]");  \r\n    print "<center>\r\n              <form action=''contactus.php'' method=post>\r\n\r\n           \r\n              <input type=hidden name=''action'' value=''send''>\r\n              <table width=60%>\r\n\r\n              <tr>\r\n              <td width=23%> $phrases[the_name] </td>\r\n              <td>\r\n              <input name=''email_name'' type=''text'' size=30>\r\n              </td>\r\n              </tr>\r\n\r\n                <tr>\r\n              <td>$phrases[email] </td>\r\n              <td>\r\n              <input name=''email_email'' type=''text'' size=30>\r\n              </td>\r\n              </tr>\r\n\r\n                  <tr>\r\n              <td> $phrases[the_subject] </td>\r\n              <td>\r\n              <input name=''email_subject'' type=''text'' size=30>\r\n              </td>\r\n              </tr>\r\n            <tr>\r\n              <td> $phrases[the_message] </td>\r\n              <td>\r\n             <textarea name=''email_msg'' rows=5 cols=40></textarea>\r\n              </td>\r\n              </tr>\r\n             <tr>\r\n             <td>$phrases[security_code]</td><td>".$sec_img->output_input_box(''sec_string'',''size=7'')."\r\n           &nbsp;<img src=\\"sec_image.php\\" alt=\\"Verification Image\\" /></td></tr>\r\n           \r\n              <tr><td colspan=2 align=center>\r\n             <input type=\\"submit\\" style=\\"width: 100 ; height: 30\\" value=\\"$phrases[send]\\">\r\n             </td> </tr>\r\n             </form>\r\n             </table>\r\n            </center> ";\r\n  close_table();  \r\n?>', 1, 1, 1),
(6, 'Send to Friend Message', 'friend_msg', '<html dir=ltr>\r\n<body>\r\n\r\n<div dir=ltr align=left> Your Friend Sent this Movie to you </p>\r\n\r\n\r\nName : {name_from}<br>\r\nEmail : {email_from}<br><br>\r\n\r\n<center><table width=100%><td valign=top width=2><img src=''{thumb}''></td><td>\r\n<p align=center><b>{name}</b></p>\r\n\r\n<p>{details}</p>\r\n\r\n\r\nView / Download Movie : <br> <a href="{url}" target=_blank>{url}</a>\r\n\r\n\r\n</td></tr></table>\r\n\r\n</body>\r\n</html>\r\n', 1, 1, 2),
(14, 'Browse Movies', 'browse_movies', '<?\r\nglobal $data,$phrases,$action,$links,$orderby,$settings;\r\n\r\nprint "<td align=center valign=top><a href=\\"".str_replace("{id}",$data[''id''],$links[''links_movie_info''])."\\">\r\n<img border=0 title=\\"$data[name]\\" src=\\"".get_image($data[''thumb''],"images/no_pic_movie.gif")."\\">\r\n            <br>$data[name]</a>".iif($orderby == "year" && $settings[''movies_groups''],"",iif($data[''year''],"<br><span dir=''ltr''>( $data[year] )</span>"));\r\n\r\nif($data[''fav_id'']){\r\nprint "<br><br>\r\n<a href=\\"usercp.php?action=del_fav&id=$data[fav_id]\\" onclick=\\"return confirm(''$phrases[are_you_sure]'');\\"><img src=''images/delete.gif'' title=''$phrases[delete]'' border=0>$phrases[delete]</a>";\r\n}\r\n\r\n\r\nif(CFN=="search.php"){\r\nprint "<br><img src=''images/cat.gif''><a href=\\"".str_replace("{id}",$data[''cat_id''],$links[''links_cats''])."\\">$data[cat_name]</a>";\r\n}\r\nprint "</td>";\r\n?>\r\n', 1, 1, 3),
(13, 'Browse News - Outside', 'browse_news', '<?\r\nglobal $phrases,$data,$links,$settings;\r\n\r\n$news_date = date($settings[''date_format''],$data[''date'']);\r\n$details_link = str_replace(''{id}'',$data[''id''],$links[''news_details'']);\r\n\r\n\r\nprint "<table width=100%>\r\n\r\n<tr><td colspan=2 align=center>\r\n<a href=\\"$details_link\\" title=\\"$data[title]\\"><span class=''title''>$data[title]</span></a>\r\n</td></tr>\r\n\r\n\r\n<tr><td align=center width=''80''>\r\n<a href=\\"$details_link\\" title=\\"$data[title]\\"><img src=\\"".get_image($data[''img''])."\\" title=\\"$data[title]\\"></a></td>\r\n<td>\r\n\r\n<font color=''#808080''>$news_date : </font> $data[content] ... <a href=\\"$details_link\\"> $phrases[read_more]</a>\r\n<br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font></td></tr>\r\n\r\n</table>\r\n<hr class=separate_line size=\\"1\\">";\r\n?>', 1, 1, 2),
(20, '', 'browse_movies_header', '<table width=100%><tr>', 1, 1, 0),
(21, '', 'browse_movies_footer', '</tr></table>', 1, 1, 0),
(22, '', 'browse_movies_sep', '</tr><tr>', 1, 1, 0),
(25, 'Browse News - Inside', 'browse_news_inside', '<?\r\nglobal $data,$phrases,$settings;\r\n\r\n$news_date = date($settings[''date_format''],$data[''date'']);\r\n\r\nprint "<table width=100%><tr><td>\r\n\r\n<DIV style=\\"FLOAT: right\\"><TABLE border=\\"0\\"><TBODY><TR><TD><TABLE border=\\"0\\"><TBODY><TR><TD align=\\"center\\">\r\n<img src=''".get_image($data[''img''])."''>\r\n</TD></TR><TR><TD align=center><font color=''#808080''>$news_date</font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir=\\"ltr\\" align=\\"left\\">\r\n$data[details] <br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font>\r\n\r\n</td></tr>\r\n<tr><td colspan=2 align=right><a href=''news_print.php?id=$data[id]''><img src=''images/print.gif'' title=''$phrases[printable_copy]'' border=0></a>\r\n\r\n</div>\r\n\r\n</td></tr></table>";\r\n\r\nif($data[''votes_total''] > 0 && $data[''votes''] > 0){\r\n$rating = $data[''votes'']/$data[''votes_total''] ;\r\n}else{ $rating = 0 ;}\r\n\r\n\r\nprint "<br><br><center>";\r\nprint_rating(''news'',$data[''id''],$rating);    \r\nprint "</center>";\r\n?>', 1, 1, 2),
(26, 'Browse News - Print', 'browse_news_print', '<html dir=rtl>\r\n<title>{title}</title>\r\n\r\n<table width=100%>\r\n<tr>\r\n<td>\r\n<p align=center><font size=5><b>{title}</b></font></p>\r\n</td></tr>\r\n\r\n<tr><td>\r\n\r\n<DIV style="FLOAT: left"><TABLE border="0"><TBODY><TR><TD><TABLE border="0"><TBODY><TR><TD align="center">\r\n<img src=''{img}''>\r\n</TD></TR><TR><TD align=center><font color=''#808080''>{date} </font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  dir="rtl" align="right">\r\n{details} <br><br> الكاتب : <font color=''#808080''>{writer}</font>\r\n</div>\r\n</td></tr>\r\n\r\n</table>   ', 1, 1, 1),
(29, 'Fonts And Colors', 'CSS', '/*------------------ BODY -------------------*/\r\nBODY {\r\nFONT-SIZE: 8pt; \r\nCOLOR: #000000 ; \r\nFONT-FAMILY: Tahoma; \r\n\r\nmargin-top: 0px;\r\nmargin-right: 0px;\r\nmargin-bottom: 0px;\r\nmargin-left: 0px;\r\n\r\nBACKGROUND-COLOR: #911d00;\r\n}\r\n\r\n.header-div {\r\nbackground-image:url(''images/header_bg.png'');\r\nheight:141px;\r\n}\r\n\r\n.container {\r\nmin-height: 100%;\r\n}\r\n\r\n\r\n.footer-div {\r\nwidth:100%;\r\nbackground-image:url(''images/footer_bg.png'');\r\nheight:70px;\r\n}\r\n\r\nimg { \r\nborder: 0px; \r\n}\r\n\r\nfieldset {\r\n	border:  1px solid #911d00;padding: 2;\r\n	\r\n}\r\n\r\n\r\n\r\n\r\n/*--------- TITLES -------------*/\r\n.title {\r\nfont-size: 10pt; color: #911d00; font-weight:bold;align:center;\r\n}\r\n\r\n.block_title{\r\n\r\n}\r\n\r\n.table_title{\r\n}\r\n\r\n\r\n/*----------- LINKS -----------------*/\r\nA:link {COLOR: #946f20; TEXT-DECORATION: none;}\r\nA:active {COLOR: #946f20; TEXT-DECORATION: none;}\r\nA:visited {COLOR: #946f20; TEXT-DECORATION: none;}\r\nA:hover {COLOR: #000000; TEXT-DECORATION: none;}\r\n\r\n\r\n/*----------- PATH BAR -----------------*/\r\n\r\n.path{\r\nCOLOR: #FFFFFF ; \r\n}\r\n\r\n\r\nA:link.path_link {\r\nCOLOR: #FFFFFF; TEXT-DECORATION: none\r\n}\r\nA:active.path_link {\r\nCOLOR: #FFFFFF;  TEXT-DECORATION: none\r\n}\r\nA:visited.path_link {\r\nCOLOR: #FFFFFF;  TEXT-DECORATION: none\r\n}\r\nA:hover.path_link {\r\nCOLOR: #FFFFFF;  TEXT-DECORATION: none\r\n}\r\n\r\n\r\n\r\n/*--------- MEMBERS MESSAGES FONT-----------------*/\r\n.messages {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\n\r\n/*--------- SPARATE LINKE --------------------*/\r\n.separate_line{\r\nborder-width: 1px 0 0 0; border-style: solid; border-color: #911d00;\r\n}\r\n\r\n/*-------- Colored Rows COLORS ---------------*/\r\n.row_1{\r\nbackground-color: #f9ecba;\r\n}\r\n.row_2{\r\nbackground-color: #F0D7A1 ;\r\n}\r\n\r\n\r\n.older_comments_div{\r\nbackground-color: #E9E9E9;\r\n}\r\n\r\n\r\n/* ------- online / offline -----*/\r\n.online {color:#008000;font-weight: bold;}\r\n.offline {color:#585858;}\r\n\r\n/* --------- Categories Menu --------------- */\r\n#cats_menu, #cats_menu ul{\r\n  text-align:left;\r\n  margin:0; \r\n  padding:0; \r\n}\r\n\r\n#cats_menu li{\r\n  margin:0 10px 0 0; \r\n  padding:0; \r\n  list-style-type:none; \r\n}\r\n\r\n#cats_menu .symbols{ \r\n  float:left;\r\n  width:12px;\r\n  height:1em;\r\n  background-position:0 50%;\r\n  background-repeat:no-repeat;\r\n}\r\n\r\n\r\n/* ---------- Tabs ------------ */\r\n.tabs {\r\nwidth: 100%;\r\n\r\n		margin: 0px;\r\n}\r\n\r\n.tab_active {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-width: 1px;\r\n	border-style: solid;\r\n	background-color: #fff;\r\n	color: #000;\r\n	float: left;\r\n	width: 150px;\r\n	cursor: default;\r\n	font-weight: bold;\r\n	padding: 2px;\r\n	font-size: 10pt;\r\n	text-align: center;\r\n	background-image:url(''images/tabs_shade.gif'')\r\n}\r\n\r\n.tab_inactive {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 1px;\r\n	background-color: #ddd;\r\n	color: #777;\r\n	float: left;\r\n	width: 150px;\r\n        cursor:pointer;\r\n	cursor: hand;\r\n	padding: 2px;\r\n	font-size: 10pt;\r\n	text-align: center;\r\n}\r\n\r\n.tab_content {\r\n	-moz-border-radius: 0px 10px 10px 10px;\r\n	width: 99%;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 0px;\r\n	color: #000;\r\n	float: left;\r\n	text-align: left;\r\n	padding: 10px;\r\n}\r\n\r\n.tab_container {\r\nwidth: 100%;\r\nalign: center;\r\ntext-align: center;\r\n}\r\n\r\n\r\n/* --------- Slider ---------------*/\r\n\r\n.slider_active {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-width: 1px;\r\n	border-style: solid;\r\n	background-color: #fff;\r\n	color: #000;\r\n	float: left;\r\n	\r\n	cursor: default;\r\n	font-weight: bold;\r\n\r\nmargin: 0 5px; \r\nheight:15;\r\npadding: 3px 5px;\r\n\r\n	font-size: 10pt;\r\n	text-align: center;\r\n	background-image:url(''images/tabs_shade.gif'')\r\n}\r\n\r\n.slider_inactive {\r\n	-moz-border-radius: 5px 5px 0px 0px;\r\n	border-color: #aaa;\r\n	border-style: solid;\r\n	border-width: 1px;\r\n	background-color: #ddd;\r\n	color: #777;\r\n	float: left;\r\n        cursor:pointer;\r\n	cursor: hand;\r\n       \r\n\r\nmargin: 0 5px; \r\nheight:15;\r\npadding: 3px 5px;\r\n\r\n	font-size: 10pt;\r\n	text-align: center;\r\n}\r\n\r\n\r\n\r\n\r\n.slider_btnz{\r\ncursor: hand;\r\nwidth:25;\r\n}\r\n\r\n\r\n//-------- pop Dialog ---------------\r\n\r\n.boxy-wrapper { position: absolute; left: 50%;\r\n  top: 50%;}\r\n\r\n.boxy-wrapper.fixed { position: fixed;  }\r\n\r\n  /* Modal */\r\n  \r\n  .boxy-modal-blackout { position: absolute; background-color: black; left: 0; top: 0; }\r\n  \r\n  /* Border */\r\n\r\n  .boxy-wrapper { empty-cells: show; }\r\n    .boxy-wrapper .top-left,\r\n    .boxy-wrapper .top-right,\r\n    .boxy-wrapper .bottom-right,\r\n    .boxy-wrapper .bottom-left { width: 10px; height: 10px; padding: 0 ;background-color: black;opacity: 0.6; filter: alpha(opacity=60);}\r\n    \r\n    \r\n	.boxy-wrapper .top,\r\n	.boxy-wrapper .bottom { height: 10px; background-color: black; opacity: 0.6; filter: alpha(opacity=60); padding: 0 }\r\n	\r\n	.boxy-wrapper .left,\r\n	.boxy-wrapper .right { width: 10px; background-color: black; opacity: 0.6; filter: alpha(opacity=60); padding: 0 }\r\n	\r\n	/* Title bar */\r\n	\r\n	.boxy-wrapper .title-bar { background-color: black; padding: 6px; position: relative; text-align:center; }\r\n	  .boxy-wrapper .title-bar.dragging { cursor: move; }\r\n	    .boxy-wrapper .title-bar h2 { font-size: 12px; color: white; line-height: 1; margin: 0; padding: 0; font-weight: normal; }\r\n	    .boxy-wrapper .title-bar .close { color: white; position: absolute; top: 6px; right: 6px; font-size: 90%; line-height: 1; }\r\n		\r\n	/* Content Region */\r\n	\r\n	.boxy-inner { background-color: #911d00; padding: 0 }\r\n	.boxy-content { padding: 15px; }\r\n	\r\n	/* Question Boxes */\r\n\r\n    .boxy-wrapper .question { width: 350px; min-height: 80px; }\r\n    .boxy-wrapper .answers { text-align: left; }\r\n\r\n\r\n\r\n\r\n', 1, 1, 4),
(30, '', 'browse_movies_cats_header', '<?\r\nopen_table();\r\nprint "<table width=100%>";\r\n?>', 1, 1, 0),
(31, '', 'browse_movies_cats_sep', '</tr><tr>', 1, 1, 0),
(32, '', 'browse_movies_cats', '<?\r\nglobal $data,$links,$phrases;\r\n\r\nprint " <td align=center><center><a href=\\"".str_replace("{id}",$data[''id''],$links[''links_cats''])."\\">\r\n            <img border=0 title=\\"$data[name]\\"\r\n            src=\\"".get_image($data[''img''],"images/folder.gif")."\\">\r\n            <br>$data[name] </a><br>" ;\r\n\r\n print "</td>";\r\n?>', 1, 1, 0),
(33, '', 'browse_movies_cats_footer', '<?\r\nprint "</tr></table>";\r\nclose_table();\r\n?>', 1, 1, 0),
(110, 'Email Activation Message', 'email_activation_msg', '<html dir=ltr>\r\n<body>\r\n\r\nHello {name}, <br><br>\r\n\r\n\r\nTo Activate your email , please click on the following URL : <br>\r\n\r\n<a href="{url}" target=_blank>{url}</a>\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>\r\n', 1, 1, 1),
(111, 'Email Change Confirm Message', 'email_change_confirmation_msg', '<html dir=ltr>\r\n<body>\r\n\r\nHello {username} <br><br>\r\n\r\nyou have requested to change your email to this email , if you want to confirm that , click on the following URL : <br>\r\n\r\n<a href="{active_link}" target=_blank>{active_link}</a>\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1, 1),
(112, 'New Password Message', 'pwd_rest_done_msg', '<html dir=ltr>\r\n<body>\r\n\r\n{name},<br>\r\nYour Password Has been changed Successfully,\r\n<br><br>\r\n\r\nYour New Password : {password}\r\n\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1, 3),
(113, 'Password Reset Request Message', 'pwd_rest_request_msg', '<html dir=ltr>\r\n<body>\r\n\r\n{name},<br><br>\r\n\r\nYou have requested to reset your current password , to confirm click on the following url : \r\n<br>\r\n<a href="{url}" target=_blank>{url}</a>\r\n<br><br>\r\n\r\nif you didn''t request that , please ignore this message.\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}', 1, 1, 1),
(114, '', 'no_title_no_border', '{content}', 0, 1, 0),
(115, '', 'center_banners', '<?\r\nglobal $data;\r\nprint "<center><a href=''banner.php?id=$data[id]'' target=_blank><img src=''$data[img]'' border=0 title=''$data[title]''></a><br></center>";\r\n?>', 1, 1, 0),
(116, '', 'blocks_banners', '<?\r\nglobal $data;\r\nopen_block();\r\n\r\nprint "<center><a href=''banner.php?id=$data[id]'' target=_blank><img src=''$data[img]'' border=0 title=''$data[title]''></a></center>";\r\n\r\nclose_block();\r\n?>', 1, 1, 0),
(123, '', 'movie_icons', '<?\r\nglobal $data,$movie_files_count,$movie_subtitles_count,$settings,$phrases,$style,$files_cnt,$scripturl,$links;\r\n\r\n\r\n //------ files ----------//\r\n\r\n          if($movie_files_count == 1){\r\n          get_movie_file_icons($data[''id'']);\r\n          }elseif($movie_files_count > 1 && $settings[''movie_files_list_ajax'']){\r\n            print "<a href=''javascript:;'' onClick=\\"show_files_list($data[id]);\\"><img src=''$style[images]/folder_download.gif'' title=\\"$phrases[watch] / $phrases[download]\\" border=0 width=24 height=24></a>&nbsp;";\r\n           }\r\n\r\n//------ subtitles ------//\r\n\r\nif($movie_subtitles_count && $settings[''movie_subtitles_list_ajax'']){\r\n          print "<a href=''javascript:;'' onClick=\\"show_subtitles_list($data[id]);\\"><img src=''$style[images]/subtitles.gif'' title=\\"$phrases[subtitles]\\" border=0 width=24 height=24></a>&nbsp;";\r\n          }\r\n//----------------------//\r\n          if($settings[''snd2friend'']){\r\n          print "<a href=\\"javascript:send($data[id])\\" id=''snd2friend_lnk''><img src=''$style[images]/snd.gif'' title=\\"$phrases[send2friend]\\" border=0 width=24 height=24></a>&nbsp;";\r\n         }\r\n\r\n//--------------------//\r\nprint "<a href=''http://www.facebook.com/sharer.php?u=".urlencode($scripturl."/".str_replace("{id}",$data[''id''],$links[''links_movie_info'']))."'' target=_blank><img src=''$style[images]/facebook.gif'' width=24 height=24 title=''Share with Facebook'' border=0></a>&nbsp;";\r\n\r\n//--------------------//\r\n         if(check_member_login()){\r\n          print "<a href=\\"javascript:add_to_fav($data[id]);\\"><img src=''$style[images]/favorite_add.gif'' title=\\"$phrases[add2favorite]\\" border=0></a>&nbsp;";\r\n          }\r\n\r\n if($settings[''reports_enabled''] && $movie_files_count == 1){\r\n           print "<a href=\\"javascript:;\\" onClick=\\"report($files_cnt[id],''movie_file'');\\"><img src=\\"$style[images]/report.gif\\" title=\\"$phrases[report_do]\\" border=0 width=24 height=24></a>&nbsp;";\r\n           }\r\n\r\n?>', 1, 1, 0),
(118, 'New PM Notify Message', 'pm_email_notify_msg', '<html dir="ltr">\r\n<body>\r\n\r\n<div align=left>\r\n\r\nHello, <br>\r\n\r\nYou Have Received a new Message from {name_from} <br><br>\r\n\r\nTo View the message , please visit the following url <br>\r\n\r\n<a href="{url}" target=_blank>{url}</a> <br>\r\n\r\n</div>\r\n</body>\r\n</html>', 1, 1, 3),
(119, 'Movies Sort By Bar', 'movies_sort_bar', '<?\r\nglobal $phrases,$cat,$links,$start,$orderby,$sort;\r\n\r\n$orders = array("name"=>$phrases[''the_name''],"year"=>$phrases[''release_year''],"id"=>$phrases[''add_date''],"votes"=>$phrases[''the_most_voted'']);\r\n\r\n\r\n\r\n$page_string = str_replace(array(''{id}'',''{start}''),array($cat,$start),$links[''links_cats_w_pages'']);\r\n\r\n\r\nprint "<span class=''path''><img src=''images/sort.gif''>&nbsp;<b>$phrases[sort_by] :</b>&nbsp;&nbsp;";\r\n\r\nforeach($orders as $key=>$value){\r\n\r\nprint "<a href=''".str_replace(array(''{orderby}'',''{sort}''),array($key,''asc''),$page_string)."'' class=''path_link''>".iif($orderby==$key,"<b>").$value.iif($orderby==$key,"</b>")."</a>";\r\n\r\n\r\nif($orderby==$key && $sort=="asc"){\r\nprint "<img src=''images/arr_asc_disabled.gif'' border=0 title=\\"$value $phrases[asc]\\"></a>";\r\n}else{\r\nprint "<a href=''".str_replace(array(''{orderby}'',''{sort}''),array($key,''asc''),$page_string)."'' class=''path_link''><img src=''images/arr_asc.gif'' border=0 title=\\"$value $phrases[asc]\\"></a>";\r\n}\r\n\r\nif($orderby==$key && $sort=="desc"){\r\nprint "<img src=''images/arr_desc_disabled.gif'' border=0 title=\\"$value $phrases[desc]\\">";\r\n}else{\r\nprint "<a href=''".str_replace(array(''{orderby}'',''{sort}''),array($key,''desc''),$page_string)."'' class=''path_link''><img src=''images/arr_desc.gif'' border=0 title=\\"$value $phrases[desc]\\"></a>";\r\n}\r\n\r\nprint "&nbsp;";\r\n\r\n}\r\n\r\n\r\nprint "</span><br><br>";\r\n\r\n?>', 1, 1, 1),
(120, '', 'movie_file_icons', '<?\r\nglobal $player_data,$links,$phrases,$file_id;\r\n\r\n if($player_data[''int_enabled'']){\r\n           print "<a href=\\"".str_replace("{id}",$file_id[''id''],$links[''file_watch''])."\\" onClick=\\"return show_player($file_id[id],$player_data[id],$player_data[view_style]);\\"><img src=\\"{$player_data[''int_icon'']}\\" title=\\"".str_replace("{views}",$file_id[''views''],$player_data[''int_icon_alt''])."\\" border=0></a>";\r\n          }\r\n          \r\n          if($player_data[''ext_enabled'']){\r\n           print "<a href=\\"".str_replace("{id}",$file_id[''id''],$links[''file_watch_ext''])."\\"><img src=\\"{$player_data[''ext_icon'']}\\" title=\\"".str_replace("{views}",$file_id[''views''],$player_data[''ext_icon_alt''])."\\" border=0></a>";\r\n          }\r\n          \r\n          if($player_data[''download_enabled'']){\r\n           print "<a href=\\"".str_replace("{id}",$file_id[''id''],$links[''file_download''])."\\"><img src=\\"{$player_data[''download_icon'']}\\" title=\\"".str_replace("{downloads}",$file_id[''downloads''],$player_data[''download_icon_alt''])."\\" border=0></a>";\r\n          }\r\n?>', 1, 1, 0),
(121, '', 'movie_files_list', '<?\r\nglobal $tr_color,$data,$player_data,$links,$phrases,$settings,$style;\r\n\r\nprint "<tr class=''$tr_color''><td>$data[name]</td>";\r\n       \r\n         \r\n if(is_array($player_data)){\r\n\r\n if($player_data[''int_enabled'']){\r\n print "<td width=5% align=center><a href=\\"".str_replace("{id}",$data[''id''],$links[''file_watch''])."\\" onClick=\\"return show_player($data[id],$player_data[id],$player_data[view_style]);\\"><img src=\\"{$player_data[''int_icon'']}\\" title=\\"".str_replace("{views}",$data[''views''],$player_data[''int_icon_alt''])."\\" border=0></a></td>";\r\n }\r\n          \r\n if($player_data[''ext_enabled'']){\r\n           print "<td width=5% align=center><a href=\\"".str_replace("{id}",$data[''id''],$links[''file_watch_ext''])."\\"><img src=\\"{$player_data[''ext_icon'']}\\" title=\\"".str_replace("{views}",$data[''views''],$player_data[''ext_icon_alt''])."\\" border=0></a></td>";\r\n          }\r\n          \r\n          if($player_data[''download_enabled'']){\r\n           print "<td width=5% align=center><a href=\\"".str_replace("{id}",$data[''id''],$links[''file_download''])."\\"><img src=\\"{$player_data[''download_icon'']}\\" title=\\"".str_replace("{downloads}",$data[''downloads''],$player_data[''download_icon_alt''])."\\" border=0></a></td>";\r\n          }\r\n          \r\n          \r\nif($settings[''reports_enabled'']){\r\n           print "<td width=5% align=center><a href=\\"javascript:;\\" onClick=\\"report($data[id],''movie_file'');\\"><img src=\\"$style[images]/report.gif\\" title=\\"$phrases[report_do]\\" border=0></a></td>";\r\n           }\r\n           \r\n        \r\n         \r\n          }else{\r\n              print "<td>Error : no player</td>";\r\n          }\r\n        \r\n        print "</tr>";  \r\n?>', 1, 1, 0),
(122, '', 'movie_subtitles_list', '<?\r\nglobal $tr_color,$data,$links,$phrases,$style;\r\n\r\n print "<tr class=''$tr_color''><td>$data[name]</td><td width=''24''>\r\n       <a href=\\"".str_replace("{id}",$data[''id''],$links[''subtitle_download''])."\\" title=\\"$phrases[download]\\">\r\n       <img src=\\"$style[images]/download.gif\\" border=0></a></td></tr>";\r\n?>\r\n', 1, 1, 0),
(124, 'Contact us Message Template', 'contactus_msg', '<html dir=ltr>\r\n<body>\r\n\r\nSender''s Name : {name} <br>\r\nSender''s Email : {email} <br><br>\r\n\r\n----------------------------------<br><br>\r\n\r\n{message}\r\n\r\n<br><br>\r\n\r\n---------------------------------\r\n\r\n</body>\r\n</html>', 1, 1, 1),
(125, 'Movie Info', 'movie_info', '<?\r\nglobal $data,$phrases,$settings,$director,$custom_fields,$global_align_x,$style,$movie_files_count,$movie_subtitles_count,$rating,$links;\r\n\r\nprint "<table width=100%><tr>\r\n          <td align=center width=\\"".($settings[''movie_cover_thumb_width'']+10)."\\" rowspan=2>";\r\n        \r\n          if($data[''thumb'']){\r\n          print "<a href=\\"javascript:enlarge_pic(''".$data[''img'']."'',''".htmlspecialchars(str_replace(array("?","''"),"",$data[''name'']))."'')\\"><img border=0 src=\\"".get_image($data[''thumb''])."\\" title=\\"$data[name]\\n$phrases[enlarge_pic]\\"></a>";\r\n          }else{\r\nprint "<img border=0 src=''".get_image($data[''thumb''],$style[''images'']."/no_pic_movie.gif")."''>";\r\n        }\r\n                  \r\n       \r\n         print "\r\n         <br><br>";\r\n         \r\nprint_rating(''movie'',$data[''id''],$rating);\r\n        \r\n          \r\nprint "</td><td>\r\n         <img src=''$style[images]/add_date.gif''> &nbsp; <b>$phrases[add_date] : </b> ".date($settings[''date_format''],$data[''date'']);\r\n          \r\n//---------------- director ------\r\n          if($director[''name'']){\r\n              print "<br><img src=''images/director.gif''> &nbsp;<b> $phrases[the_director] : </b>";\r\n           if($director[''id'']){\r\n             print "<a href=\\"".str_replace("{id}",$director[''id''],$links[''links_actor_details''])."\\" title=\\"$director[name]\\">$director[name]</a>";        \r\n              }else{\r\n             print "$director[name]";\r\n              }\r\n          }\r\n          //-------------------\r\n          \r\n    \r\n   foreach($custom_fields as $field){\r\n\r\nprint "<br><img src=''$style[images]/info.gif''> &nbsp;<b>$field[name] : </b> ".iif($field[''search''],"<a href=\\"search.php?field_id=$field[id]&keyword=".$field[''value'']."\\">").$field[''value''].iif($field[''search''],"</a>");\r\n\r\n}       \r\n          \r\n          \r\n  if($movie_files_count){print "<br><img src=''$style[images]/files.gif''> &nbsp;<b> $phrases[the_files_count] : </b> $movie_files_count";}\r\n\r\n\r\nif($movie_subtitles_count){print "<br><img src=''$style[images]/subtitles_count.gif''> &nbsp;<b> $phrases[the_subtitles_count] : </b> $movie_subtitles_count";} \r\n\r\nif($data[''year'']){\r\nprint "<br> <img src=''$style[images]/year.gif''> &nbsp; <b>$phrases[release_year] : </b>$data[year]";\r\n}\r\n\r\n\r\nprint "<br> <img src=''$style[images]/views.gif''> &nbsp; <b>$phrases[views] : </b>$data[views]";\r\n\r\n\r\n           \r\n            \r\n          print "<br><br>\r\n          $data[details]<br>\r\n\r\n          </td></tr><tr><td align=''$global_align_x'' valign=bottom>";\r\n          run_template(''movie_icons'');\r\n          print "</td></tr></table>";\r\n\r\n?>', 1, 1, 3),
(126, '', 'news_cats_header', '<?\r\nopen_table();\r\nprint "<table width=100%><tr>";\r\n?>', 1, 1, 0),
(127, '', 'news_cats', '<?\r\nglobal $data,$links,$style;\r\n\r\nprint "<td align=center><a href=\\"".str_replace(''{cat}'',$data[''id''],$links[''links_browse_news''])."\\"><img src=\\"".get_image($data[''img''],"$style[images]/folder.gif")."\\" title=\\"$data[name]\\"><br>$data[name]</a></td>";\r\n\r\n\r\n?>', 1, 1, 1),
(128, '', 'news_cats_sep', '</tr><tr>', 1, 1, 0),
(129, '', 'news_cats_footer', '<?\r\nprint "</tr></table>";\r\nclose_table();\r\n?>', 1, 1, 0),
(130, '', 'browse_news_header', '<?\r\nglobal $phrases;\r\nopen_table("$phrases[the_news]");\r\nprint "<hr class=separate_line size=\\"1\\">";    \r\n?>', 1, 1, 0),
(131, '', 'browse_news_sep', '', 1, 1, 0),
(132, '', 'browse_news_footer', '<?\r\nclose_table();\r\n?>', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `movies_templates_cats`
--

CREATE TABLE IF NOT EXISTS `movies_templates_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `selectable` int(11) NOT NULL default '0',
  `images` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `movies_templates_cats`
--

INSERT INTO `movies_templates_cats` (`id`, `name`, `selectable`, `images`) VALUES
(1, 'Default Style', 1, 'images');

-- --------------------------------------------------------

--
-- Table structure for table `movies_user`
--

CREATE TABLE IF NOT EXISTS `movies_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `group_id` int(11) NOT NULL default '0',
  `cp_permisions` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_user`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_votes`
--

CREATE TABLE IF NOT EXISTS `movies_votes` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `cnt` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cat` (`cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_votes`
--


-- --------------------------------------------------------

--
-- Table structure for table `movies_votes_cats`
--

CREATE TABLE IF NOT EXISTS `movies_votes_cats` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `active` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `movies_votes_cats`
--

